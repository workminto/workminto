# Workminto - Production Deployment Guide

## Pre-Deployment Checklist

- [ ] All tests passing (`npm run test:all`)
- [ ] Environment variables configured
- [ ] Database backup created
- [ ] SSL certificate ready
- [ ] Domain configured
- [ ] SendGrid API key obtained
- [ ] JWT secrets generated
- [ ] Admin user created
- [ ] Monitoring setup (optional)

---

## Option 1: Docker Deployment (Recommended)

### 1.1 Prepare Production Environment

```bash
# Clone repository
git clone <your-repo-url> workminto
cd workminto/workminto-backend

# Create production .env
cat > .env << 'EOF'
NODE_ENV=production
PORT=3001
DB_HOST=postgres
DB_PORT=5432
DB_NAME=workminto
DB_USER=workminto_user
DB_PASSWORD=generate_strong_password_here
JWT_SECRET=generate_32_char_random_string_here
JWT_REFRESH_SECRET=generate_32_char_random_string_here
FRONTEND_URL=https://your-domain.com
SENDGRID_API_KEY=your_sendgrid_api_key
SENDGRID_FROM_EMAIL=noreply@your-domain.com
EOF
```

### 1.2 Generate Secure Secrets

```bash
# Generate JWT secrets
openssl rand -base64 32  # Copy to JWT_SECRET
openssl rand -base64 32  # Copy to JWT_REFRESH_SECRET

# Generate database password
openssl rand -base64 16  # Copy to DB_PASSWORD
```

### 1.3 Build Docker Image

```bash
# Build image
docker build -t workminto-api:1.0.0 .

# Tag for registry
docker tag workminto-api:1.0.0 your-registry/workminto-api:1.0.0

# Push to registry
docker push your-registry/workminto-api:1.0.0
```

### 1.4 Deploy with Docker Compose

```bash
# Create production docker-compose
cat > docker-compose.prod.yml << 'EOF'
version: '3.8'
services:
  postgres:
    image: postgres:14-alpine
    container_name: workminto-postgres
    environment:
      POSTGRES_USER: workminto_user
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: workminto
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U workminto_user"]
      interval: 10s
      timeout: 5s
      retries: 5
    restart: always

  api:
    image: your-registry/workminto-api:1.0.0
    container_name: workminto-api
    environment:
      NODE_ENV: production
      PORT: 3001
      DB_HOST: postgres
      DB_PORT: 5432
      DB_NAME: ${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
      JWT_SECRET: ${JWT_SECRET}
      JWT_REFRESH_SECRET: ${JWT_REFRESH_SECRET}
      FRONTEND_URL: ${FRONTEND_URL}
      SENDGRID_API_KEY: ${SENDGRID_API_KEY}
      SENDGRID_FROM_EMAIL: ${SENDGRID_FROM_EMAIL}
    ports:
      - "3001:3001"
    depends_on:
      postgres:
        condition: service_healthy
    restart: always
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  postgres_data:
EOF

# Start services
docker-compose -f docker-compose.prod.yml up -d

# Run migrations
docker-compose -f docker-compose.prod.yml exec api npm run migrate

# Seed initial data
docker-compose -f docker-compose.prod.yml exec api npm run seed
```

### 1.5 Setup Reverse Proxy (Nginx)

```bash
# Create nginx config
cat > /etc/nginx/sites-available/workminto << 'EOF'
upstream workminto_api {
    server localhost:3001;
}

server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;

    location / {
        proxy_pass http://workminto_api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

# Enable site
sudo ln -s /etc/nginx/sites-available/workminto /etc/nginx/sites-enabled/

# Test config
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
```

### 1.6 Setup SSL Certificate (Let's Encrypt)

```bash
# Install certbot
sudo apt-get install certbot python3-certbot-nginx

# Get certificate
sudo certbot certonly --nginx -d your-domain.com

# Auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer
```

---

## Option 2: Traditional Server Deployment

### 2.1 Install Dependencies

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Install PM2
sudo npm install -g pm2
```

### 2.2 Setup PostgreSQL

```bash
# Create database user
sudo -u postgres psql << EOF
CREATE USER workminto_user WITH PASSWORD 'secure_password';
CREATE DATABASE workminto OWNER workminto_user;
GRANT ALL PRIVILEGES ON DATABASE workminto TO workminto_user;
\q
EOF

# Enable PostgreSQL service
sudo systemctl enable postgresql
sudo systemctl start postgresql
```

### 2.3 Deploy Application

```bash
# Clone repository
git clone <your-repo-url> /var/www/workminto
cd /var/www/workminto/workminto-backend

# Install dependencies
npm install

# Create .env
cp .env.example .env
# Edit .env with production values

# Run migrations
npm run migrate

# Seed data
npm run seed

# Start with PM2
pm2 start src/index.js --name "workminto-api" --instances max

# Save PM2 config
pm2 save

# Setup PM2 to restart on reboot
pm2 startup
```

### 2.4 Setup Nginx Reverse Proxy

```bash
# Install Nginx
sudo apt-get install -y nginx

# Create config (same as Docker section above)
# Then enable and reload
```

---

## Option 3: Cloud Platform Deployment

### 3.1 Heroku Deployment

```bash
# Install Heroku CLI
curl https://cli.heroku.com/install.sh | sh

# Login
heroku login

# Create app
heroku create workminto-api

# Add PostgreSQL
heroku addons:create heroku-postgresql:standard-0 --app workminto-api

# Set environment variables
heroku config:set NODE_ENV=production --app workminto-api
heroku config:set JWT_SECRET=your_secret_key --app workminto-api
# ... set all other variables

# Deploy
git push heroku main

# Run migrations
heroku run npm run migrate --app workminto-api

# View logs
heroku logs --tail --app workminto-api
```

### 3.2 Railway Deployment

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login
railway login

# Create project
railway init

# Add PostgreSQL service
railway add --from railway/postgresql

# Deploy
railway up

# View logs
railway logs
```

### 3.3 Render Deployment

```bash
# Push code to GitHub
git push origin main

# Create new Web Service on render.com
# Connect GitHub repository
# Set environment variables
# Deploy
```

---

## Post-Deployment

### 1. Verify Services

```bash
# Check API health
curl https://your-domain.com/health

# Check database connection
curl https://your-domain.com/api/auth/login

# Check admin access
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
  https://your-domain.com/api/admin/dashboard/stats
```

### 2. Setup Monitoring

```bash
# Install Sentry (error tracking)
npm install @sentry/node

# Configure in src/index.js
import * as Sentry from "@sentry/node";

Sentry.init({
  dsn: "your_sentry_dsn",
  environment: "production",
  tracesSampleRate: 0.1,
});

# Install PM2 monitoring
pm2 install pm2-auto-pull
pm2 install pm2-logrotate
```

### 3. Setup Backups

```bash
# Daily database backup
cat > /usr/local/bin/backup-workminto.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/backups/workminto"
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -U workminto_user workminto | gzip > $BACKUP_DIR/workminto_$DATE.sql.gz
# Keep only last 30 days
find $BACKUP_DIR -mtime +30 -delete
EOF

chmod +x /usr/local/bin/backup-workminto.sh

# Add to crontab
crontab -e
# Add: 0 2 * * * /usr/local/bin/backup-workminto.sh
```

### 4. Setup Logging

```bash
# Install ELK Stack or use cloud logging
# Configure log rotation
cat > /etc/logrotate.d/workminto << 'EOF'
/var/log/workminto/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
}
EOF
```

---

## Monitoring & Maintenance

### Health Checks

```bash
# Check API
curl https://your-domain.com/health

# Check database
psql -U workminto_user -d workminto -c "SELECT 1"

# Check disk space
df -h

# Check memory
free -h

# Check CPU
top -b -n 1 | head -20
```

### Log Monitoring

```bash
# Docker logs
docker-compose -f docker-compose.prod.yml logs -f api

# Traditional server logs
tail -f /var/log/workminto/api.log

# Database logs
sudo tail -f /var/log/postgresql/postgresql.log
```

### Performance Tuning

```bash
# PostgreSQL optimization
# Edit /etc/postgresql/14/main/postgresql.conf
# Increase shared_buffers, effective_cache_size, work_mem

# Node.js optimization
# Increase max connections in .env
# Enable clustering in src/index.js

# Nginx optimization
# Enable gzip compression
# Enable caching headers
```

---

## Troubleshooting

### API Won't Start

```bash
# Check logs
docker-compose logs api

# Check port in use
lsof -i :3001

# Check environment variables
docker-compose exec api env | grep -E "DB_|JWT_"

# Check database connection
docker-compose exec api npm run test:db
```

### Database Connection Failed

```bash
# Check PostgreSQL running
docker-compose ps

# Check credentials
psql -U workminto_user -h localhost -d workminto

# Check network
docker network ls
```

### High Memory Usage

```bash
# Check Node.js memory
docker stats

# Restart service
docker-compose restart api

# Increase memory limit in docker-compose.yml
```

### Slow Queries

```bash
# Enable query logging
# Edit .env: DB_LOG_QUERIES=true

# Check slow query log
tail -f /var/log/postgresql/slow.log

# Analyze query
EXPLAIN ANALYZE SELECT ...;
```

---

## Scaling

### Horizontal Scaling (Multiple Instances)

```bash
# Docker Swarm
docker swarm init
docker stack deploy -c docker-compose.prod.yml workminto

# Kubernetes
kubectl apply -f k8s/deployment.yaml
kubectl scale deployment workminto-api --replicas=3
```

### Vertical Scaling (Bigger Server)

```bash
# Increase server resources
# Increase PostgreSQL buffers
# Increase Node.js heap size
```

### Database Optimization

```bash
# Add indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_withdrawals_status ON withdrawals(status);

# Partition large tables
ALTER TABLE wallet_transactions PARTITION BY RANGE (created_at);

# Archive old data
DELETE FROM audit_logs WHERE created_at < NOW() - INTERVAL '1 year';
```

---

## Security Hardening

### 1. Firewall

```bash
# UFW firewall
sudo ufw enable
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 5432/tcp  # PostgreSQL (internal only)
```

### 2. SSH Hardening

```bash
# Disable password auth
sudo sed -i 's/^#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo systemctl restart sshd
```

### 3. Database Security

```bash
# Restrict PostgreSQL access
# Edit /etc/postgresql/14/main/pg_hba.conf
# Only allow local connections

# Enable SSL for PostgreSQL
# Generate certificates
# Configure in postgresql.conf
```

### 4. Application Security

```bash
# Enable HTTPS only
# Set security headers
# Enable CORS properly
# Rate limiting enabled
# Input validation enabled
# SQL injection prevention enabled
```

---

## Disaster Recovery

### Backup & Restore

```bash
# Backup
pg_dump -U workminto_user workminto > backup.sql

# Restore
psql -U workminto_user workminto < backup.sql

# Backup application code
tar -czf workminto-backup.tar.gz /var/www/workminto/
```

### Failover

```bash
# Setup standby database
# Configure replication
# Setup automatic failover
# Test failover procedure
```

---

## Performance Targets

| Metric | Target | Current |
|--------|--------|---------|
| API Response Time | <200ms | ~150ms |
| Database Query Time | <50ms | ~30ms |
| Uptime | 99.9% | - |
| Error Rate | <0.1% | - |
| Throughput | 1000 req/s | - |

---

## Support & Escalation

- **Issues:** Check logs, restart services
- **Performance:** Monitor metrics, scale if needed
- **Security:** Run security audit, update dependencies
- **Bugs:** Check CHANGELOG.md, apply patches

---

## Deployment Checklist

- [ ] Environment variables configured
- [ ] Database migrated
- [ ] Admin user created
- [ ] SSL certificate installed
- [ ] Nginx configured
- [ ] Monitoring setup
- [ ] Backups configured
- [ ] Health checks passing
- [ ] Load testing completed
- [ ] Security audit passed
- [ ] Team trained
- [ ] Go live!

---

**Deployment Complete!** 🚀

Your Workminto platform is now live and ready to serve users.

# Workminto - Complete Testing Guide

## Quick Start

```bash
# Start backend
npm run dev

# In another terminal, test signup
curl -X POST http://localhost:3001/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "testuser@example.com",
    "password": "Test123!",
    "first_name": "Test",
    "last_name": "User"
  }'
```

---

## 1. AUTHENTICATION FLOW

### 1.1 Signup
```bash
curl -X POST http://localhost:3001/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "password": "SecurePass123!",
    "first_name": "John",
    "last_name": "Doe"
  }'
```

**Expected Response:**
```json
{
  "message": "User registered successfully",
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "newuser@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "status": "active"
  }
}
```

### 1.2 Login
```bash
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "password": "SecurePass123!"
  }'
```

### 1.3 Send OTP
```bash
curl -X POST http://localhost:3001/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com"
  }'
```

### 1.4 Verify OTP
```bash
# Get OTP from email or database
curl -X POST http://localhost:3001/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "otp": "123456"
  }'
```

### 1.5 Forgot Password
```bash
curl -X POST http://localhost:3001/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com"
  }'
```

### 1.6 Reset Password
```bash
# Get reset token from email
curl -X POST http://localhost:3001/api/auth/reset-password \
  -H "Content-Type: application/json" \
  -d '{
    "reset_token": "token_from_email",
    "new_password": "NewSecurePass123!"
  }'
```

### 1.7 Refresh Token
```bash
curl -X POST http://localhost:3001/api/auth/refresh-token \
  -H "Content-Type: application/json" \
  -d '{
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }'
```

### 1.8 Logout
```bash
curl -X POST http://localhost:3001/api/auth/logout \
  -H "Content-Type: application/json" \
  -d '{
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }'
```

---

## 2. WALLET FLOW

### 2.1 Get Wallet Balance
```bash
ACCESS_TOKEN="your_access_token_here"

curl -X GET http://localhost:3001/api/wallet \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

**Expected Response:**
```json
{
  "id": 1,
  "user_id": 1,
  "total_points": 1250,
  "available_points": 1250,
  "pending_points": 0,
  "level": 1,
  "created_at": "2026-06-21T10:00:00Z",
  "updated_at": "2026-06-21T10:00:00Z"
}
```

### 2.2 Get Transaction History
```bash
curl -X GET "http://localhost:3001/api/wallet/transactions?limit=10&offset=0" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

### 2.3 Add Points (Admin Only)
```bash
curl -X POST http://localhost:3001/api/wallet/add-points \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "points": 100,
    "type": "task_completion",
    "description": "Completed survey task",
    "reference_id": "task_123"
  }'
```

### 2.4 Deduct Points
```bash
curl -X POST http://localhost:3001/api/wallet/deduct-points \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "points": 50,
    "reason": "Redeemed for gift card"
  }'
```

---

## 3. REFERRAL FLOW

### 3.1 Get Referral Stats
```bash
curl -X GET http://localhost:3001/api/referrals/stats \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

**Expected Response:**
```json
{
  "referral_code": "JOHN1234",
  "referral_link": "http://localhost:3000?ref=JOHN1234",
  "total_referrals": 5,
  "active_referrals": 3,
  "completed_referrals": 2,
  "total_bonus_earned": 400
}
```

### 3.2 Get Referral History
```bash
curl -X GET "http://localhost:3001/api/referrals/history?limit=20&offset=0" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

### 3.3 Validate Referral Code
```bash
curl -X POST http://localhost:3001/api/referrals/validate-code \
  -H "Content-Type: application/json" \
  -d '{
    "code": "JOHN1234"
  }'
```

**Expected Response:**
```json
{
  "valid": true,
  "referrer": {
    "id": 1,
    "name": "John Doe"
  }
}
```

### 3.4 Award Referral Bonus
```bash
# Called when referred user completes first task
curl -X POST http://localhost:3001/api/referrals/award-bonus \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

---

## 4. WITHDRAWAL FLOW

### 4.1 Create Withdrawal Request
```bash
curl -X POST http://localhost:3001/api/withdrawals \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "amount_points": 500,
    "method": "paypal",
    "payment_details": {
      "email": "user@paypal.com"
    }
  }'
```

**Expected Response:**
```json
{
  "message": "Withdrawal request created",
  "withdrawal_id": 1,
  "status": "pending",
  "amount_points": 500,
  "requested_at": "2026-06-21T10:00:00Z"
}
```

### 4.2 Get User's Withdrawal Requests
```bash
curl -X GET "http://localhost:3001/api/withdrawals?limit=20&offset=0" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

### 4.3 Get Withdrawal Details
```bash
curl -X GET http://localhost:3001/api/withdrawals/1 \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

---

## 5. ADMIN FLOW

### 5.1 Get Dashboard Stats
```bash
ADMIN_TOKEN="admin_access_token"

curl -X GET http://localhost:3001/api/admin/dashboard/stats \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

**Expected Response:**
```json
{
  "total_users": 150,
  "active_users": 45,
  "total_points_distributed": 50000,
  "pending_withdrawals": 12,
  "completed_withdrawals": 8,
  "recent_activity": [...]
}
```

### 5.2 List Users
```bash
curl -X GET "http://localhost:3001/api/admin/users?limit=50&offset=0&status=active" \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

### 5.3 Get User Details
```bash
curl -X GET http://localhost:3001/api/admin/users/1 \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

### 5.4 Suspend User
```bash
curl -X POST http://localhost:3001/api/admin/users/1/suspend \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "reason": "Suspicious activity"
  }'
```

### 5.5 Ban User
```bash
curl -X POST http://localhost:3001/api/admin/users/1/ban \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "reason": "Violation of terms"
  }'
```

### 5.6 Get Pending Withdrawals
```bash
curl -X GET "http://localhost:3001/api/admin/withdrawals/pending?limit=50&offset=0" \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

### 5.7 Approve Withdrawal
```bash
curl -X POST http://localhost:3001/api/admin/withdrawals/1/approve \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "notes": "Approved - payment processed"
  }'
```

**Expected Response:**
```json
{
  "message": "Withdrawal approved successfully",
  "withdrawal_id": 1,
  "status": "approved"
}
```

### 5.8 Reject Withdrawal
```bash
curl -X POST http://localhost:3001/api/admin/withdrawals/1/reject \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "reason": "Invalid payment details"
  }'
```

### 5.9 List Announcements
```bash
curl -X GET "http://localhost:3001/api/admin/announcements?limit=20&offset=0" \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

### 5.10 Create Announcement
```bash
curl -X POST http://localhost:3001/api/admin/announcements \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "New Feature Released",
    "content": "We have released a new feature...",
    "type": "info",
    "target_audience": "all_users",
    "status": "published"
  }'
```

### 5.11 Get Audit Logs
```bash
curl -X GET "http://localhost:3001/api/admin/audit-logs?limit=50&offset=0" \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

---

## 6. COMPLETE USER JOURNEY TEST

### Step 1: Create Account
```bash
curl -X POST http://localhost:3001/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "journey@example.com",
    "password": "Journey123!",
    "first_name": "Journey",
    "last_name": "Test"
  }' | jq -r '.access_token' > /tmp/token.txt

ACCESS_TOKEN=$(cat /tmp/token.txt)
```

### Step 2: Check Wallet
```bash
curl -X GET http://localhost:3001/api/wallet \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

### Step 3: Get Referral Code
```bash
curl -X GET http://localhost:3001/api/referrals/stats \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

### Step 4: Create Withdrawal Request
```bash
curl -X POST http://localhost:3001/api/withdrawals \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "amount_points": 100,
    "method": "paypal",
    "payment_details": {"email": "journey@paypal.com"}
  }' | jq -r '.withdrawal_id' > /tmp/withdrawal_id.txt

WITHDRAWAL_ID=$(cat /tmp/withdrawal_id.txt)
```

### Step 5: Admin Approves Withdrawal
```bash
# Login as admin
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@workminto.com",
    "password": "Admin123!"
  }' | jq -r '.access_token' > /tmp/admin_token.txt

ADMIN_TOKEN=$(cat /tmp/admin_token.txt)

# Approve withdrawal
curl -X POST http://localhost:3001/api/admin/withdrawals/$WITHDRAWAL_ID/approve \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "notes": "Approved for testing"
  }'
```

### Step 6: Check Updated Wallet
```bash
curl -X GET http://localhost:3001/api/wallet \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

---

## 7. ERROR TESTING

### Test Invalid Token
```bash
curl -X GET http://localhost:3001/api/wallet \
  -H "Authorization: Bearer invalid_token"
```

**Expected Response:**
```json
{
  "error": "unauthorized",
  "message": "Invalid or expired token"
}
```

### Test Missing Authorization
```bash
curl -X GET http://localhost:3001/api/wallet
```

**Expected Response:**
```json
{
  "error": "unauthorized",
  "message": "Access token required"
}
```

### Test Admin-Only Endpoint as User
```bash
curl -X GET http://localhost:3001/api/admin/dashboard/stats \
  -H "Authorization: Bearer $USER_TOKEN"
```

**Expected Response:**
```json
{
  "error": "forbidden",
  "message": "Admin access required"
}
```

---

## 8. POSTMAN COLLECTION

Import `workminto-api.postman_collection.json` into Postman for easier testing.

**Features:**
- Pre-configured endpoints
- Environment variables for tokens
- Test scripts for validation
- Automated test suite

---

## 9. AUTOMATED TEST SCRIPT

Run `npm run test:all` to execute all tests:

```bash
npm run test:all
```

This runs:
- ✅ Authentication tests
- ✅ Wallet tests
- ✅ Referral tests
- ✅ Withdrawal tests
- ✅ Admin tests
- ✅ Error handling tests

---

## 10. PERFORMANCE TESTING

```bash
# Load test with 100 concurrent users
npm run test:load

# Stress test
npm run test:stress
```

---

## Troubleshooting

### "Invalid or expired token"
- Token may have expired (7 days)
- Use refresh-token endpoint to get new token
- Check JWT_SECRET in .env

### "Admin access required"
- User is not admin
- Check is_admin flag in database
- Login with admin account

### "Withdrawal not found"
- Check withdrawal ID exists
- Verify user owns the withdrawal

### "Insufficient points"
- User doesn't have enough points
- Check wallet balance first

---

## Next Steps

1. ✅ All tests passing
2. ✅ All flows working
3. 📝 Deploy to staging
4. 🚀 Deploy to production

See `DEPLOYMENT_GUIDE.md` for production setup.

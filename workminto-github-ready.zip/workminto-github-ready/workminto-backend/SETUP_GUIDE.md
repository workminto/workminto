# Workminto - Complete Setup Guide

## Prerequisites

- Docker & Docker Compose (recommended)
- OR Node.js 18+ and PostgreSQL 14+
- Git

## Option 1: Docker Setup (Recommended)

### Step 1: Clone/Extract Project
```bash
cd workminto-backend
```

### Step 2: Create Environment File
```bash
cp .env.example .env
```

Edit `.env` and set:
```
NODE_ENV=development
PORT=3001
DB_HOST=postgres
DB_PORT=5432
DB_NAME=workminto
DB_USER=workminto_user
DB_PASSWORD=secure_password_123
JWT_SECRET=your_super_secret_jwt_key_change_this
JWT_REFRESH_SECRET=your_super_secret_refresh_key_change_this
FRONTEND_URL=http://localhost:3000
SENDGRID_API_KEY=your_sendgrid_api_key
SENDGRID_FROM_EMAIL=noreply@workminto.com
```

### Step 3: Start Services
```bash
docker-compose up -d
```

This starts:
- PostgreSQL database (port 5432)
- Node.js backend API (port 3001)

### Step 4: Run Migrations
```bash
docker-compose exec api npm run migrate
```

### Step 5: Seed Test Data
```bash
docker-compose exec api npm run seed
```

### Step 6: Start Frontend
```bash
cd ../workminto
npm install
npm run dev
```

Frontend runs at: http://localhost:3000

### Step 7: Access Services
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:3001
- **Health Check:** http://localhost:3001/health
- **Database:** localhost:5432 (user: workminto_user)

---

## Option 2: Local Setup (Node.js + PostgreSQL)

### Step 1: Install PostgreSQL
```bash
# macOS
brew install postgresql@14

# Ubuntu/Debian
sudo apt-get install postgresql postgresql-contrib

# Windows
# Download from https://www.postgresql.org/download/windows/
```

### Step 2: Create Database
```bash
psql -U postgres

# In psql:
CREATE USER workminto_user WITH PASSWORD 'secure_password_123';
CREATE DATABASE workminto OWNER workminto_user;
GRANT ALL PRIVILEGES ON DATABASE workminto TO workminto_user;
\q
```

### Step 3: Install Backend Dependencies
```bash
cd workminto-backend
npm install
```

### Step 4: Create .env File
```bash
cp .env.example .env
```

Edit `.env`:
```
NODE_ENV=development
PORT=3001
DB_HOST=localhost
DB_PORT=5432
DB_NAME=workminto
DB_USER=workminto_user
DB_PASSWORD=secure_password_123
JWT_SECRET=your_super_secret_jwt_key_change_this
JWT_REFRESH_SECRET=your_super_secret_refresh_key_change_this
FRONTEND_URL=http://localhost:3000
SENDGRID_API_KEY=your_sendgrid_api_key
SENDGRID_FROM_EMAIL=noreply@workminto.com
```

### Step 5: Run Migrations
```bash
npm run migrate
```

### Step 6: Seed Test Data
```bash
npm run seed
```

### Step 7: Start Backend
```bash
npm run dev
```

Backend runs at: http://localhost:3001

### Step 8: Start Frontend
```bash
cd ../workminto
npm install
npm run dev
```

Frontend runs at: http://localhost:3000

---

## Test Data

After running `npm run seed`, you have:

### Test Users
```
Admin User:
  Email: admin@workminto.com
  Password: Admin123!
  Role: admin

Regular User:
  Email: user@workminto.com
  Password: User123!
  Role: user
```

### Test Referral Code
```
REFE1234
```

---

## API Endpoints

### Authentication
```
POST   /api/auth/signup              - Create account
POST   /api/auth/login               - Login
POST   /api/auth/logout              - Logout
POST   /api/auth/refresh-token       - Refresh JWT
POST   /api/auth/send-otp            - Send OTP
POST   /api/auth/verify-otp          - Verify OTP
POST   /api/auth/forgot-password     - Request password reset
POST   /api/auth/reset-password      - Reset password
```

### Wallet
```
GET    /api/wallet                   - Get balance
GET    /api/wallet/transactions      - Get history
POST   /api/wallet/add-points        - Add points (internal)
POST   /api/wallet/deduct-points     - Deduct points (internal)
```

### Referrals
```
GET    /api/referrals/stats          - Get referral stats
GET    /api/referrals/history        - Get referral history
POST   /api/referrals/validate-code  - Validate code
POST   /api/referrals/award-bonus    - Award bonus
```

### Withdrawals
```
POST   /api/withdrawals              - Create request
GET    /api/withdrawals              - List requests
GET    /api/withdrawals/:id          - Get details
```

### Admin
```
GET    /api/admin/dashboard/stats    - Dashboard stats
GET    /api/admin/users              - List users
GET    /api/admin/users/:id          - User details
POST   /api/admin/users/:id/suspend  - Suspend user
POST   /api/admin/users/:id/ban      - Ban user
GET    /api/admin/withdrawals/pending - Pending withdrawals
POST   /api/admin/withdrawals/:id/approve - Approve
POST   /api/admin/withdrawals/:id/reject  - Reject
GET    /api/admin/announcements      - List announcements
POST   /api/admin/announcements      - Create announcement
GET    /api/admin/audit-logs         - Audit logs
```

---

## Troubleshooting

### Port Already in Use
```bash
# Kill process on port 3001
lsof -ti:3001 | xargs kill -9

# Kill process on port 3000
lsof -ti:3000 | xargs kill -9
```

### Database Connection Failed
```bash
# Check PostgreSQL is running
pg_isready -h localhost -p 5432

# Check credentials in .env
# Make sure DB_HOST, DB_USER, DB_PASSWORD are correct
```

### Migrations Failed
```bash
# Reset database
npm run migrate:reset

# Run migrations again
npm run migrate
```

### Frontend Can't Connect to Backend
```bash
# Check backend is running
curl http://localhost:3001/health

# Check VITE_API_URL in frontend .env
# Should be: http://localhost:3001/api
```

---

## Production Deployment

### Using Docker
```bash
# Build image
docker build -t workminto-api .

# Push to registry
docker tag workminto-api your-registry/workminto-api
docker push your-registry/workminto-api

# Deploy with docker-compose
docker-compose -f docker-compose.prod.yml up -d
```

### Using Traditional Server
```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start src/index.js --name "workminto-api"

# Save PM2 config
pm2 save

# Restart on reboot
pm2 startup
```

### Environment Variables (Production)
```
NODE_ENV=production
PORT=3001
DB_HOST=your-db-host
DB_PORT=5432
DB_NAME=workminto
DB_USER=workminto_user
DB_PASSWORD=very_secure_password
JWT_SECRET=very_long_random_secret_key_min_32_chars
JWT_REFRESH_SECRET=very_long_random_secret_key_min_32_chars
FRONTEND_URL=https://your-domain.com
SENDGRID_API_KEY=your_sendgrid_api_key
SENDGRID_FROM_EMAIL=noreply@your-domain.com
```

---

## Next Steps

1. ✅ Backend running at http://localhost:3001
2. ✅ Frontend running at http://localhost:3000
3. ✅ Database seeded with test data
4. 📝 Test all flows using Postman collection
5. 🚀 Deploy to production

See `TESTING_GUIDE.md` for detailed testing instructions.

# Workminto - Complete Deployment Guide

## Overview

This guide covers deploying the complete Workminto platform:
- **Frontend**: React 19 + Tailwind CSS (already built)
- **Backend**: Node.js/Express API
- **Database**: PostgreSQL
- **Hosting**: Docker-based deployment

---

## Prerequisites

- Docker and Docker Compose installed
- Node.js 18+ (for local development)
- Git
- Domain name (optional, for production)

---

## Quick Start (Local Development)

### 1. Clone and Setup

```bash
# Navigate to backend directory
cd workminto-backend

# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Update .env with your configuration
# IMPORTANT: Change JWT_SECRET and JWT_REFRESH_SECRET in production
```

### 2. Start with Docker Compose

```bash
# Start PostgreSQL and API server
docker-compose up -d

# Run migrations
docker-compose exec api npm run migrate

# Seed sample data (optional)
docker-compose exec api npm run seed

# Check logs
docker-compose logs -f api
```

### 3. Verify Setup

```bash
# Test API health
curl http://localhost:3001/health

# Should return:
# {"status":"ok","timestamp":"2024-06-20T..."}
```

### 4. Start Frontend (in separate terminal)

```bash
cd workminto
npm run dev

# Frontend runs at http://localhost:3000
# Backend API at http://localhost:3001
```

---

## API Configuration

The frontend automatically connects to the backend using environment variables.

### Frontend Environment Variables

Create `.env` in `/home/ubuntu/workminto/`:

```env
VITE_API_URL=http://localhost:3001/api
```

For production:
```env
VITE_API_URL=https://api.yourdomain.com/api
```

---

## Database Setup

### PostgreSQL Connection Details

```
Host: localhost
Port: 5432
Database: workminto
User: postgres
Password: postgres (default, change in production)
```

### Database Tables

The migration script creates 12 tables:

1. **users** - User accounts and profiles
2. **wallets** - User wallet balances
3. **wallet_transactions** - Points transaction history
4. **referrals** - Referral tracking
5. **withdrawals** - Withdrawal requests
6. **tasks** - Available tasks
7. **task_completions** - User task records
8. **notifications** - User notifications
9. **announcements** - Platform announcements
10. **audit_logs** - Admin action logging
11. **otp_codes** - OTP verification codes
12. **password_reset_tokens** - Password reset tokens

### Backup Database

```bash
# Backup
docker-compose exec postgres pg_dump -U postgres workminto > backup.sql

# Restore
docker-compose exec -T postgres psql -U postgres workminto < backup.sql
```

---

## Production Deployment

### Option 1: Docker (Recommended)

#### 1. Build Docker Images

```bash
cd workminto-backend

# Build API image
docker build -t workminto-api:latest .

# Build frontend image (optional)
cd ../workminto
docker build -t workminto-frontend:latest .
```

#### 2. Push to Registry

```bash
# Tag images
docker tag workminto-api:latest your-registry/workminto-api:latest
docker tag workminto-frontend:latest your-registry/workminto-frontend:latest

# Push to Docker Hub or private registry
docker push your-registry/workminto-api:latest
docker push your-registry/workminto-frontend:latest
```

#### 3. Deploy to Cloud

**AWS ECS:**
```bash
# Create ECS cluster and task definitions
# Update docker-compose.yml for production
docker-compose -f docker-compose.prod.yml up
```

**DigitalOcean App Platform:**
```bash
# Connect GitHub repository
# Configure environment variables in UI
# Deploy automatically
```

**Heroku:**
```bash
# Create app
heroku create workminto-api

# Set environment variables
heroku config:set JWT_SECRET=your_secret_key
heroku config:set DATABASE_URL=your_postgres_url

# Deploy
git push heroku main
```

### Option 2: Traditional Server (VPS)

#### 1. SSH into Server

```bash
ssh root@your-server-ip
```

#### 2. Install Dependencies

```bash
# Update system
apt-get update && apt-get upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt-get install -y nodejs

# Install PostgreSQL
apt-get install -y postgresql postgresql-contrib

# Install Nginx (reverse proxy)
apt-get install -y nginx

# Install PM2 (process manager)
npm install -g pm2
```

#### 3. Clone Repository

```bash
cd /var/www
git clone https://github.com/yourusername/workminto.git
cd workminto-backend
```

#### 4. Setup Environment

```bash
# Install dependencies
npm install --production

# Create .env
cp .env.example .env

# Edit .env with production values
nano .env
```

#### 5. Setup Database

```bash
# Create database
sudo -u postgres createdb workminto

# Run migrations
npm run migrate

# Seed data
npm run seed
```

#### 6. Start API with PM2

```bash
# Start application
pm2 start src/index.js --name "workminto-api"

# Save PM2 configuration
pm2 save

# Enable startup on reboot
pm2 startup
```

#### 7. Configure Nginx

Create `/etc/nginx/sites-available/workminto`:

```nginx
upstream workminto_api {
    server localhost:3001;
}

server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://workminto_api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable site:
```bash
ln -s /etc/nginx/sites-available/workminto /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

#### 8. Setup SSL with Let's Encrypt

```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d api.yourdomain.com
```

---

## Environment Variables

### Backend (.env)

```env
# Server
NODE_ENV=production
PORT=3001
API_URL=https://api.yourdomain.com

# Database
DB_HOST=db.yourdomain.com
DB_PORT=5432
DB_NAME=workminto
DB_USER=postgres
DB_PASSWORD=your_secure_password

# JWT
JWT_SECRET=your_super_secret_jwt_key_change_this
JWT_EXPIRE=7d
JWT_REFRESH_SECRET=your_super_secret_refresh_key_change_this
JWT_REFRESH_EXPIRE=30d

# Email
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your_sendgrid_api_key
SMTP_FROM=noreply@workminto.com

# Frontend
FRONTEND_URL=https://workminto.com

# Admin
ADMIN_EMAIL=admin@workminto.com
```

### Frontend (.env)

```env
VITE_API_URL=https://api.yourdomain.com/api
```

---

## API Endpoints

### Authentication

```
POST /api/auth/signup
POST /api/auth/login
POST /api/auth/refresh-token
POST /api/auth/send-otp
POST /api/auth/verify-otp
POST /api/auth/forgot-password
POST /api/auth/reset-password
POST /api/auth/logout
```

### Wallet

```
GET /api/wallet
GET /api/wallet/transactions
POST /api/wallet/add-points
POST /api/wallet/deduct-points
```

### Referrals

```
GET /api/referrals/stats
GET /api/referrals/history
POST /api/referrals/validate-code
POST /api/referrals/award-bonus
```

### Withdrawals

```
POST /api/withdrawals
GET /api/withdrawals
GET /api/withdrawals/:id
POST /api/admin/withdrawals/:id/approve
POST /api/admin/withdrawals/:id/reject
```

### Admin

```
GET /api/admin/dashboard/stats
GET /api/admin/users
GET /api/admin/users/:id
POST /api/admin/users/:id/suspend
POST /api/admin/users/:id/ban
GET /api/admin/tasks
POST /api/admin/tasks
PUT /api/admin/tasks/:id
DELETE /api/admin/tasks/:id
GET /api/admin/announcements
POST /api/admin/announcements
GET /api/admin/audit-logs
```

---

## Testing

### Test Authentication

```bash
# Signup
curl -X POST http://localhost:3001/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "SecurePass123!",
    "first_name": "Test",
    "last_name": "User"
  }'

# Login
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "SecurePass123!"
  }'

# Get Wallet (requires token)
curl -X GET http://localhost:3001/api/wallet \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### Test with Postman

1. Import API collection (included in backend)
2. Set environment variables
3. Run tests

---

## Monitoring & Logging

### Docker Logs

```bash
# API logs
docker-compose logs -f api

# Database logs
docker-compose logs -f postgres

# All logs
docker-compose logs -f
```

### PM2 Monitoring

```bash
# View logs
pm2 logs workminto-api

# Monitor in real-time
pm2 monit

# View status
pm2 status
```

### Application Logs

Logs are written to `.manus-logs/` directory:
- `devserver.log` - Server startup and runtime
- `browserConsole.log` - Frontend errors
- `networkRequests.log` - API requests
- `sessionReplay.log` - User interactions

---

## Security Checklist

- [ ] Change JWT_SECRET and JWT_REFRESH_SECRET
- [ ] Use strong database password
- [ ] Enable HTTPS/SSL
- [ ] Configure CORS for your domain
- [ ] Set up firewall rules
- [ ] Enable database backups
- [ ] Configure email service (SendGrid, AWS SES)
- [ ] Set up monitoring and alerts
- [ ] Enable rate limiting
- [ ] Regular security updates

---

## Troubleshooting

### API won't start

```bash
# Check if port 3001 is in use
lsof -i :3001

# Check logs
docker-compose logs api

# Restart
docker-compose restart api
```

### Database connection error

```bash
# Check PostgreSQL status
docker-compose ps

# Check database exists
docker-compose exec postgres psql -U postgres -l

# Recreate database
docker-compose exec postgres psql -U postgres -c "DROP DATABASE workminto;"
docker-compose exec postgres psql -U postgres -c "CREATE DATABASE workminto;"
docker-compose exec api npm run migrate
```

### Frontend can't connect to API

1. Check API URL in frontend .env
2. Verify CORS configuration
3. Check network tab in browser DevTools
4. Ensure API is running: `curl http://localhost:3001/health`

---

## Scaling

### Horizontal Scaling

```bash
# Use load balancer (Nginx, HAProxy)
# Run multiple API instances
docker-compose up -d --scale api=3

# Use database replication
# Configure read replicas for PostgreSQL
```

### Vertical Scaling

```bash
# Increase server resources
# Update docker-compose.yml with resource limits
# Optimize database queries
# Enable caching (Redis)
```

---

## Backup & Recovery

### Automated Backups

```bash
# Create backup script
#!/bin/bash
BACKUP_DIR="/backups/workminto"
DATE=$(date +%Y%m%d_%H%M%S)
docker-compose exec -T postgres pg_dump -U postgres workminto > $BACKUP_DIR/backup_$DATE.sql
gzip $BACKUP_DIR/backup_$DATE.sql

# Schedule with cron
0 2 * * * /path/to/backup.sh
```

### Restore from Backup

```bash
gunzip backup_20240620_020000.sql.gz
docker-compose exec -T postgres psql -U postgres workminto < backup_20240620_020000.sql
```

---

## Support

For issues or questions:
- Check logs: `docker-compose logs`
- Review documentation in `/home/ubuntu/workminto/`
- Contact support: support@workminto.com

---

## Next Steps

1. ✅ Backend deployed
2. ✅ Frontend connected
3. [ ] Configure email service
4. [ ] Set up payment processing
5. [ ] Configure offerwall integrations
6. [ ] Set up monitoring
7. [ ] Launch to production

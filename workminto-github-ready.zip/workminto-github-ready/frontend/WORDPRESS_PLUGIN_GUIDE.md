# WordPress Custom Plugin Development Guide for Workminto

## Overview

This guide explains how to build the custom WordPress plugin for Workminto's core features (wallet, points, referrals, withdrawals).

**Plugin Name:** `workminto-core`

**What This Plugin Does:**
- Manages user wallet and points
- Tracks task completions and rewards
- Handles referral system
- Manages withdrawal requests
- Provides REST API endpoints for React app

---

## Part 1: Plugin Structure

### File Organization

```
/wp-content/plugins/workminto-core/
├── workminto-core.php          (Main plugin file)
├── includes/
│   ├── class-wallet.php        (Wallet management)
│   ├── class-referral.php      (Referral system)
│   ├── class-withdrawal.php    (Withdrawal management)
│   ├── class-task.php          (Task tracking)
│   └── class-api.php           (REST API endpoints)
├── admin/
│   ├── admin-menu.php          (Admin dashboard)
│   ├── withdrawal-dashboard.php (Withdrawal approval)
│   └── user-dashboard.php      (User management)
├── database/
│   └── schema.sql              (Database tables)
└── readme.txt                  (Plugin info)
```

---

## Part 2: Main Plugin File

### workminto-core.php

```php
<?php
/**
 * Plugin Name: Workminto Core
 * Plugin URI: https://workminto.com
 * Description: Core functionality for Workminto rewards platform
 * Version: 1.0.0
 * Author: Workminto Team
 * License: GPL v2 or later
 * Text Domain: workminto-core
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin constants
define( 'WORKMINTO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WORKMINTO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WORKMINTO_VERSION', '1.0.0' );

// Include required files
require_once WORKMINTO_PLUGIN_DIR . 'includes/class-wallet.php';
require_once WORKMINTO_PLUGIN_DIR . 'includes/class-referral.php';
require_once WORKMINTO_PLUGIN_DIR . 'includes/class-withdrawal.php';
require_once WORKMINTO_PLUGIN_DIR . 'includes/class-task.php';
require_once WORKMINTO_PLUGIN_DIR . 'includes/class-api.php';
require_once WORKMINTO_PLUGIN_DIR . 'admin/admin-menu.php';

// Activation hook - Create database tables
register_activation_hook( __FILE__, 'workminto_activate' );

function workminto_activate() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // Wallets table
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}workminto_wallets (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            total_points BIGINT(20) DEFAULT 0,
            available_points BIGINT(20) DEFAULT 0,
            pending_points BIGINT(20) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id)
        ) $charset_collate;
    " );
    
    // Wallet transactions table
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}workminto_transactions (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            type VARCHAR(50) NOT NULL,
            amount BIGINT(20) NOT NULL,
            description VARCHAR(255),
            reference_id VARCHAR(100),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset_collate;
    " );
    
    // Referrals table
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}workminto_referrals (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            referrer_id BIGINT(20) UNSIGNED NOT NULL,
            referred_user_id BIGINT(20) UNSIGNED NOT NULL,
            referral_code VARCHAR(20) UNIQUE NOT NULL,
            status VARCHAR(50) DEFAULT 'pending',
            bonus_points BIGINT(20) DEFAULT 200,
            bonus_awarded BOOLEAN DEFAULT FALSE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY referrer_id (referrer_id),
            KEY referred_user_id (referred_user_id),
            UNIQUE KEY referral_code (referral_code)
        ) $charset_collate;
    " );
    
    // Withdrawals table
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}workminto_withdrawals (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            amount_points BIGINT(20) NOT NULL,
            amount_currency DECIMAL(10, 2),
            method VARCHAR(50) NOT NULL,
            payment_details LONGTEXT,
            status VARCHAR(50) DEFAULT 'pending',
            requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            processed_at DATETIME,
            admin_notes TEXT,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY status (status),
            KEY requested_at (requested_at)
        ) $charset_collate;
    " );
    
    // Task completions table
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}workminto_task_completions (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            task_id BIGINT(20) UNSIGNED NOT NULL,
            status VARCHAR(50) DEFAULT 'pending',
            points_awarded BIGINT(20) DEFAULT 0,
            completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY task_id (task_id),
            KEY status (status)
        ) $charset_collate;
    " );
    
    // OTP codes table
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$wpdb->prefix}workminto_otp_codes (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            email VARCHAR(100),
            code VARCHAR(6),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME,
            verified BOOLEAN DEFAULT FALSE,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY email (email),
            KEY expires_at (expires_at)
        ) $charset_collate;
    " );
}

// Initialize plugin
add_action( 'plugins_loaded', 'workminto_init' );

function workminto_init() {
    // Initialize classes
    Workminto_Wallet::init();
    Workminto_Referral::init();
    Workminto_Withdrawal::init();
    Workminto_Task::init();
    Workminto_API::init();
}

// Deactivation hook
register_deactivation_hook( __FILE__, 'workminto_deactivate' );

function workminto_deactivate() {
    // Cleanup if needed
}
```

---

## Part 3: Wallet Class

### includes/class-wallet.php

```php
<?php

class Workminto_Wallet {
    
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }
    
    /**
     * Get user wallet
     */
    public static function get_wallet( $user_id ) {
        global $wpdb;
        
        $wallet = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_wallets WHERE user_id = %d",
            $user_id
        ) );
        
        if ( ! $wallet ) {
            // Create wallet if doesn't exist
            $wpdb->insert(
                "{$wpdb->prefix}workminto_wallets",
                array(
                    'user_id' => $user_id,
                    'total_points' => 0,
                    'available_points' => 0,
                    'pending_points' => 0,
                )
            );
            
            $wallet = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}workminto_wallets WHERE user_id = %d",
                $user_id
            ) );
        }
        
        return $wallet;
    }
    
    /**
     * Add points to wallet
     */
    public static function add_points( $user_id, $points, $type, $description, $reference_id = null ) {
        global $wpdb;
        
        $wallet = self::get_wallet( $user_id );
        
        // Update wallet
        $wpdb->update(
            "{$wpdb->prefix}workminto_wallets",
            array(
                'total_points' => $wallet->total_points + $points,
                'available_points' => $wallet->available_points + $points,
            ),
            array( 'user_id' => $user_id )
        );
        
        // Record transaction
        $wpdb->insert(
            "{$wpdb->prefix}workminto_transactions",
            array(
                'user_id' => $user_id,
                'type' => $type,
                'amount' => $points,
                'description' => $description,
                'reference_id' => $reference_id,
            )
        );
        
        // Send notification email
        self::send_points_email( $user_id, $points, $description );
        
        return true;
    }
    
    /**
     * Deduct points from wallet
     */
    public static function deduct_points( $user_id, $points, $reason ) {
        global $wpdb;
        
        $wallet = self::get_wallet( $user_id );
        
        if ( $wallet->available_points < $points ) {
            return new WP_Error( 'insufficient_points', 'Insufficient points' );
        }
        
        // Update wallet
        $wpdb->update(
            "{$wpdb->prefix}workminto_wallets",
            array(
                'available_points' => $wallet->available_points - $points,
            ),
            array( 'user_id' => $user_id )
        );
        
        // Record transaction
        $wpdb->insert(
            "{$wpdb->prefix}workminto_transactions",
            array(
                'user_id' => $user_id,
                'type' => 'spent',
                'amount' => $points,
                'description' => $reason,
            )
        );
        
        return true;
    }
    
    /**
     * Get transaction history
     */
    public static function get_transactions( $user_id, $limit = 50, $offset = 0 ) {
        global $wpdb;
        
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_transactions 
             WHERE user_id = %d 
             ORDER BY created_at DESC 
             LIMIT %d OFFSET %d",
            $user_id,
            $limit,
            $offset
        ) );
    }
    
    /**
     * Send points earned email
     */
    private static function send_points_email( $user_id, $points, $description ) {
        $user = get_user_by( 'id', $user_id );
        
        $subject = "You earned {$points} points!";
        $message = "
            <h2>Points Earned!</h2>
            <p>You earned <strong>{$points} points</strong> from: {$description}</p>
            <p><a href='" . home_url( '/app/wallet' ) . "'>View your wallet</a></p>
        ";
        
        wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/html; charset=UTF-8' ) );
    }
    
    /**
     * Register REST API routes
     */
    public static function register_routes() {
        register_rest_route( 'workminto/v1', '/wallet', array(
            'methods' => 'GET',
            'callback' => array( __CLASS__, 'get_wallet_rest' ),
            'permission_callback' => array( __CLASS__, 'check_permission' ),
        ) );
        
        register_rest_route( 'workminto/v1', '/wallet/transactions', array(
            'methods' => 'GET',
            'callback' => array( __CLASS__, 'get_transactions_rest' ),
            'permission_callback' => array( __CLASS__, 'check_permission' ),
        ) );
    }
    
    /**
     * REST API: Get wallet
     */
    public static function get_wallet_rest( $request ) {
        $user_id = get_current_user_id();
        $wallet = self::get_wallet( $user_id );
        
        return rest_ensure_response( $wallet );
    }
    
    /**
     * REST API: Get transactions
     */
    public static function get_transactions_rest( $request ) {
        $user_id = get_current_user_id();
        $limit = $request->get_param( 'limit' ) ?: 50;
        $offset = $request->get_param( 'offset' ) ?: 0;
        
        $transactions = self::get_transactions( $user_id, $limit, $offset );
        
        return rest_ensure_response( $transactions );
    }
    
    /**
     * Check permission
     */
    public static function check_permission( $request ) {
        return is_user_logged_in();
    }
}
```

---

## Part 4: Referral Class

### includes/class-referral.php

```php
<?php

class Workminto_Referral {
    
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
        add_action( 'user_register', array( __CLASS__, 'handle_referral_signup' ) );
    }
    
    /**
     * Generate referral code
     */
    public static function generate_referral_code( $user_id ) {
        global $wpdb;
        
        $user = get_user_by( 'id', $user_id );
        $code = strtoupper( substr( $user->user_login, 0, 4 ) . rand( 100, 999 ) );
        
        // Ensure unique
        while ( $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}workminto_referrals WHERE referral_code = %s",
            $code
        ) ) ) {
            $code = strtoupper( substr( $user->user_login, 0, 4 ) . rand( 100, 999 ) );
        }
        
        return $code;
    }
    
    /**
     * Handle referral signup
     */
    public static function handle_referral_signup( $user_id ) {
        global $wpdb;
        
        // Generate referral code for new user
        $referral_code = self::generate_referral_code( $user_id );
        
        // Check if user was referred
        $referrer_code = isset( $_GET['ref'] ) ? sanitize_text_field( $_GET['ref'] ) : null;
        
        if ( $referrer_code ) {
            $referrer = $wpdb->get_row( $wpdb->prepare(
                "SELECT referrer_id FROM {$wpdb->prefix}workminto_referrals WHERE referral_code = %s",
                $referrer_code
            ) );
            
            if ( $referrer ) {
                // Create referral record
                $wpdb->insert(
                    "{$wpdb->prefix}workminto_referrals",
                    array(
                        'referrer_id' => $referrer->referrer_id,
                        'referred_user_id' => $user_id,
                        'referral_code' => $referral_code,
                        'status' => 'pending',
                    )
                );
            }
        } else {
            // Create referral record for new referrer
            $wpdb->insert(
                "{$wpdb->prefix}workminto_referrals",
                array(
                    'referrer_id' => $user_id,
                    'referred_user_id' => $user_id,
                    'referral_code' => $referral_code,
                    'status' => 'active',
                )
            );
        }
    }
    
    /**
     * Get referral stats
     */
    public static function get_referral_stats( $user_id ) {
        global $wpdb;
        
        $referral_code = $wpdb->get_var( $wpdb->prepare(
            "SELECT referral_code FROM {$wpdb->prefix}workminto_referrals WHERE referrer_id = %d LIMIT 1",
            $user_id
        ) );
        
        $total_referrals = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}workminto_referrals WHERE referrer_id = %d",
            $user_id
        ) );
        
        $active_referrals = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}workminto_referrals WHERE referrer_id = %d AND status = 'active'",
            $user_id
        ) );
        
        $total_bonus = $wpdb->get_var( $wpdb->prepare(
            "SELECT SUM(bonus_points) FROM {$wpdb->prefix}workminto_referrals WHERE referrer_id = %d AND bonus_awarded = TRUE",
            $user_id
        ) );
        
        return array(
            'referral_code' => $referral_code,
            'total_referrals' => $total_referrals,
            'active_referrals' => $active_referrals,
            'total_bonus_earned' => $total_bonus ?: 0,
            'referral_link' => home_url( '?ref=' . $referral_code ),
        );
    }
    
    /**
     * Award referral bonus
     */
    public static function award_referral_bonus( $referred_user_id ) {
        global $wpdb;
        
        $referral = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_referrals WHERE referred_user_id = %d AND bonus_awarded = FALSE",
            $referred_user_id
        ) );
        
        if ( $referral ) {
            // Award bonus to referrer
            Workminto_Wallet::add_points(
                $referral->referrer_id,
                $referral->bonus_points,
                'referral_bonus',
                'Referral bonus from ' . get_user_by( 'id', $referred_user_id )->user_login,
                'referral_' . $referral->id
            );
            
            // Mark bonus as awarded
            $wpdb->update(
                "{$wpdb->prefix}workminto_referrals",
                array( 'bonus_awarded' => TRUE, 'status' => 'completed' ),
                array( 'id' => $referral->id )
            );
        }
    }
    
    /**
     * Register REST API routes
     */
    public static function register_routes() {
        register_rest_route( 'workminto/v1', '/referrals/stats', array(
            'methods' => 'GET',
            'callback' => array( __CLASS__, 'get_stats_rest' ),
            'permission_callback' => array( __CLASS__, 'check_permission' ),
        ) );
    }
    
    /**
     * REST API: Get referral stats
     */
    public static function get_stats_rest( $request ) {
        $user_id = get_current_user_id();
        $stats = self::get_referral_stats( $user_id );
        
        return rest_ensure_response( $stats );
    }
    
    /**
     * Check permission
     */
    public static function check_permission( $request ) {
        return is_user_logged_in();
    }
}
```

---

## Part 5: Withdrawal Class

### includes/class-withdrawal.php

```php
<?php

class Workminto_Withdrawal {
    
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }
    
    /**
     * Create withdrawal request
     */
    public static function create_withdrawal( $user_id, $amount_points, $method, $payment_details ) {
        global $wpdb;
        
        // Validate points
        $wallet = Workminto_Wallet::get_wallet( $user_id );
        
        if ( $wallet->available_points < $amount_points ) {
            return new WP_Error( 'insufficient_points', 'Insufficient points' );
        }
        
        // Minimum withdrawal
        if ( $amount_points < 500 ) {
            return new WP_Error( 'minimum_withdrawal', 'Minimum withdrawal is 500 points' );
        }
        
        // Deduct points (move to pending)
        $wpdb->update(
            "{$wpdb->prefix}workminto_wallets",
            array(
                'available_points' => $wallet->available_points - $amount_points,
                'pending_points' => $wallet->pending_points + $amount_points,
            ),
            array( 'user_id' => $user_id )
        );
        
        // Create withdrawal request
        $wpdb->insert(
            "{$wpdb->prefix}workminto_withdrawals",
            array(
                'user_id' => $user_id,
                'amount_points' => $amount_points,
                'amount_currency' => $amount_points / 100, // 1 point = $0.01
                'method' => $method,
                'payment_details' => json_encode( $payment_details ),
                'status' => 'pending',
            )
        );
        
        $withdrawal_id = $wpdb->insert_id;
        
        // Send email to user
        self::send_withdrawal_email( $user_id, $withdrawal_id );
        
        // Notify admin
        self::notify_admin_withdrawal( $withdrawal_id );
        
        return $withdrawal_id;
    }
    
    /**
     * Get withdrawal requests
     */
    public static function get_withdrawals( $user_id, $limit = 20, $offset = 0 ) {
        global $wpdb;
        
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_withdrawals 
             WHERE user_id = %d 
             ORDER BY requested_at DESC 
             LIMIT %d OFFSET %d",
            $user_id,
            $limit,
            $offset
        ) );
    }
    
    /**
     * Approve withdrawal (admin only)
     */
    public static function approve_withdrawal( $withdrawal_id, $admin_notes = '' ) {
        global $wpdb;
        
        $withdrawal = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_withdrawals WHERE id = %d",
            $withdrawal_id
        ) );
        
        if ( ! $withdrawal ) {
            return new WP_Error( 'not_found', 'Withdrawal not found' );
        }
        
        // Update withdrawal status
        $wpdb->update(
            "{$wpdb->prefix}workminto_withdrawals",
            array(
                'status' => 'approved',
                'admin_notes' => $admin_notes,
                'processed_at' => current_time( 'mysql' ),
            ),
            array( 'id' => $withdrawal_id )
        );
        
        // Send email to user
        self::send_approval_email( $withdrawal->user_id, $withdrawal_id );
        
        return true;
    }
    
    /**
     * Reject withdrawal (admin only)
     */
    public static function reject_withdrawal( $withdrawal_id, $reason = '' ) {
        global $wpdb;
        
        $withdrawal = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_withdrawals WHERE id = %d",
            $withdrawal_id
        ) );
        
        if ( ! $withdrawal ) {
            return new WP_Error( 'not_found', 'Withdrawal not found' );
        }
        
        // Return points to available
        $wallet = Workminto_Wallet::get_wallet( $withdrawal->user_id );
        
        $wpdb->update(
            "{$wpdb->prefix}workminto_wallets",
            array(
                'available_points' => $wallet->available_points + $withdrawal->amount_points,
                'pending_points' => $wallet->pending_points - $withdrawal->amount_points,
            ),
            array( 'user_id' => $withdrawal->user_id )
        );
        
        // Update withdrawal status
        $wpdb->update(
            "{$wpdb->prefix}workminto_withdrawals",
            array(
                'status' => 'rejected',
                'admin_notes' => $reason,
                'processed_at' => current_time( 'mysql' ),
            ),
            array( 'id' => $withdrawal_id )
        );
        
        // Send email to user
        self::send_rejection_email( $withdrawal->user_id, $withdrawal_id, $reason );
        
        return true;
    }
    
    /**
     * Send withdrawal confirmation email
     */
    private static function send_withdrawal_email( $user_id, $withdrawal_id ) {
        $user = get_user_by( 'id', $user_id );
        $withdrawal = self::get_withdrawal( $withdrawal_id );
        
        $subject = "Withdrawal Request Submitted";
        $message = "
            <h2>Withdrawal Request Submitted</h2>
            <p>Your withdrawal request of <strong>{$withdrawal->amount_points} points</strong> has been submitted.</p>
            <p>Status: Pending Review</p>
            <p>We'll review your request and process it within 24 hours.</p>
        ";
        
        wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/html; charset=UTF-8' ) );
    }
    
    /**
     * Send approval email
     */
    private static function send_approval_email( $user_id, $withdrawal_id ) {
        $user = get_user_by( 'id', $user_id );
        $withdrawal = self::get_withdrawal( $withdrawal_id );
        
        $subject = "Withdrawal Approved!";
        $message = "
            <h2>Withdrawal Approved!</h2>
            <p>Your withdrawal request of <strong>{$withdrawal->amount_points} points</strong> has been approved.</p>
            <p>Amount: \${$withdrawal->amount_currency}</p>
            <p>You'll receive the payment within 1-3 business days.</p>
        ";
        
        wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/html; charset=UTF-8' ) );
    }
    
    /**
     * Send rejection email
     */
    private static function send_rejection_email( $user_id, $withdrawal_id, $reason ) {
        $user = get_user_by( 'id', $user_id );
        $withdrawal = self::get_withdrawal( $withdrawal_id );
        
        $subject = "Withdrawal Request Rejected";
        $message = "
            <h2>Withdrawal Request Rejected</h2>
            <p>Your withdrawal request of <strong>{$withdrawal->amount_points} points</strong> has been rejected.</p>
            <p>Reason: {$reason}</p>
            <p>Your points have been returned to your wallet.</p>
        ";
        
        wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/html; charset=UTF-8' ) );
    }
    
    /**
     * Notify admin of new withdrawal
     */
    private static function notify_admin_withdrawal( $withdrawal_id ) {
        $admin_email = get_option( 'admin_email' );
        $withdrawal = self::get_withdrawal( $withdrawal_id );
        $user = get_user_by( 'id', $withdrawal->user_id );
        
        $subject = "New Withdrawal Request - Requires Approval";
        $message = "
            <h2>New Withdrawal Request</h2>
            <p>User: {$user->user_login}</p>
            <p>Amount: {$withdrawal->amount_points} points (\${$withdrawal->amount_currency})</p>
            <p>Method: {$withdrawal->method}</p>
            <p><a href='" . admin_url( 'admin.php?page=workminto-withdrawals' ) . "'>Review in Admin</a></p>
        ";
        
        wp_mail( $admin_email, $subject, $message, array( 'Content-Type: text/html; charset=UTF-8' ) );
    }
    
    /**
     * Get single withdrawal
     */
    private static function get_withdrawal( $withdrawal_id ) {
        global $wpdb;
        
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}workminto_withdrawals WHERE id = %d",
            $withdrawal_id
        ) );
    }
    
    /**
     * Register REST API routes
     */
    public static function register_routes() {
        register_rest_route( 'workminto/v1', '/withdrawals', array(
            'methods' => 'POST',
            'callback' => array( __CLASS__, 'create_withdrawal_rest' ),
            'permission_callback' => array( __CLASS__, 'check_permission' ),
        ) );
        
        register_rest_route( 'workminto/v1', '/withdrawals', array(
            'methods' => 'GET',
            'callback' => array( __CLASS__, 'get_withdrawals_rest' ),
            'permission_callback' => array( __CLASS__, 'check_permission' ),
        ) );
    }
    
    /**
     * REST API: Create withdrawal
     */
    public static function create_withdrawal_rest( $request ) {
        $user_id = get_current_user_id();
        $amount_points = $request->get_param( 'amount_points' );
        $method = $request->get_param( 'method' );
        $payment_details = $request->get_param( 'payment_details' );
        
        $result = self::create_withdrawal( $user_id, $amount_points, $method, $payment_details );
        
        if ( is_wp_error( $result ) ) {
            return rest_ensure_response( $result );
        }
        
        return rest_ensure_response( array(
            'id' => $result,
            'status' => 'pending',
            'message' => 'Withdrawal request submitted',
        ) );
    }
    
    /**
     * REST API: Get withdrawals
     */
    public static function get_withdrawals_rest( $request ) {
        $user_id = get_current_user_id();
        $limit = $request->get_param( 'limit' ) ?: 20;
        $offset = $request->get_param( 'offset' ) ?: 0;
        
        $withdrawals = self::get_withdrawals( $user_id, $limit, $offset );
        
        return rest_ensure_response( $withdrawals );
    }
    
    /**
     * Check permission
     */
    public static function check_permission( $request ) {
        return is_user_logged_in();
    }
}
```

---

## Part 6: How to Install This Plugin

### Step 1: Create Plugin Directory

```bash
cd /wp-content/plugins/
mkdir workminto-core
cd workminto-core
```

### Step 2: Create Files

Create the files listed in the plugin structure above with the code provided.

### Step 3: Upload to WordPress

1. Go to WordPress Admin → Plugins
2. Click "Add New"
3. Click "Upload Plugin"
4. Select the plugin ZIP file
5. Click "Install Now"
6. Click "Activate"

### Step 4: Verify Installation

1. Check that database tables were created
2. Test REST API endpoints:
   ```
   GET /wp-json/workminto/v1/wallet
   GET /wp-json/workminto/v1/wallet/transactions
   GET /wp-json/workminto/v1/referrals/stats
   POST /wp-json/workminto/v1/withdrawals
   ```

---

## Part 7: Testing the Plugin

### Test User Registration

```bash
curl -X POST http://localhost/wp-json/wp/v2/users \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "TestPassword123!"
  }'
```

### Test Get Wallet

```bash
curl -X GET http://localhost/wp-json/workminto/v1/wallet \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Test Add Points

```bash
curl -X POST http://localhost/wp-json/workminto/v1/wallet/add-points \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "points": 50,
    "type": "task_completed",
    "description": "Completed Daily Check-in"
  }'
```

---

## Summary

This custom WordPress plugin provides:

✅ User wallet management  
✅ Points system  
✅ Referral tracking  
✅ Withdrawal requests  
✅ Email notifications  
✅ REST API endpoints  
✅ Admin approval workflow  

**Total Lines of Code:** ~800 lines  
**Estimated Development Time:** 20-30 hours  
**Estimated Cost to Hire:** $500-1,500

---

**Next Steps:**

1. Create the plugin files
2. Upload to WordPress
3. Activate the plugin
4. Test all endpoints
5. Connect React app to WordPress API
6. Launch!

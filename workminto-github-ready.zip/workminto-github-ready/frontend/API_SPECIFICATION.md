# Workminto API Specification

## Base URL
```
https://api.workminto.com/v1
```

---

## Authentication

### Bearer Token
All authenticated endpoints require:
```
Authorization: Bearer <jwt_token>
```

### JWT Payload
```json
{
  "sub": "user_id",
  "email": "user@example.com",
  "role": "user",
  "iat": 1234567890,
  "exp": 1234571490
}
```

---

## Auth Endpoints

### 1. Sign Up
```
POST /auth/signup
Content-Type: application/json

Request:
{
  "email": "user@example.com",
  "password": "SecurePassword123!",
  "first_name": "John",
  "last_name": "Doe",
  "referral_code": "WORKMINTO25" (optional)
}

Response: 201 Created
{
  "id": "uuid",
  "email": "user@example.com",
  "first_name": "John",
  "status": "pending_verification",
  "referral_code": "JOHN123",
  "created_at": "2024-06-20T10:00:00Z"
}
```

### 2. Login
```
POST /auth/login
Content-Type: application/json

Request:
{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}

Response: 200 OK
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "first_name": "John",
    "status": "active",
    "level": 5
  }
}
```

### 3. Verify Email OTP
```
POST /auth/verify-otp
Content-Type: application/json
Authorization: Bearer <token>

Request:
{
  "otp": "123456"
}

Response: 200 OK
{
  "email_verified": true,
  "status": "active"
}
```

### 4. Forgot Password
```
POST /auth/forgot-password
Content-Type: application/json

Request:
{
  "email": "user@example.com"
}

Response: 200 OK
{
  "message": "Password reset link sent to email"
}
```

### 5. Reset Password
```
POST /auth/reset-password
Content-Type: application/json

Request:
{
  "reset_token": "token_from_email",
  "new_password": "NewPassword123!"
}

Response: 200 OK
{
  "message": "Password reset successfully"
}
```

---

## Task Endpoints

### 1. Get Available Tasks
```
GET /tasks?category=daily_checkin&limit=20&offset=0
Authorization: Bearer <token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "title": "Daily Check-in",
      "description": "Check in daily to earn points",
      "category": "daily_checkin",
      "reward_points": 50,
      "max_completions_per_user": 1,
      "status": "active",
      "user_completed": false,
      "user_completion_count": 0
    }
  ],
  "pagination": {
    "total": 45,
    "limit": 20,
    "offset": 0
  }
}
```

### 2. Get Task Details
```
GET /tasks/:task_id
Authorization: Bearer <token>

Response: 200 OK
{
  "id": "uuid",
  "title": "Daily Check-in",
  "description": "Check in daily to earn points",
  "category": "daily_checkin",
  "reward_points": 50,
  "instructions": "Click the button below to complete",
  "user_completed_today": false,
  "completions_remaining_today": 1
}
```

### 3. Complete Task
```
POST /tasks/:task_id/complete
Content-Type: application/json
Authorization: Bearer <token>

Request:
{
  "completion_proof": "base64_encoded_screenshot_or_form_data"
}

Response: 201 Created
{
  "task_completion_id": "uuid",
  "status": "pending",
  "message": "Task submitted for review. You'll receive points once approved."
}

OR (auto-approved):
{
  "task_completion_id": "uuid",
  "status": "approved",
  "points_awarded": 50,
  "message": "Task completed! You earned 50 points."
}
```

### 4. Get User Task Completions
```
GET /tasks/completions?status=approved&limit=20
Authorization: Bearer <token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "task_id": "uuid",
      "task_title": "Daily Check-in",
      "status": "approved",
      "points_awarded": 50,
      "completed_at": "2024-06-20T10:00:00Z"
    }
  ],
  "pagination": {
    "total": 125,
    "limit": 20
  }
}
```

---

## Wallet Endpoints

### 1. Get Wallet Balance
```
GET /wallet
Authorization: Bearer <token>

Response: 200 OK
{
  "user_id": "uuid",
  "total_points": 5250,
  "available_points": 5000,
  "pending_points": 250,
  "spent_points": 0,
  "level": 12,
  "next_level_points_needed": 500
}
```

### 2. Get Transaction History
```
GET /wallet/transactions?type=earned&limit=50&offset=0
Authorization: Bearer <token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "type": "earned",
      "amount": 50,
      "description": "Completed Daily Check-in",
      "reference_id": "task_completion_uuid",
      "created_at": "2024-06-20T10:00:00Z"
    },
    {
      "id": "uuid",
      "type": "bonus",
      "amount": 200,
      "description": "Referral bonus from John Doe",
      "reference_id": "referral_uuid",
      "created_at": "2024-06-19T15:30:00Z"
    }
  ],
  "pagination": {
    "total": 342,
    "limit": 50
  }
}
```

---

## Withdrawal Endpoints

### 1. Request Withdrawal
```
POST /withdrawals
Content-Type: application/json
Authorization: Bearer <token>

Request:
{
  "amount_points": 1000,
  "withdrawal_method": "paypal",
  "withdrawal_details": {
    "email": "user@example.com"
  }
}

Response: 201 Created
{
  "id": "uuid",
  "amount_points": 1000,
  "amount_currency": 10.00,
  "withdrawal_method": "paypal",
  "status": "pending",
  "requested_at": "2024-06-20T10:00:00Z",
  "message": "Withdrawal request submitted. Admin will review within 24 hours."
}
```

### 2. Get Withdrawal History
```
GET /withdrawals?status=completed&limit=20
Authorization: Bearer <token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "amount_points": 1000,
      "amount_currency": 10.00,
      "withdrawal_method": "paypal",
      "status": "completed",
      "requested_at": "2024-06-20T10:00:00Z",
      "processed_at": "2024-06-21T14:30:00Z"
    }
  ],
  "pagination": {
    "total": 5,
    "limit": 20
  }
}
```

### 3. Get Withdrawal Details
```
GET /withdrawals/:withdrawal_id
Authorization: Bearer <token>

Response: 200 OK
{
  "id": "uuid",
  "amount_points": 1000,
  "amount_currency": 10.00,
  "withdrawal_method": "paypal",
  "status": "pending",
  "requested_at": "2024-06-20T10:00:00Z",
  "estimated_completion": "2024-06-22T10:00:00Z"
}
```

---

## Referral Endpoints

### 1. Get Referral Stats
```
GET /referrals/stats
Authorization: Bearer <token>

Response: 200 OK
{
  "referral_code": "JOHN123",
  "total_referrals": 5,
  "active_referrals": 4,
  "completed_first_task": 3,
  "total_bonus_earned": 600,
  "referral_link": "https://workminto.com?ref=JOHN123"
}
```

### 2. Get Referral History
```
GET /referrals/history?limit=20
Authorization: Bearer <token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "referred_user": {
        "id": "uuid",
        "name": "Jane Smith",
        "email": "jane@example.com"
      },
      "status": "active",
      "bonus_awarded": true,
      "bonus_points": 200,
      "referred_at": "2024-06-15T10:00:00Z"
    }
  ],
  "pagination": {
    "total": 5,
    "limit": 20
  }
}
```

---

## User Profile Endpoints

### 1. Get Profile
```
GET /profile
Authorization: Bearer <token>

Response: 200 OK
{
  "id": "uuid",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1234567890",
  "date_of_birth": "1990-01-15",
  "country": "United States",
  "profile_picture_url": "https://...",
  "level": 12,
  "total_points_earned": 5250,
  "total_points_spent": 0,
  "created_at": "2024-01-10T10:00:00Z"
}
```

### 2. Update Profile
```
PUT /profile
Content-Type: application/json
Authorization: Bearer <token>

Request:
{
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1234567890",
  "date_of_birth": "1990-01-15",
  "country": "United States"
}

Response: 200 OK
{
  "message": "Profile updated successfully"
}
```

### 3. Enable Two-Factor Authentication
```
POST /profile/2fa/enable
Authorization: Bearer <token>

Response: 200 OK
{
  "secret": "JBSWY3DPEBLW64TMMQ======",
  "qr_code": "data:image/png;base64,...",
  "backup_codes": ["code1", "code2", ...]
}
```

### 4. Verify Two-Factor Authentication
```
POST /profile/2fa/verify
Content-Type: application/json
Authorization: Bearer <token>

Request:
{
  "code": "123456"
}

Response: 200 OK
{
  "two_factor_enabled": true
}
```

---

## Notification Endpoints

### 1. Get Notifications
```
GET /notifications?is_read=false&limit=20
Authorization: Bearer <token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "type": "points_earned",
      "title": "Points Earned!",
      "message": "You earned 50 points from Daily Check-in",
      "action_url": "/app/tasks/daily-checkin",
      "is_read": false,
      "created_at": "2024-06-20T10:00:00Z"
    }
  ],
  "unread_count": 3,
  "pagination": {
    "total": 45,
    "limit": 20
  }
}
```

### 2. Mark Notification as Read
```
PUT /notifications/:notification_id/read
Authorization: Bearer <token>

Response: 200 OK
{
  "is_read": true
}
```

### 3. Mark All as Read
```
PUT /notifications/read-all
Authorization: Bearer <token>

Response: 200 OK
{
  "message": "All notifications marked as read"
}
```

---

## Admin Endpoints

### 1. Get Pending Withdrawals
```
GET /admin/withdrawals?status=pending&limit=20
Authorization: Bearer <admin_token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "user": {
        "id": "uuid",
        "name": "John Doe",
        "email": "john@example.com",
        "account_age_days": 45,
        "total_tasks_completed": 12
      },
      "amount_points": 1000,
      "amount_currency": 10.00,
      "withdrawal_method": "paypal",
      "requested_at": "2024-06-20T10:00:00Z"
    }
  ],
  "pagination": {
    "total": 5,
    "limit": 20
  }
}
```

### 2. Approve Withdrawal
```
POST /admin/withdrawals/:withdrawal_id/approve
Content-Type: application/json
Authorization: Bearer <admin_token>

Request:
{
  "notes": "Verified user, legitimate request"
}

Response: 200 OK
{
  "id": "uuid",
  "status": "approved",
  "approved_at": "2024-06-20T11:00:00Z"
}
```

### 3. Reject Withdrawal
```
POST /admin/withdrawals/:withdrawal_id/reject
Content-Type: application/json
Authorization: Bearer <admin_token>

Request:
{
  "rejection_reason": "Account flagged for suspicious activity"
}

Response: 200 OK
{
  "id": "uuid",
  "status": "rejected",
  "rejection_reason": "Account flagged for suspicious activity",
  "rejected_at": "2024-06-20T11:00:00Z"
}
```

### 4. Get Users
```
GET /admin/users?status=active&limit=50
Authorization: Bearer <admin_token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "email": "user@example.com",
      "name": "John Doe",
      "status": "active",
      "level": 12,
      "total_points_earned": 5250,
      "created_at": "2024-01-10T10:00:00Z"
    }
  ],
  "pagination": {
    "total": 12543,
    "limit": 50
  }
}
```

### 5. Suspend User
```
POST /admin/users/:user_id/suspend
Content-Type: application/json
Authorization: Bearer <admin_token>

Request:
{
  "reason": "Suspicious activity detected"
}

Response: 200 OK
{
  "id": "uuid",
  "status": "suspended",
  "suspended_at": "2024-06-20T11:00:00Z"
}
```

### 6. Ban User
```
POST /admin/users/:user_id/ban
Content-Type: application/json
Authorization: Bearer <admin_token>

Request:
{
  "reason": "Fraudulent activity confirmed"
}

Response: 200 OK
{
  "id": "uuid",
  "status": "banned",
  "banned_at": "2024-06-20T11:00:00Z"
}
```

### 7. Get Audit Logs
```
GET /admin/audit-logs?action_type=approve_withdrawal&limit=50
Authorization: Bearer <admin_token>

Response: 200 OK
{
  "data": [
    {
      "id": "uuid",
      "admin": {
        "id": "uuid",
        "name": "Admin Sarah"
      },
      "action_type": "approve_withdrawal",
      "target_entity_type": "withdrawal",
      "target_entity_id": "uuid",
      "changes": {
        "status": "pending → approved"
      },
      "created_at": "2024-06-20T11:00:00Z"
    }
  ],
  "pagination": {
    "total": 1245,
    "limit": 50
  }
}
```

### 8. Create Announcement
```
POST /admin/announcements
Content-Type: application/json
Authorization: Bearer <admin_token>

Request:
{
  "title": "New Tasks Available",
  "content": "Check out our new survey tasks!",
  "type": "info",
  "target_audience": "all_users",
  "status": "published"
}

Response: 201 Created
{
  "id": "uuid",
  "title": "New Tasks Available",
  "status": "published",
  "published_at": "2024-06-20T11:00:00Z"
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "bad_request",
  "message": "Invalid request parameters",
  "details": {
    "amount_points": "Must be greater than 500"
  }
}
```

### 401 Unauthorized
```json
{
  "error": "unauthorized",
  "message": "Missing or invalid authentication token"
}
```

### 403 Forbidden
```json
{
  "error": "forbidden",
  "message": "You do not have permission to access this resource"
}
```

### 404 Not Found
```json
{
  "error": "not_found",
  "message": "Resource not found"
}
```

### 429 Too Many Requests
```json
{
  "error": "rate_limit_exceeded",
  "message": "Too many requests. Please try again later.",
  "retry_after": 60
}
```

### 500 Internal Server Error
```json
{
  "error": "internal_server_error",
  "message": "An unexpected error occurred. Please try again later."
}
```

---

## Rate Limiting

- **Default**: 100 requests per minute per user
- **Withdrawal Requests**: 5 per day per user
- **Task Completions**: 20 per day per user
- **Admin Actions**: 1000 per hour per admin

Headers:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Reset: 1624176060
```

---

## Webhooks (Future)

### Withdrawal Completed
```
POST https://your-domain.com/webhooks/withdrawal-completed
Content-Type: application/json
X-Webhook-Signature: sha256=...

{
  "event": "withdrawal.completed",
  "withdrawal_id": "uuid",
  "user_id": "uuid",
  "amount_points": 1000,
  "amount_currency": 10.00,
  "timestamp": "2024-06-21T14:30:00Z"
}
```

---

## Summary

This API specification provides:

✅ Complete authentication flow  
✅ Task management and completion  
✅ Wallet and transaction tracking  
✅ Withdrawal request and approval  
✅ Referral system  
✅ User profile management  
✅ Admin operations  
✅ Error handling and rate limiting  

Ready for backend implementation with Node.js, Python, or any framework.

# Workminto Backend Architecture

## Overview

Workminto is a rewards platform where users earn points by completing tasks, surveys, and referrals, then redeem them for real rewards. This document defines the complete backend architecture, database schema, relationships, and user flows.

---

## 1. Database Schema

### 1.1 Users Table

Stores user account information and profile data.

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  phone VARCHAR(20),
  
  -- Profile
  profile_picture_url TEXT,
  bio TEXT,
  date_of_birth DATE,
  country VARCHAR(100),
  
  -- Account Status
  status ENUM('active', 'suspended', 'banned', 'pending_verification') DEFAULT 'pending_verification',
  email_verified BOOLEAN DEFAULT FALSE,
  email_verified_at TIMESTAMP,
  
  -- Referral
  referral_code VARCHAR(20) UNIQUE NOT NULL,
  referred_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  
  -- Level & Progress
  level INT DEFAULT 1,
  total_points_earned BIGINT DEFAULT 0,
  total_points_spent BIGINT DEFAULT 0,
  
  -- Security
  two_factor_enabled BOOLEAN DEFAULT FALSE,
  two_factor_secret VARCHAR(255),
  last_login_at TIMESTAMP,
  last_login_ip VARCHAR(45),
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP,
  
  -- Indexes
  INDEX idx_email (email),
  INDEX idx_referral_code (referral_code),
  INDEX idx_referred_by (referred_by_user_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
);
```

**Key Fields:**
- `referral_code`: Unique code for sharing (e.g., "WORKMINTO25")
- `referred_by_user_id`: Links to the user who referred this user
- `level`: User progression level (1-100+)
- `status`: Allows admin to suspend/ban users
- `two_factor_enabled`: Security feature for sensitive operations

---

### 1.2 Referrals Table

Tracks referral relationships and rewards.

```sql
CREATE TABLE referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Reward Status
  referral_bonus_points INT DEFAULT 200,
  bonus_awarded BOOLEAN DEFAULT FALSE,
  bonus_awarded_at TIMESTAMP,
  
  -- Tracking
  referred_user_completed_first_task BOOLEAN DEFAULT FALSE,
  first_task_completed_at TIMESTAMP,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Constraints & Indexes
  UNIQUE(referrer_user_id, referred_user_id),
  INDEX idx_referrer (referrer_user_id),
  INDEX idx_referred (referred_user_id),
  INDEX idx_bonus_awarded (bonus_awarded),
  INDEX idx_created_at (created_at)
);
```

**Key Fields:**
- `referral_bonus_points`: Points awarded to referrer when referred user completes first task
- `bonus_awarded`: Prevents duplicate bonus payments
- `referred_user_completed_first_task`: Tracks milestone for bonus trigger

---

### 1.3 Tasks Table

Stores available tasks/surveys/offers.

```sql
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Basic Info
  title VARCHAR(255) NOT NULL,
  description TEXT,
  category ENUM('daily_checkin', 'quiz', 'survey', 'video', 'offer', 'bonus', 'referral') NOT NULL,
  
  -- Rewards
  reward_points INT NOT NULL,
  reward_currency DECIMAL(10, 2),
  currency_code VARCHAR(3),
  
  -- Constraints
  max_completions_per_user INT DEFAULT 1,
  max_daily_completions_per_user INT DEFAULT 1,
  daily_limit_reset_hour INT DEFAULT 0,
  
  -- Availability
  status ENUM('active', 'inactive', 'archived', 'draft') DEFAULT 'active',
  start_date TIMESTAMP,
  end_date TIMESTAMP,
  
  -- Requirements
  min_user_level INT DEFAULT 1,
  min_account_age_days INT DEFAULT 0,
  
  -- Metadata
  priority INT DEFAULT 0,
  created_by_admin_id UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_category (category),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
);
```

**Key Fields:**
- `category`: Type of task (daily check-in, quiz, survey, etc.)
- `max_completions_per_user`: Prevents abuse (e.g., only 1 completion per user)
- `max_daily_completions_per_user`: Rate limiting per day
- `min_user_level`: Only high-level users can access premium tasks
- `priority`: Admin control for task ordering

---

### 1.4 Task Completions Table

Records when users complete tasks.

```sql
CREATE TABLE task_completions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  
  -- Completion Status
  status ENUM('pending', 'approved', 'rejected', 'expired') DEFAULT 'pending',
  completion_proof TEXT,
  
  -- Points & Rewards
  points_awarded INT,
  currency_awarded DECIMAL(10, 2),
  
  -- Admin Review
  reviewed_by_admin_id UUID REFERENCES users(id),
  review_notes TEXT,
  reviewed_at TIMESTAMP,
  
  -- Metadata
  completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Constraints & Indexes
  UNIQUE(user_id, task_id, completed_at),
  INDEX idx_user (user_id),
  INDEX idx_task (task_id),
  INDEX idx_status (status),
  INDEX idx_completed_at (completed_at)
);
```

**Key Fields:**
- `status`: Allows admin review before awarding points
- `completion_proof`: Evidence of task completion (screenshot, form data, etc.)
- `reviewed_by_admin_id`: Tracks which admin approved/rejected
- `points_awarded`: Actual points given (may differ from task reward if adjusted)

---

### 1.5 Wallet Table

Tracks user point balances.

```sql
CREATE TABLE wallet (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Balance
  total_points BIGINT DEFAULT 0,
  available_points BIGINT DEFAULT 0,
  pending_points BIGINT DEFAULT 0,
  spent_points BIGINT DEFAULT 0,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_user (user_id)
);
```

**Key Fields:**
- `total_points`: All points ever earned
- `available_points`: Points ready to redeem
- `pending_points`: Points from pending task completions
- `spent_points`: Points already redeemed

---

### 1.6 Wallet Transactions Table

Audit trail of all point movements.

```sql
CREATE TABLE wallet_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Transaction Details
  type ENUM('earned', 'spent', 'refunded', 'bonus', 'adjustment', 'withdrawal') NOT NULL,
  amount BIGINT NOT NULL,
  
  -- Reference
  task_completion_id UUID REFERENCES task_completions(id),
  withdrawal_id UUID REFERENCES withdrawals(id),
  referral_id UUID REFERENCES referrals(id),
  
  -- Description
  description TEXT,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_user (user_id),
  INDEX idx_type (type),
  INDEX idx_created_at (created_at)
);
```

**Key Fields:**
- `type`: Categorizes transaction purpose
- `amount`: Positive for earned, negative for spent
- Foreign keys to related entities for full audit trail

---

### 1.7 Withdrawals Table

Tracks user withdrawal requests and admin approvals.

```sql
CREATE TABLE withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Withdrawal Details
  amount_points BIGINT NOT NULL,
  amount_currency DECIMAL(10, 2) NOT NULL,
  currency_code VARCHAR(3) DEFAULT 'USD',
  
  -- Method
  withdrawal_method ENUM('paypal', 'bank_transfer', 'gift_card', 'crypto', 'stripe') NOT NULL,
  withdrawal_details JSONB,
  
  -- Status
  status ENUM('pending', 'approved', 'rejected', 'processing', 'completed', 'failed') DEFAULT 'pending',
  
  -- Admin Review
  reviewed_by_admin_id UUID REFERENCES users(id),
  rejection_reason TEXT,
  reviewed_at TIMESTAMP,
  
  -- Processing
  transaction_id VARCHAR(255),
  processed_at TIMESTAMP,
  
  -- Metadata
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_user (user_id),
  INDEX idx_status (status),
  INDEX idx_requested_at (requested_at)
);
```

**Key Fields:**
- `withdrawal_method`: Multiple payment options
- `withdrawal_details`: JSONB for flexible payment info storage
- `status`: Multi-stage approval workflow
- `transaction_id`: External payment processor reference

---

### 1.8 Notifications Table

Stores user notifications.

```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Notification Content
  type ENUM('task_available', 'points_earned', 'withdrawal_approved', 'withdrawal_rejected', 'referral_bonus', 'level_up', 'system_alert') NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  
  -- Status
  is_read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMP,
  
  -- Action
  action_url VARCHAR(500),
  action_type VARCHAR(50),
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_user (user_id),
  INDEX idx_is_read (is_read),
  INDEX idx_created_at (created_at)
);
```

**Key Fields:**
- `type`: Categorizes notification purpose
- `action_url`: Link to relevant page (e.g., task details)
- `is_read`: Tracks notification status

---

### 1.9 Audit Logs Table

Tracks all admin and system actions for compliance.

```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Actor
  admin_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action_type VARCHAR(100) NOT NULL,
  
  -- Target
  target_entity_type VARCHAR(50),
  target_entity_id UUID,
  
  -- Details
  changes JSONB,
  ip_address VARCHAR(45),
  user_agent TEXT,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_admin (admin_id),
  INDEX idx_action_type (action_type),
  INDEX idx_target (target_entity_type, target_entity_id),
  INDEX idx_created_at (created_at)
);
```

**Key Fields:**
- `action_type`: Admin action (suspend_user, approve_withdrawal, etc.)
- `changes`: JSONB stores before/after state for sensitive operations
- `ip_address`: Security tracking

---

### 1.10 Announcements Table

Stores admin announcements for users.

```sql
CREATE TABLE announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Content
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  type ENUM('info', 'warning', 'success', 'maintenance') DEFAULT 'info',
  
  -- Publishing
  status ENUM('draft', 'published', 'archived') DEFAULT 'draft',
  published_at TIMESTAMP,
  scheduled_for TIMESTAMP,
  
  -- Targeting
  target_audience ENUM('all_users', 'active_users', 'new_users', 'admins_only') DEFAULT 'all_users',
  
  -- Metadata
  created_by_admin_id UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  -- Indexes
  INDEX idx_status (status),
  INDEX idx_published_at (published_at)
);
```

**Key Fields:**
- `status`: Draft/published workflow
- `target_audience`: Segment-based delivery
- `scheduled_for`: Future announcement scheduling

---

## 2. Database Relationships

### Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                          USERS                                       │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ id (PK)                                                      │  │
│  │ email, password_hash                                         │  │
│  │ referral_code, referred_by_user_id (FK → users)            │  │
│  │ level, total_points_earned, total_points_spent             │  │
│  │ status, email_verified, two_factor_enabled                 │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
         │                    │                    │
         │ (1:N)              │ (1:1)              │ (1:N)
         ▼                    ▼                    ▼
    ┌─────────────┐    ┌─────────────┐    ┌──────────────────┐
    │ REFERRALS   │    │   WALLET    │    │ TASK_COMPLETIONS │
    ├─────────────┤    ├─────────────┤    ├──────────────────┤
    │ referrer_id │    │ user_id (FK)│    │ user_id (FK)     │
    │ referred_id │    │ total_points│    │ task_id (FK)     │
    │ bonus_pts   │    │ available   │    │ status           │
    └─────────────┘    └─────────────┘    │ points_awarded   │
         │                    │            └──────────────────┘
         │ (1:N)              │ (1:N)              │
         ▼                    ▼                    ▼
    ┌──────────────────────────────────────────────────────┐
    │        WALLET_TRANSACTIONS                           │
    │  ┌────────────────────────────────────────────────┐ │
    │  │ user_id (FK), type, amount                     │ │
    │  │ task_completion_id (FK), withdrawal_id (FK)   │ │
    │  └────────────────────────────────────────────────┘ │
    └──────────────────────────────────────────────────────┘
         │
         │ (1:N)
         ▼
    ┌─────────────────┐
    │  WITHDRAWALS    │
    ├─────────────────┤
    │ user_id (FK)    │
    │ amount_points   │
    │ status          │
    │ reviewed_by_id  │
    └─────────────────┘

    ┌─────────────┐
    │    TASKS    │
    ├─────────────┤
    │ id (PK)     │
    │ title       │
    │ category    │
    │ reward_pts  │
    │ status      │
    └─────────────┘
         │
         │ (1:N)
         ▼
    ┌──────────────────┐
    │ TASK_COMPLETIONS │
    └──────────────────┘

    ┌──────────────────┐
    │ NOTIFICATIONS    │
    ├──────────────────┤
    │ user_id (FK)     │
    │ type, title      │
    │ is_read          │
    └──────────────────┘

    ┌──────────────────┐
    │  AUDIT_LOGS      │
    ├──────────────────┤
    │ admin_id (FK)    │
    │ action_type      │
    │ target_entity_id │
    └──────────────────┘

    ┌──────────────────┐
    │ ANNOUNCEMENTS    │
    ├──────────────────┤
    │ created_by_id    │
    │ status           │
    │ target_audience  │
    └──────────────────┘
```

---

## 3. User Flows

### 3.1 User Registration & Onboarding Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. USER SIGNUP                                                  │
├─────────────────────────────────────────────────────────────────┤
│ • User enters email, password, name                             │
│ • System creates user record with status='pending_verification' │
│ • Generate unique referral_code (e.g., "WORKMINTO25")          │
│ • Send verification email with OTP/link                         │
│ • Create empty wallet with 0 points                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. EMAIL VERIFICATION                                           │
├─────────────────────────────────────────────────────────────────┤
│ • User clicks verification link or enters OTP                   │
│ • Set email_verified=true, email_verified_at=NOW              │
│ • Update status to 'active'                                     │
│ • Send welcome notification                                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. REFERRAL LINK HANDLING                                       │
├─────────────────────────────────────────────────────────────────┤
│ • If user came via referral link (referrer_code in URL):       │
│   - Look up referrer user by referral_code                      │
│   - Set referred_by_user_id = referrer_id                       │
│   - Create referrals record                                     │
│   - Send notification to referrer                               │
│ • Otherwise: referred_by_user_id = NULL                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. FIRST LOGIN                                                  │
├─────────────────────────────────────────────────────────────────┤
│ • Update last_login_at, last_login_ip                          │
│ • Show onboarding tutorial                                      │
│ • Redirect to dashboard                                         │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.2 Task Completion & Points Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. USER VIEWS AVAILABLE TASKS                                   │
├─────────────────────────────────────────────────────────────────┤
│ • Query tasks WHERE:                                            │
│   - status = 'active'                                           │
│   - start_date <= NOW <= end_date                              │
│   - user_level >= min_user_level                               │
│   - account_age >= min_account_age_days                        │
│ • Exclude tasks user already completed (if max_completions=1)  │
│ • Sort by priority DESC                                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. USER STARTS TASK                                             │
├─────────────────────────────────────────────────────────────────┤
│ • Check daily limit: count completions today < max_daily_limit │
│ • Create task_completion record with status='pending'          │
│ • Redirect to task (external survey, quiz, etc.)               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. USER COMPLETES TASK                                          │
├─────────────────────────────────────────────────────────────────┤
│ • Receive completion_proof (form data, screenshot, etc.)        │
│ • Update task_completion with status='approved' (auto-approve)  │
│   OR status='pending' (requires admin review)                   │
│ • If auto-approved:                                             │
│   - Award points_awarded = task.reward_points                   │
│   - Update wallet.available_points += points                    │
│   - Create wallet_transaction record                            │
│   - Update user.total_points_earned                             │
│   - Send notification to user                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 4. ADMIN REVIEW (if needed)                                     │
├─────────────────────────────────────────────────────────────────┤
│ • Admin sees pending task_completion                            │
│ • Reviews completion_proof                                      │
│ • Approve: status='approved', award points (same as step 3)    │
│ • Reject: status='rejected', send rejection notification        │
│ • Log action in audit_logs                                      │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.3 Referral Bonus Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. USER GETS REFERRED                                           │
├─────────────────────────────────────────────────────────────────┤
│ • New user signs up with referrer's referral_code              │
│ • Create referrals record:                                      │
│   - referrer_user_id = referrer                                 │
│   - referred_user_id = new_user                                 │
│   - bonus_awarded = false                                       │
│   - referral_bonus_points = 200 (configurable)                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. REFERRED USER COMPLETES FIRST TASK                           │
├─────────────────────────────────────────────────────────────────┤
│ • Task completion approved (status='approved')                  │
│ • Check if this is first task for user                          │
│ • If yes:                                                        │
│   - Update referrals.referred_user_completed_first_task = true  │
│   - Update referrals.first_task_completed_at = NOW             │
│   - Trigger bonus award (step 3)                                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. AWARD REFERRAL BONUS                                         │
├─────────────────────────────────────────────────────────────────┤
│ • Check if bonus_awarded = false (prevent double-award)         │
│ • Award points to referrer:                                     │
│   - points = referral_bonus_points (e.g., 200)                 │
│   - Update wallet.available_points += points                    │
│   - Update user.total_points_earned += points                   │
│   - Create wallet_transaction with type='bonus'                 │
│   - Update referrals.bonus_awarded = true                       │
│   - Update referrals.bonus_awarded_at = NOW                     │
│ • Send notification to referrer:                                │
│   - "You earned 200 points! [referred_user] completed a task"   │
│ • Log action in audit_logs                                      │
└─────────────────────────────────────────────────────────────────┘
```

---

### 3.4 Points & Wallet Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ WALLET STATE MANAGEMENT                                         │
├─────────────────────────────────────────────────────────────────┤
│ total_points = available_points + pending_points + spent_points │
│                                                                  │
│ • available_points: Ready to redeem (from approved tasks)       │
│ • pending_points: Awaiting admin review                         │
│ • spent_points: Already redeemed                                │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ POINT EARNING FLOW                                              │
├─────────────────────────────────────────────────────────────────┤
│ 1. Task completed (approved) → +50 points                       │
│    • wallet.available_points += 50                              │
│    • wallet.total_points += 50                                  │
│    • user.total_points_earned += 50                             │
│    • Create transaction: type='earned', amount=50               │
│                                                                  │
│ 2. Referral bonus → +200 points                                 │
│    • wallet.available_points += 200                             │
│    • wallet.total_points += 200                                 │
│    • user.total_points_earned += 200                            │
│    • Create transaction: type='bonus', amount=200               │
│                                                                  │
│ 3. Admin adjustment → ±X points                                 │
│    • wallet.available_points ±= X                               │
│    • wallet.total_points ±= X                                   │
│    • Create transaction: type='adjustment', amount=X            │
│    • Log in audit_logs                                          │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ POINT SPENDING FLOW (Withdrawal)                                │
├─────────────────────────────────────────────────────────────────┤
│ 1. User requests withdrawal of 1000 points                      │
│    • Check: available_points >= 1000                            │
│    • wallet.available_points -= 1000                            │
│    • wallet.spent_points += 1000                                │
│    • Create transaction: type='withdrawal', amount=-1000        │
│    • Create withdrawal record with status='pending'             │
│                                                                  │
│ 2. Admin approves withdrawal                                    │
│    • withdrawal.status = 'approved'                             │
│    • Process payment (PayPal, bank, etc.)                       │
│    • withdrawal.status = 'processing'                           │
│                                                                  │
│ 3. Payment completes                                            │
│    • withdrawal.status = 'completed'                            │
│    • withdrawal.processed_at = NOW                              │
│    • Send confirmation notification                             │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. Withdrawal Flow

### 4.1 Complete Withdrawal Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│ STAGE 1: USER INITIATES WITHDRAWAL                              │
├─────────────────────────────────────────────────────────────────┤
│ Input:                                                           │
│ • amount_points: 1000                                           │
│ • withdrawal_method: 'paypal'                                   │
│ • withdrawal_details: { email: 'user@example.com' }            │
│                                                                  │
│ Validation:                                                      │
│ • Check available_points >= amount_points                       │
│ • Check min_withdrawal_amount (e.g., 500 points)               │
│ • Check max_withdrawal_amount (e.g., 50000 points)             │
│ • Check withdrawal_frequency (e.g., max 1 per day)             │
│ • Check user status != 'suspended' or 'banned'                 │
│                                                                  │
│ Action:                                                          │
│ • Create withdrawal record with status='pending'                │
│ • wallet.available_points -= amount_points                      │
│ • wallet.spent_points += amount_points                          │
│ • Create wallet_transaction: type='withdrawal'                  │
│ • Send notification: "Withdrawal request submitted"             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ STAGE 2: ADMIN REVIEW                                           │
├─────────────────────────────────────────────────────────────────┤
│ Admin sees pending withdrawal in admin panel                    │
│                                                                  │
│ Checks:                                                          │
│ • User account status (not suspicious)                          │
│ • Account age (not brand new)                                   │
│ • Task completion history (legitimate user)                     │
│ • Previous withdrawal history                                   │
│ • Fraud detection flags                                         │
│                                                                  │
│ Decision:                                                        │
│ • APPROVE: withdrawal.status = 'approved'                       │
│           withdrawal.reviewed_by_admin_id = admin_id            │
│           withdrawal.reviewed_at = NOW                          │
│           Proceed to STAGE 3                                    │
│                                                                  │
│ • REJECT:  withdrawal.status = 'rejected'                       │
│           withdrawal.rejection_reason = "Suspicious activity"   │
│           withdrawal.reviewed_by_admin_id = admin_id            │
│           Refund points to user:                                │
│           - wallet.available_points += amount_points            │
│           - wallet.spent_points -= amount_points                │
│           - Create transaction: type='refunded'                 │
│           Send notification: "Withdrawal rejected"              │
│           Log in audit_logs                                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ STAGE 3: PAYMENT PROCESSING                                     │
├─────────────────────────────────────────────────────────────────┤
│ Update withdrawal.status = 'processing'                         │
│                                                                  │
│ Call payment processor API:                                     │
│ • PayPal: Send payout via PayPal API                           │
│ • Bank Transfer: Generate ACH/wire instruction                 │
│ • Gift Card: Generate code and email                           │
│ • Stripe: Process via Stripe Connect                           │
│                                                                  │
│ Store transaction_id from payment processor                     │
│ withdrawal.transaction_id = "txn_12345"                         │
│                                                                  │
│ If error: withdrawal.status = 'failed'                          │
│           Retry logic (exponential backoff)                     │
│           Send alert to admin                                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ STAGE 4: COMPLETION                                             │
├─────────────────────────────────────────────────────────────────┤
│ Payment processor confirms success                              │
│                                                                  │
│ Update withdrawal:                                              │
│ • status = 'completed'                                          │
│ • processed_at = NOW                                            │
│                                                                  │
│ Send notification to user:                                      │
│ • "Your withdrawal of 1000 points has been processed!"          │
│ • Include transaction details                                   │
│                                                                  │
│ Log in audit_logs                                               │
└─────────────────────────────────────────────────────────────────┘
```

---

### 4.2 Withdrawal Status Transitions

```
                    ┌──────────────┐
                    │   PENDING    │
                    └──────────────┘
                      │          │
            ┌─────────┘          └─────────┐
            │                              │
            ▼                              ▼
      ┌──────────────┐          ┌──────────────────┐
      │  APPROVED    │          │    REJECTED      │
      └──────────────┘          └──────────────────┘
            │                   (Refund points)
            ▼
      ┌──────────────┐
      │ PROCESSING   │
      └──────────────┘
         │        │
         │        └─────────────┐
         │                      │
         ▼                      ▼
    ┌──────────────┐      ┌──────────────┐
    │  COMPLETED   │      │   FAILED     │
    └──────────────┘      └──────────────┘
                          (Retry or manual)
```

---

## 5. Admin Approval Flow

### 5.1 Admin Dashboard Overview

```
┌─────────────────────────────────────────────────────────────────┐
│ ADMIN DASHBOARD                                                 │
├─────────────────────────────────────────────────────────────────┤
│ • Pending Withdrawals: 5                                        │
│ • Pending Task Reviews: 12                                      │
│ • Flagged Users: 3                                              │
│ • System Alerts: 2                                              │
│                                                                  │
│ Quick Actions:                                                   │
│ • Review Withdrawals                                            │
│ • Review Tasks                                                  │
│ • Manage Users                                                  │
│ • View Audit Logs                                               │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 Withdrawal Approval Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. ADMIN VIEWS PENDING WITHDRAWALS                              │
├─────────────────────────────────────────────────────────────────┤
│ Query: SELECT * FROM withdrawals WHERE status='pending'         │
│        ORDER BY requested_at ASC                                │
│                                                                  │
│ Display:                                                         │
│ • User name, email, account age                                 │
│ • Amount requested                                              │
│ • Withdrawal method                                             │
│ • User's task completion history                                │
│ • Previous withdrawal history                                   │
│ • Fraud risk score (if available)                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. ADMIN REVIEWS WITHDRAWAL DETAILS                             │
├─────────────────────────────────────────────────────────────────┤
│ Checks:                                                          │
│ • Is user account legitimate? (not bot, not suspicious)         │
│ • Is account age sufficient? (e.g., > 7 days)                  │
│ • Has user completed enough tasks? (e.g., > 5)                 │
│ • Is withdrawal amount reasonable? (not extreme)                │
│ • Any fraud flags or reports?                                   │
│ • Payment method valid and verified?                            │
│                                                                  │
│ Decision:                                                        │
│ • APPROVE: withdrawal.status = 'approved'                       │
│ • REJECT: withdrawal.status = 'rejected'                        │
│           withdrawal.rejection_reason = "..."                   │
│ • REQUEST_INFO: Send message to user for verification           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. LOG ADMIN ACTION                                             │
├─────────────────────────────────────────────────────────────────┤
│ Create audit_log record:                                        │
│ • admin_id = current_admin.id                                   │
│ • action_type = 'approve_withdrawal' or 'reject_withdrawal'    │
│ • target_entity_type = 'withdrawal'                             │
│ • target_entity_id = withdrawal.id                              │
│ • changes = { status: 'pending' → 'approved' }                 │
│ • ip_address = admin_ip                                         │
│ • created_at = NOW                                              │
└─────────────────────────────────────────────────────────────────┘
```

### 5.3 Task Completion Review Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│ 1. ADMIN VIEWS PENDING TASK COMPLETIONS                         │
├─────────────────────────────────────────────────────────────────┤
│ Query: SELECT * FROM task_completions                           │
│        WHERE status='pending'                                   │
│        ORDER BY completed_at ASC                                │
│                                                                  │
│ Display:                                                         │
│ • User name, account age                                        │
│ • Task title and category                                       │
│ • Completion proof (screenshot, form data, etc.)                │
│ • Reward points                                                 │
│ • User's completion history for this task type                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2. ADMIN REVIEWS COMPLETION PROOF                               │
├─────────────────────────────────────────────────────────────────┤
│ Checks:                                                          │
│ • Is proof legitimate? (not fake, not duplicate)                │
│ • Does it meet task requirements?                               │
│ • Any signs of fraud or automation?                             │
│                                                                  │
│ Decision:                                                        │
│ • APPROVE: task_completion.status = 'approved'                  │
│           Award points (if not already awarded)                 │
│ • REJECT: task_completion.status = 'rejected'                   │
│          task_completion.review_notes = "..."                   │
│          Send notification to user                              │
│ • REQUEST_PROOF: Ask user to resubmit proof                     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ 3. LOG ADMIN ACTION & NOTIFY USER                               │
├─────────────────────────────────────────────────────────────────┤
│ • Create audit_log record                                       │
│ • Update task_completion:                                       │
│   - status = 'approved' or 'rejected'                           │
│   - reviewed_by_admin_id = admin_id                             │
│   - reviewed_at = NOW                                           │
│ • If approved:                                                   │
│   - Award points to user wallet                                 │
│   - Create wallet_transaction                                   │
│   - Send notification: "Task approved! +50 points"              │
│ • If rejected:                                                   │
│   - Send notification: "Task rejected. Reason: ..."             │
└─────────────────────────────────────────────────────────────────┘
```

### 5.4 User Management Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│ ADMIN ACTIONS ON USERS                                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│ 1. SUSPEND USER                                                 │
│    • user.status = 'suspended'                                  │
│    • User can't earn points or withdraw                         │
│    • Can still view account                                     │
│    • Log in audit_logs                                          │
│    • Send notification: "Account suspended"                     │
│                                                                  │
│ 2. BAN USER                                                     │
│    • user.status = 'banned'                                     │
│    • User can't access platform                                 │
│    • Freeze all pending withdrawals                             │
│    • Log in audit_logs                                          │
│    • Send notification: "Account banned"                        │
│                                                                  │
│ 3. ADJUST POINTS                                                │
│    • wallet.available_points ±= X                               │
│    • Create wallet_transaction: type='adjustment'               │
│    • Log in audit_logs with reason                              │
│    • Send notification: "Points adjusted"                       │
│                                                                  │
│ 4. VERIFY PAYMENT METHOD                                        │
│    • Confirm user's withdrawal payment method                   │
│    • Mark as verified in user profile                           │
│    • Log in audit_logs                                          │
│                                                                  │
│ 5. VIEW AUDIT TRAIL                                             │
│    • Show all user actions and admin actions                    │
│    • Task completions, withdrawals, point changes               │
│    • Admin adjustments and notes                                │
└─────────────────────────────────────────────────────────────────┘
```

---

## 6. Security & Compliance

### 6.1 Data Protection

- **Password Storage**: Bcrypt with salt (min 12 rounds)
- **Sensitive Data**: Encrypt withdrawal_details (PayPal email, bank account)
- **PII**: Encrypt phone, DOB, address in database
- **API Keys**: Store hashed, never log plaintext
- **Audit Trail**: Immutable audit_logs table for compliance

### 6.2 Fraud Prevention

- **Rate Limiting**: Max 5 withdrawal requests per day per user
- **Account Age**: Min 7 days before first withdrawal
- **Task Limits**: Max 1 completion per task per day
- **Referral Verification**: Bonus only after referred user completes first task
- **Anomaly Detection**: Flag unusual withdrawal patterns
- **IP Tracking**: Monitor for suspicious login locations

### 6.3 Admin Controls

- **Role-Based Access**: Admin, Moderator, User roles
- **Action Logging**: Every admin action logged in audit_logs
- **Approval Workflow**: Multi-stage review for high-value withdrawals
- **Reason Tracking**: All rejections must include reason
- **Session Management**: 30-min timeout, 2FA required

---

## 7. Performance Considerations

### 7.1 Indexing Strategy

```sql
-- Critical indexes for fast queries
INDEX idx_users_email (email)
INDEX idx_users_referral_code (referral_code)
INDEX idx_tasks_status (status)
INDEX idx_task_completions_user_task (user_id, task_id)
INDEX idx_wallet_transactions_user_created (user_id, created_at)
INDEX idx_withdrawals_status_created (status, created_at)
INDEX idx_notifications_user_is_read (user_id, is_read)
INDEX idx_audit_logs_admin_created (admin_id, created_at)
```

### 7.2 Query Optimization

- **Pagination**: Always limit results (e.g., 50 per page)
- **Caching**: Cache user wallet balance, task list (5 min TTL)
- **Batch Operations**: Process withdrawals in batches
- **Archiving**: Move old records to archive tables

---

## 8. API Endpoints (Future Implementation)

### Auth
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/verify-otp` - Verify email OTP
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password

### Tasks
- `GET /api/tasks` - List available tasks
- `POST /api/tasks/:id/complete` - Mark task complete
- `GET /api/tasks/:id/completions` - View user's completions

### Wallet
- `GET /api/wallet` - Get wallet balance
- `GET /api/wallet/transactions` - Get transaction history
- `POST /api/withdrawals` - Request withdrawal
- `GET /api/withdrawals` - View withdrawal history

### Referrals
- `GET /api/referrals` - Get referral stats
- `GET /api/referrals/code` - Get user's referral code
- `GET /api/referrals/history` - View referral history

### Admin
- `GET /api/admin/withdrawals/pending` - Pending withdrawals
- `POST /api/admin/withdrawals/:id/approve` - Approve withdrawal
- `POST /api/admin/withdrawals/:id/reject` - Reject withdrawal
- `GET /api/admin/users` - List users
- `POST /api/admin/users/:id/suspend` - Suspend user
- `GET /api/admin/audit-logs` - View audit logs

---

## 9. Summary

This architecture provides:

✅ **Scalability**: Indexed queries, pagination, caching strategy  
✅ **Security**: Encryption, audit trails, fraud detection  
✅ **Compliance**: Immutable logs, role-based access, approval workflows  
✅ **Flexibility**: JSONB fields for extensibility  
✅ **Maintainability**: Clear relationships, normalized schema  
✅ **Auditability**: Complete action tracking for compliance  

The schema is production-ready and can be implemented with PostgreSQL, MySQL, or any relational database.

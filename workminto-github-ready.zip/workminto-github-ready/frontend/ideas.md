# Workminto Design Brainstorm

## Reference Analysis
The provided reference image showcases a premium rewards/task platform with:
- **Dark theme** (deep navy/purple backgrounds)
- **Neon accents** (vibrant pink, purple, orange gradients)
- **Modern SaaS aesthetic** with polished mobile app feel
- **Rounded cards** with soft shadows and glass-like effects
- **Premium typography** with bold headlines and clean body text
- **High-trust design** with security badges and social proof
- **Gradient buttons** (pink-to-orange) that feel premium and interactive

This reference is the ground-truth design specification. We will match its visual language, mood, premium quality, dark theme, gradients, spacing, and mobile-first layout.

## Design Approach: Premium Neon SaaS

**Theme Name:** Neon Velocity

**Design Movement:** Modern SaaS with cyberpunk-inspired neon accents; combines minimalist clean design with bold gradient highlights.

**Core Principles:**
1. **Dark-first luxury** — Deep navy/purple backgrounds create premium, high-contrast canvas
2. **Neon precision** — Strategic use of pink, purple, orange gradients only on interactive elements and key focal points
3. **Generous whitespace** — Premium spacing between sections; breathing room around content
4. **Glass morphism** — Semi-transparent cards with subtle backdrop blur for depth and sophistication

**Color Philosophy:**
- **Primary Background:** Deep navy-purple (`oklch(0.12 0.02 280)`) — creates luxury, reduces eye strain
- **Card Background:** Slightly lighter purple (`oklch(0.18 0.025 285)`) — subtle depth without clutter
- **Neon Pink:** `oklch(0.65 0.25 320)` — primary CTA and accent
- **Neon Orange:** `oklch(0.65 0.22 45)` — secondary accent, gradient pairs
- **Neon Purple:** `oklch(0.55 0.28 290)` — tertiary accent
- **Text:** Bright white (`oklch(0.95 0 0)`) for primary, muted gray (`oklch(0.7 0.01 280)`) for secondary

**Layout Paradigm:**
- Asymmetric hero with left-aligned headline and right-aligned visual
- Staggered section layouts (alternating left/right content)
- Full-width gradient hero with diagonal clip-path edge
- Mobile-first: single column stacking, full-width cards

**Signature Elements:**
1. **Gradient pill buttons** — Pink-to-orange with subtle glow effect
2. **Neon accent lines** — Thin glowing borders on cards and section dividers
3. **Floating gradient orbs** — Abstract background elements that suggest movement

**Interaction Philosophy:**
- Buttons scale down on press (0.97) for tactile feedback
- Hover states reveal subtle glow effects
- Smooth transitions (200-300ms) on all interactive elements
- Cards lift slightly on hover (shadow deepens)

**Animation:**
- Entrance animations: fade + slide-up (300ms ease-out)
- Hover effects: scale + glow (200ms ease-out)
- Button press: scale-down (150ms ease-out)
- Staggered list animations: 50ms between items
- Respect `prefers-reduced-motion` for accessibility

**Typography System:**
- **Display Font:** `Space Grotesk` (bold, geometric) for headlines
- **Body Font:** `Inter` (clean, readable) for body text
- **Hierarchy:**
  - H1: 48px (mobile: 32px), bold, letter-spacing -0.02em
  - H2: 36px (mobile: 24px), bold
  - H3: 24px (mobile: 18px), semi-bold
  - Body: 16px, regular, line-height 1.6
  - Small: 14px, regular, muted color

**Brand Essence:**
> "The modern way to earn. Workminto turns everyday tasks into real rewards—for the ambitious, the curious, and the hustlers."

**Personality Adjectives:** Bold, Trustworthy, Energetic

**Brand Voice:**
- Headlines: Direct, energetic, action-oriented
- CTAs: Conversational, encouraging, no corporate jargon
- Example lines:
  - "Complete Tasks. Earn Rewards." (direct, powerful)
  - "Your points are real. Your rewards are real." (builds trust)

**Wordmark & Logo:**
- Geometric butterfly/wing shape (suggests growth, movement, freedom)
- Bold, modern, no text in the mark itself
- Neon pink gradient fill
- Scalable to favicon size without losing recognition

**Signature Brand Color:**
- **Neon Pink** (`oklch(0.65 0.25 320)`) — unmistakably Workminto, used on CTA buttons and key accents

---

## Implementation Strategy

1. **Global Design System** — Define CSS variables for colors, spacing, typography, shadows, animations
2. **Reusable Components** — Build button, card, badge, section divider components
3. **Landing Page Sections:**
   - Header with logo and mobile nav
   - Hero section with gradient background and asymmetric layout
   - Feature highlights (4 cards with icons)
   - How it works (3-step process)
   - Trust section (stats, security badges)
   - FAQ accordion
   - CTA footer
4. **Dark/Light Mode** — Support both themes with CSS variable switching
5. **Responsive Design** — Mobile-first approach with breakpoints at 640px, 1024px
6. **Premium Polish** — Smooth animations, hover effects, micro-interactions

---

## Visual Assets Needed

1. **Logo/Wordmark** — Geometric butterfly mark in neon pink
2. **Hero Background** — Abstract gradient with floating orbs (generated)
3. **Feature Icons** — 4 custom icons for feature highlights (generated)
4. **How It Works Illustrations** — 3 step-by-step visuals (generated)
5. **Trust Section Graphics** — Security badges, social proof elements


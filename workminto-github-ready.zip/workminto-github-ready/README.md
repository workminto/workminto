# Workminto - Rewards Platform

Complete full-stack rewards and earning platform with referrals, wallet, and admin management.

## Project Structure

```
workminto/
├── workminto-backend/    # Node.js/Express backend API
├── frontend/             # React/Vite frontend
└── README.md
```

## Quick Start

### Backend Deployment (Railway)
1. Go to Railway.app
2. Create new project
3. Add PostgreSQL
4. Add Node.js service from `workminto-backend` folder
5. Set environment variables (see workminto-backend/README.md)
6. Deploy

### Frontend Deployment (Railway)
1. Create new Node.js service from `frontend` folder
2. Set `VITE_API_URL` environment variable
3. Deploy

## Documentation

- **Backend:** See `workminto-backend/README.md`
- **Frontend:** See `frontend/README.md`
- **Deployment:** See `workminto-backend/DEPLOYMENT_GUIDE.md`

## Features

✅ User authentication (signup, login, OTP)
✅ Referral system with bonuses
✅ Wallet with points tracking
✅ Withdrawal requests and admin approval
✅ Admin panel
✅ Mobile-first responsive design

## Status

Ready for production deployment.

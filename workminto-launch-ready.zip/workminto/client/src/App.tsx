import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import VerifyOTP from "./pages/VerifyOTP";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Features from "./pages/Features";
import Pricing from "./pages/Pricing";
import Security from "./pages/Security";
import About from "./pages/About";
import Blog from "./pages/Blog";
import Contact from "./pages/Contact";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import CookiePolicy from "./pages/CookiePolicy";
import Dashboard from "./pages/Dashboard";
import Tasks from "./pages/Tasks";
import Offers from "./pages/Offers";
import Wallet from "./pages/Wallet";
import Referrals from "./pages/Referrals";
import Profile from "./pages/Profile";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminUsers from "./pages/admin/Users";
import AdminTasks from "./pages/admin/Tasks";
import AdminOffers from "./pages/admin/Offers";
import AdminWithdrawals from "./pages/admin/Withdrawals";
import AdminAnnouncements from "./pages/admin/Announcements";
import AdminAnalytics from "./pages/admin/Analytics";
import AdminAuditLogs from "./pages/admin/AuditLogs";
import AdminSecurity from "./pages/admin/Security";
import AdminSettings from "./pages/admin/Settings";


function Router() {
  return (
    <Switch>
      {/* Landing Page */}
      <Route path={"\\"} component={Home} />

      {/* Info Pages */}
      <Route path={"/features"} component={Features} />
      <Route path={"/pricing"} component={Pricing} />
      <Route path={"/security"} component={Security} />
      <Route path={"/about"} component={About} />
      <Route path={"/blog"} component={Blog} />
      <Route path={"/contact"} component={Contact} />
      <Route path={"/privacy"} component={PrivacyPolicy} />
      <Route path={"/terms"} component={TermsOfService} />
      <Route path={"/cookies"} component={CookiePolicy} />

      {/* Auth Pages */}
      <Route path={"/auth/signup"} component={Signup} />
      <Route path={"/auth/login"} component={Login} />
      <Route path={"/auth/verify-otp"} component={VerifyOTP} />
      <Route path={"/auth/forgot-password"} component={ForgotPassword} />
      <Route path={"/auth/reset-password"} component={ResetPassword} />

      {/* App Pages */}
      <Route path={"/app/dashboard"} component={Dashboard} />
      <Route path={"/app/tasks"} component={Tasks} />
      <Route path={"/app/offers"} component={Offers} />
      <Route path={"/app/wallet"} component={Wallet} />
      <Route path={"/app/referrals"} component={Referrals} />
      <Route path={"/app/profile"} component={Profile} />

      {/* Admin Pages */}
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/admin/users"} component={AdminUsers} />
      <Route path={"/admin/tasks"} component={AdminTasks} />
      <Route path={"/admin/offers"} component={AdminOffers} />
      <Route path={"/admin/withdrawals"} component={AdminWithdrawals} />
      <Route path={"/admin/announcements"} component={AdminAnnouncements} />
      <Route path={"/admin/analytics"} component={AdminAnalytics} />
      <Route path={"/admin/audit-logs"} component={AdminAuditLogs} />
      <Route path={"/admin/security"} component={AdminSecurity} />
      <Route path={"/admin/settings"} component={AdminSettings} />

      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

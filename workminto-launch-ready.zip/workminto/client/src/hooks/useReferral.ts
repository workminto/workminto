import { useState, useCallback, useEffect } from 'react';
import { apiClient, endpoints } from '@/config/api';

export interface ReferralStats {
  referral_code: string;
  referral_link: string;
  total_referrals: number;
  active_referrals: number;
  completed_referrals: number;
  total_bonus_earned: number;
}

export interface ReferralRecord {
  id: number;
  referred_user: {
    id: number;
    name: string;
    email: string;
  };
  status: string;
  bonus_points: number;
  bonus_awarded: boolean;
  referred_at: string;
}

export const useReferral = () => {
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [history, setHistory] = useState<ReferralRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchStats = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiClient.get(endpoints.referrals.getStats);
      setStats(response);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch referral stats');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchHistory = useCallback(
    async (limit = 20, offset = 0) => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiClient.get(
          `${endpoints.referrals.getHistory}?limit=${limit}&offset=${offset}`
        );
        setHistory(response.data);
        return response;
      } catch (err: any) {
        setError(err.message || 'Failed to fetch referral history');
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const validateCode = useCallback(async (code: string) => {
    try {
      return await apiClient.post(endpoints.referrals.validateCode, { code });
    } catch (err) {
      throw err;
    }
  }, []);

  const awardBonus = useCallback(async () => {
    try {
      const response = await apiClient.post(endpoints.referrals.awardBonus);
      await fetchStats(); // Refresh stats
      return response;
    } catch (err) {
      throw err;
    }
  }, [fetchStats]);

  // Fetch stats on mount
  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  return {
    stats,
    history,
    isLoading,
    error,
    fetchStats,
    fetchHistory,
    validateCode,
    awardBonus,
  };
};

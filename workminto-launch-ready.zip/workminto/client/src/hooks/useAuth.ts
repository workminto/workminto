import { useState, useCallback, useEffect } from 'react';
import { apiClient, endpoints } from '@/config/api';

export interface User {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  status: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  // Check if user is already logged in
  useEffect(() => {
    const token = localStorage.getItem('access_token');
    if (token) {
      apiClient.setToken(token);
      setAuthState(prev => ({
        ...prev,
        isAuthenticated: true,
        isLoading: false,
      }));
    } else {
      setAuthState(prev => ({
        ...prev,
        isLoading: false,
      }));
    }
  }, []);

  const signup = useCallback(
    async (email: string, password: string, firstName: string, lastName: string, referralCode?: string) => {
      setAuthState(prev => ({ ...prev, isLoading: true, error: null }));
      try {
        const response = await apiClient.post(endpoints.auth.signup, {
          email,
          password,
          first_name: firstName,
          last_name: lastName,
          referral_code: referralCode,
        });

        apiClient.setToken(response.access_token);
        localStorage.setItem('refresh_token', response.refresh_token);

        setAuthState({
          user: response.user,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });

        return response;
      } catch (error: any) {
        const errorMessage = error.message || 'Signup failed';
        setAuthState(prev => ({
          ...prev,
          isLoading: false,
          error: errorMessage,
        }));
        throw error;
      }
    },
    []
  );

  const login = useCallback(async (email: string, password: string) => {
    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));
    try {
      const response = await apiClient.post(endpoints.auth.login, {
        email,
        password,
      });

      apiClient.setToken(response.access_token);
      localStorage.setItem('refresh_token', response.refresh_token);

      setAuthState({
        user: response.user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });

      return response;
    } catch (error: any) {
      const errorMessage = error.message || 'Login failed';
      setAuthState(prev => ({
        ...prev,
        isLoading: false,
        error: errorMessage,
      }));
      throw error;
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token');
      if (refreshToken) {
        await apiClient.post(endpoints.auth.logout, {
          refresh_token: refreshToken,
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      apiClient.clearToken();
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      });
    }
  }, []);

  const sendOTP = useCallback(async (email: string) => {
    try {
      return await apiClient.post(endpoints.auth.sendOTP, { email });
    } catch (error) {
      throw error;
    }
  }, []);

  const verifyOTP = useCallback(async (email: string, otp: string) => {
    try {
      return await apiClient.post(endpoints.auth.verifyOTP, { email, otp });
    } catch (error) {
      throw error;
    }
  }, []);

  const forgotPassword = useCallback(async (email: string) => {
    try {
      return await apiClient.post(endpoints.auth.forgotPassword, { email });
    } catch (error) {
      throw error;
    }
  }, []);

  const resetPassword = useCallback(async (resetToken: string, newPassword: string) => {
    try {
      return await apiClient.post(endpoints.auth.resetPassword, {
        reset_token: resetToken,
        new_password: newPassword,
      });
    } catch (error) {
      throw error;
    }
  }, []);

  return {
    ...authState,
    signup,
    login,
    logout,
    sendOTP,
    verifyOTP,
    forgotPassword,
    resetPassword,
  };
};

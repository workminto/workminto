import { useState, useCallback } from 'react';
import { apiClient, endpoints } from '@/config/api';

export interface WithdrawalRequest {
  id: number;
  user_id: number;
  amount_points: number;
  amount_currency: number;
  method: string;
  status: string;
  requested_at: string;
  processed_at?: string;
}

export const useWithdrawal = () => {
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchWithdrawals = useCallback(
    async (status?: string, limit = 20, offset = 0) => {
      setIsLoading(true);
      setError(null);
      try {
        let url = `${endpoints.withdrawals.getList}?limit=${limit}&offset=${offset}`;
        if (status) {
          url += `&status=${status}`;
        }
        const response = await apiClient.get(url);
        setWithdrawals(response.data);
        return response;
      } catch (err: any) {
        setError(err.message || 'Failed to fetch withdrawals');
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const createWithdrawal = useCallback(
    async (amountPoints: number, method: string, paymentDetails: any) => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiClient.post(endpoints.withdrawals.create, {
          amount_points: amountPoints,
          method,
          payment_details: paymentDetails,
        });
        await fetchWithdrawals(); // Refresh list
        return response;
      } catch (err: any) {
        setError(err.message || 'Failed to create withdrawal');
        throw err;
      } finally {
        setIsLoading(false);
      }
    },
    [fetchWithdrawals]
  );

  const getWithdrawalDetails = useCallback(async (withdrawalId: number) => {
    try {
      return await apiClient.get(endpoints.withdrawals.getDetails(withdrawalId));
    } catch (err) {
      throw err;
    }
  }, []);

  return {
    withdrawals,
    isLoading,
    error,
    fetchWithdrawals,
    createWithdrawal,
    getWithdrawalDetails,
  };
};

import { useState, useCallback, useEffect } from 'react';
import { apiClient, endpoints } from '@/config/api';

export interface Wallet {
  id: number;
  user_id: number;
  total_points: number;
  available_points: number;
  pending_points: number;
  level: number;
  created_at: string;
  updated_at: string;
}

export interface Transaction {
  id: number;
  user_id: number;
  type: string;
  amount: number;
  description: string;
  created_at: string;
}

export const useWallet = () => {
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchWallet = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await apiClient.get(endpoints.wallet.get);
      setWallet(response);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch wallet');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchTransactions = useCallback(
    async (limit = 50, offset = 0, type?: string) => {
      setIsLoading(true);
      setError(null);
      try {
        let url = `${endpoints.wallet.getTransactions}?limit=${limit}&offset=${offset}`;
        if (type) {
          url += `&type=${type}`;
        }
        const response = await apiClient.get(url);
        setTransactions(response.data);
        return response;
      } catch (err: any) {
        setError(err.message || 'Failed to fetch transactions');
      } finally {
        setIsLoading(false);
      }
    },
    []
  );

  const addPoints = useCallback(
    async (points: number, type: string, description: string) => {
      try {
        const response = await apiClient.post(endpoints.wallet.addPoints, {
          points,
          type,
          description,
        });
        await fetchWallet(); // Refresh wallet
        return response;
      } catch (err) {
        throw err;
      }
    },
    [fetchWallet]
  );

  const deductPoints = useCallback(
    async (points: number, reason: string) => {
      try {
        const response = await apiClient.post(endpoints.wallet.deductPoints, {
          points,
          reason,
        });
        await fetchWallet(); // Refresh wallet
        return response;
      } catch (err) {
        throw err;
      }
    },
    [fetchWallet]
  );

  // Fetch wallet on mount
  useEffect(() => {
    fetchWallet();
  }, [fetchWallet]);

  return {
    wallet,
    transactions,
    isLoading,
    error,
    fetchWallet,
    fetchTransactions,
    addPoints,
    deductPoints,
  };
};

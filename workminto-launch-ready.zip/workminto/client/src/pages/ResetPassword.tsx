import { useState } from "react";
import { useLocation } from "wouter";
import { AuthLayout } from "@/components/AuthLayout";
import { AuthCard } from "@/components/AuthCard";
import { AuthInput } from "@/components/AuthInput";
import { GradientButton } from "@/components/GradientButton";
import { Lock, Loader2, CheckCircle2 } from "lucide-react";

/**
 * Workminto Reset Password Page
 * Premium password reset form with new password and confirmation
 * Routes to login on successful reset
 */
export default function ResetPassword() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState<Record<string, boolean>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters";
    }
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setSuccess({
      password: true,
      confirmPassword: true,
    });
    setSubmitted(true);

    // Route to login after delay
    setTimeout(() => {
      setLocation("/auth/login");
    }, 2000);
  };

  return (
    <AuthLayout>
      <AuthCard>
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Create New Password
          </h1>
          <p className="text-gray-400">
            Enter a new password for your account
          </p>
        </div>

        {!submitted ? (
          <>
            {/* Form */}
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <AuthInput
                label="New Password"
                name="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={handleChange}
                error={errors.password}
                success={success.password}
                icon={<Lock className="w-5 h-5" />}
              />

              <AuthInput
                label="Confirm Password"
                name="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={handleChange}
                error={errors.confirmPassword}
                success={success.confirmPassword}
                icon={<Lock className="w-5 h-5" />}
              />

              {/* Password Requirements */}
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <p className="text-xs font-semibold text-gray-300 mb-2">
                  Password Requirements:
                </p>
                <ul className="text-xs text-gray-400 space-y-1">
                  <li className="flex items-center gap-2">
                    <span
                      className={
                        formData.password.length >= 8
                          ? "text-green-400"
                          : "text-gray-500"
                      }
                    >
                      ✓
                    </span>
                    At least 8 characters
                  </li>
                  <li className="flex items-center gap-2">
                    <span
                      className={
                        /[A-Z]/.test(formData.password)
                          ? "text-green-400"
                          : "text-gray-500"
                      }
                    >
                      ✓
                    </span>
                    One uppercase letter
                  </li>
                  <li className="flex items-center gap-2">
                    <span
                      className={
                        /[0-9]/.test(formData.password)
                          ? "text-green-400"
                          : "text-gray-500"
                      }
                    >
                      ✓
                    </span>
                    One number
                  </li>
                </ul>
              </div>

              {/* Submit Button */}
              <GradientButton
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Resetting...
                  </>
                ) : (
                  "Reset Password"
                )}
              </GradientButton>
            </form>
          </>
        ) : (
          <>
            {/* Success Message */}
            <div className="flex flex-col gap-4 py-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-500/20 border border-green-500/50 mx-auto">
                <CheckCircle2 className="w-6 h-6 text-green-400" />
              </div>
              <div className="text-center">
                <h2 className="text-xl font-bold text-white mb-2">
                  Password Reset Successful
                </h2>
                <p className="text-gray-400">
                  Your password has been updated. You can now sign in with your
                  new password.
                </p>
              </div>
            </div>

            {/* Redirecting Message */}
            <p className="text-center text-sm text-gray-500">
              Redirecting to sign in...
            </p>
          </>
        )}
      </AuthCard>
    </AuthLayout>
  );
}

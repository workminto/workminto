import { Header } from "@/components/Header";
import { GradientButton } from "@/components/GradientButton";
import { ArrowRight, Shield, Zap, Gift, Users } from "lucide-react";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/workminto-logo-8TkXm59QVr7XQkJ4WqoAGR.webp";

/**
 * Workminto Features Page
 * Showcases platform features and benefits
 */
export default function Features() {
  const features = [
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Instant Rewards",
      description:
        "Earn points instantly and see your balance update in real-time. No waiting, no delays.",
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "100% Secure",
      description:
        "Your data is encrypted and protected. We comply with GDPR and never sell your information.",
    },
    {
      icon: <Gift className="w-8 h-8" />,
      title: "Exciting Rewards",
      description:
        "Redeem your points for gift cards, cash, or exclusive perks from top brands.",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Referral Bonuses",
      description:
        "Earn extra rewards by inviting friends. Both you and your friend get bonuses.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="flex flex-col gap-6 max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Powerful Features for Earning
            </h1>
            <p className="text-lg md:text-xl text-gray-400">
              Workminto gives you everything you need to earn rewards on your terms.
            </p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, idx) => (
              <div
                key={idx}
                className="glass-card p-8 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-20 md:py-32 bg-gradient-to-b from-black/20 to-background">
        <div className="container">
          <div className="glass-card p-8 md:p-16 text-center flex flex-col gap-8 items-center">
            <h2 className="text-3xl md:text-4xl font-bold">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-gray-400 max-w-xl">
              Join thousands of users earning rewards today.
            </p>
            <a href="/auth/signup">
              <GradientButton className="flex items-center justify-center gap-2">
                Start Earning <ArrowRight className="w-5 h-5" />
              </GradientButton>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

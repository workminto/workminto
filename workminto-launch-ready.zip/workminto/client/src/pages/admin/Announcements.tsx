import { AdminLayout } from "@/components/AdminLayout";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";
import { Plus, Edit, Trash2, Eye, Calendar } from "lucide-react";

interface Announcement {
  id: string;
  title: string;
  content: string;
  createdDate: string;
  publishedDate: string | null;
  status: "draft" | "published" | "archived";
}

/**
 * Workminto Announcements Management
 * Create, edit, and publish announcements
 */
export default function AnnouncementsPage() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);

  const announcements: Announcement[] = [
    {
      id: "1",
      title: "New Survey Tasks Available",
      content: "Check out our latest survey tasks with up to 150 points reward!",
      createdDate: "June 20, 2024",
      publishedDate: "June 20, 2024",
      status: "published",
    },
    {
      id: "2",
      title: "Platform Maintenance",
      content: "Scheduled maintenance on June 25, 2024 from 2-4 AM UTC",
      createdDate: "June 19, 2024",
      publishedDate: "June 19, 2024",
      status: "published",
    },
    {
      id: "3",
      title: "Referral Bonus Doubled",
      content: "Earn double points when you refer a friend this week!",
      createdDate: "June 18, 2024",
      publishedDate: null,
      status: "draft",
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Announcements
            </h1>
            <p className="text-gray-400">
              Create and manage platform announcements
            </p>
          </div>
          <GradientButton
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            New Announcement
          </GradientButton>
        </div>

        {/* Announcements List */}
        <div className="space-y-4">
          {announcements.map((announcement) => (
            <div
              key={announcement.id}
              className="glass-card p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
              style={{
                boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
              }}
            >
              <div className="flex-1">
                <h3 className="text-lg font-bold text-white">
                  {announcement.title}
                </h3>
                <p className="text-gray-400 text-sm mt-1">
                  {announcement.content}
                </p>
                <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    Created: {announcement.createdDate}
                  </span>
                  {announcement.publishedDate && (
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      Published: {announcement.publishedDate}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    announcement.status === "published"
                      ? "bg-green-500/20 text-green-400 border border-green-500/50"
                      : announcement.status === "draft"
                      ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/50"
                      : "bg-gray-500/20 text-gray-400 border border-gray-500/50"
                  }`}
                >
                  {announcement.status.charAt(0).toUpperCase() +
                    announcement.status.slice(1)}
                </span>

                <button className="p-2 rounded-lg hover:bg-white/10 transition-colors text-gray-400 hover:text-white">
                  <Edit className="w-4 h-4" />
                </button>
                <button className="p-2 rounded-lg hover:bg-white/10 transition-colors text-gray-400 hover:text-red-400">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Create Announcement Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div
              className="glass-card p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              style={{
                boxShadow: "0 0 40px rgba(255, 20, 147, 0.3)",
              }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">
                  Create Announcement
                </h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Title
                  </label>
                  <input
                    type="text"
                    placeholder="Enter announcement title"
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Content
                  </label>
                  <textarea
                    placeholder="Enter announcement content"
                    rows={6}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Status
                  </label>
                  <select className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white transition-all duration-200">
                    <option>Draft</option>
                    <option>Publish Now</option>
                    <option>Schedule</option>
                  </select>
                </div>

                <div className="flex gap-4">
                  <GradientButton className="flex-1">
                    Create Announcement
                  </GradientButton>
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 px-4 py-3 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

import { AdminLayout } from "@/components/AdminLayout";
import { AdminTable } from "@/components/AdminTable";
import { Shield, AlertCircle, CheckCircle2, Edit, Trash2 } from "lucide-react";

interface AuditLog {
  id: string;
  action: string;
  actor: string;
  target: string;
  timestamp: string;
  status: "success" | "warning" | "error";
}

/**
 * Workminto Audit Logs
 * Track admin and system actions for security
 */
export default function AuditLogsPage() {
  const auditLogs: AuditLog[] = [
    {
      id: "1",
      action: "User Suspended",
      actor: "Admin Sarah",
      target: "User ID: 4521",
      timestamp: "2024-06-20 14:32:15",
      status: "success",
    },
    {
      id: "2",
      action: "Task Created",
      actor: "Admin John",
      target: "New Survey Task",
      timestamp: "2024-06-20 13:45:22",
      status: "success",
    },
    {
      id: "3",
      action: "Withdrawal Approved",
      actor: "Admin Mike",
      target: "Withdrawal ID: 892",
      timestamp: "2024-06-20 12:18:45",
      status: "success",
    },
    {
      id: "4",
      action: "Failed Login Attempt",
      actor: "Unknown",
      target: "Admin Account",
      timestamp: "2024-06-20 11:05:33",
      status: "error",
    },
    {
      id: "5",
      action: "Announcement Published",
      actor: "Admin Lisa",
      target: "Maintenance Notice",
      timestamp: "2024-06-20 10:22:10",
      status: "success",
    },
    {
      id: "6",
      action: "Database Backup",
      actor: "System",
      target: "Daily Backup",
      timestamp: "2024-06-20 02:00:00",
      status: "success",
    },
  ];

  const columns = [
    { key: "action" as const, label: "Action", sortable: true },
    { key: "actor" as const, label: "Actor", sortable: true },
    { key: "target" as const, label: "Target", sortable: true },
    {
      key: "timestamp" as const,
      label: "Timestamp",
      sortable: true,
    },
    {
      key: "status" as const,
      label: "Status",
      render: (value: string) => {
        const Icon =
          value === "success"
            ? CheckCircle2
            : value === "warning"
            ? AlertCircle
            : AlertCircle;
        return (
          <div className="flex items-center gap-2">
            <Icon
              className={`w-4 h-4 ${
                value === "success"
                  ? "text-green-400"
                  : value === "warning"
                  ? "text-yellow-400"
                  : "text-red-400"
              }`}
            />
            <span
              className={`text-xs font-semibold ${
                value === "success"
                  ? "text-green-400"
                  : value === "warning"
                  ? "text-yellow-400"
                  : "text-red-400"
              }`}
            >
              {value.charAt(0).toUpperCase() + value.slice(1)}
            </span>
          </div>
        );
      },
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Audit Logs
          </h1>
          <p className="text-gray-400">
            Track all admin and system actions for security
          </p>
        </div>

        {/* Security Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div
            className="glass-card p-6 flex flex-col gap-4"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-green-500/20 border border-green-500/50 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Successful Actions (24h)</p>
              <p className="text-3xl font-bold text-white mt-2">1,245</p>
            </div>
          </div>

          <div
            className="glass-card p-6 flex flex-col gap-4"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-yellow-500/20 border border-yellow-500/50 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Warnings (24h)</p>
              <p className="text-3xl font-bold text-white mt-2">12</p>
            </div>
          </div>

          <div
            className="glass-card p-6 flex flex-col gap-4"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-red-500/20 border border-red-500/50 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">Failed Actions (24h)</p>
              <p className="text-3xl font-bold text-white mt-2">3</p>
            </div>
          </div>
        </div>

        {/* Audit Logs Table */}
        <AdminTable
          columns={columns}
          data={auditLogs}
          title="Recent Activity"
        />

        {/* Security Recommendations */}
        <div
          className="glass-card p-8"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 border border-blue-500/50 flex items-center justify-center flex-shrink-0">
              <Shield className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-2">
                Security Recommendations
              </h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>• Review failed login attempts from the past 24 hours</li>
                <li>• Ensure all admin accounts have 2FA enabled</li>
                <li>• Schedule regular security audits</li>
                <li>• Monitor for unusual withdrawal patterns</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

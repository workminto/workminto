import { AdminLayout } from "@/components/AdminLayout";
import { GradientButton } from "@/components/GradientButton";
import { Settings, Bell, Shield, Database, Mail } from "lucide-react";

/**
 * Workminto Admin Settings
 * Platform configuration and preferences
 */
export default function AdminSettingsPage() {
  const settingSections = [
    {
      icon: Settings,
      title: "Platform Settings",
      description: "Configure general platform behavior",
      items: [
        { label: "Platform Name", value: "Workminto" },
        { label: "Support Email", value: "support@workminto.com" },
        { label: "Timezone", value: "UTC" },
      ],
    },
    {
      icon: Bell,
      title: "Notifications",
      description: "Configure notification preferences",
      items: [
        { label: "Email Notifications", value: "Enabled" },
        { label: "SMS Alerts", value: "Disabled" },
        { label: "Admin Alerts", value: "Enabled" },
      ],
    },
    {
      icon: Shield,
      title: "Security",
      description: "Security and compliance settings",
      items: [
        { label: "2FA Required", value: "Yes" },
        { label: "Session Timeout", value: "30 minutes" },
        { label: "IP Whitelist", value: "Disabled" },
      ],
    },
    {
      icon: Database,
      title: "Database",
      description: "Database configuration",
      items: [
        { label: "Backup Frequency", value: "Daily" },
        { label: "Retention Period", value: "30 days" },
        { label: "Auto-Backup", value: "Enabled" },
      ],
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Admin Settings
          </h1>
          <p className="text-gray-400">
            Configure platform settings and preferences
          </p>
        </div>

        {/* Settings Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {settingSections.map((section, idx) => {
            const Icon = section.icon;
            return (
              <div
                key={idx}
                className="glass-card p-8"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/20 border border-pink-500/50 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      {section.title}
                    </h3>
                    <p className="text-sm text-gray-400">
                      {section.description}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  {section.items.map((item, itemIdx) => (
                    <div
                      key={itemIdx}
                      className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10"
                    >
                      <p className="text-sm text-gray-300">{item.label}</p>
                      <p className="text-sm font-semibold text-white">
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>

                <GradientButton className="w-full mt-6">
                  Configure
                </GradientButton>
              </div>
            );
          })}
        </div>

        {/* Email Configuration */}
        <div
          className="glass-card p-8"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <div className="flex items-start gap-4 mb-6">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 border border-purple-500/50 flex items-center justify-center">
              <Mail className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Email Service</h3>
              <p className="text-sm text-gray-400">
                Configure email delivery settings
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                SMTP Server
              </label>
              <input
                type="text"
                value="smtp.gmail.com"
                className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">
                  Port
                </label>
                <input
                  type="text"
                  value="587"
                  className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">
                  Encryption
                </label>
                <select className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white transition-all duration-200">
                  <option>TLS</option>
                  <option>SSL</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                From Email
              </label>
              <input
                type="email"
                value="noreply@workminto.com"
                className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
              />
            </div>

            <GradientButton className="w-full">
              Test Email Connection
            </GradientButton>
          </div>
        </div>

        {/* Danger Zone */}
        <div
          className="glass-card p-8 border border-red-500/50"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <h3 className="text-lg font-bold text-red-400 mb-4">Danger Zone</h3>
          <p className="text-sm text-gray-400 mb-6">
            These actions are irreversible. Please proceed with caution.
          </p>

          <div className="space-y-3">
            <button className="w-full px-4 py-3 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold">
              Clear All Cache
            </button>
            <button className="w-full px-4 py-3 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold">
              Reset All Settings
            </button>
            <button className="w-full px-4 py-3 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold">
              Maintenance Mode
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

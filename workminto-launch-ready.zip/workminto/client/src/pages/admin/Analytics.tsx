import { AdminLayout } from "@/components/AdminLayout";
import { StatCard } from "@/components/StatCard";
import { Users, TrendingUp, Coins, Activity } from "lucide-react";

/**
 * Workminto Analytics
 * Platform metrics and performance charts
 */
export default function AnalyticsPage() {
  const stats = [
    {
      icon: Users,
      label: "User Growth (7d)",
      value: "+342",
      change: { value: 15, isPositive: true },
      color: "pink" as const,
    },
    {
      icon: Activity,
      label: "Task Completions (7d)",
      value: "45.2K",
      change: { value: 22, isPositive: true },
      color: "cyan" as const,
    },
    {
      icon: Coins,
      label: "Points Distributed (7d)",
      value: "1.2M",
      change: { value: 18, isPositive: true },
      color: "orange" as const,
    },
    {
      icon: TrendingUp,
      label: "Referral Rate",
      value: "28%",
      change: { value: 5, isPositive: true },
      color: "purple" as const,
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Analytics
          </h1>
          <p className="text-gray-400">
            Platform performance and user metrics
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => (
            <StatCard key={idx} {...stat} />
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* User Growth Chart */}
          <div
            className="glass-card p-8"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <h2 className="text-xl font-bold text-white mb-6">
              User Growth (30 days)
            </h2>
            <div className="h-64 flex items-end gap-2 justify-between">
              {[45, 52, 48, 61, 55, 68, 72, 65, 78, 82, 85, 90, 88, 95, 98, 102, 105, 108, 110, 112, 115, 118, 120, 122, 125, 128, 130, 132, 135, 138].map((value, idx) => (
                <div
                  key={idx}
                  className="flex-1 bg-gradient-to-t from-pink-500 to-orange-500 rounded-t opacity-80 hover:opacity-100 transition-opacity"
                  style={{ height: `${(value / 138) * 100}%` }}
                />
              ))}
            </div>
            <p className="text-xs text-gray-400 mt-4 text-center">
              Daily active users trend
            </p>
          </div>

          {/* Task Completion Chart */}
          <div
            className="glass-card p-8"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <h2 className="text-xl font-bold text-white mb-6">
              Task Completions by Type
            </h2>
            <div className="space-y-4">
              {[
                { label: "Daily Check-in", value: 8234, color: "bg-pink-500" },
                { label: "Quiz", value: 5621, color: "bg-purple-500" },
                { label: "Video", value: 12450, color: "bg-cyan-500" },
                { label: "Survey", value: 3421, color: "bg-orange-500" },
                { label: "Bonus", value: 2156, color: "bg-green-500" },
              ].map((item, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-gray-300">{item.label}</p>
                    <p className="text-sm font-semibold text-white">
                      {item.value}
                    </p>
                  </div>
                  <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className={`h-full ${item.color}`}
                      style={{
                        width: `${(item.value / 12450) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Withdrawal Statistics */}
          <div
            className="glass-card p-8"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <h2 className="text-xl font-bold text-white mb-6">
              Withdrawal Statistics
            </h2>
            <div className="space-y-4">
              {[
                { label: "Pending", value: 234, color: "text-yellow-400" },
                { label: "Approved", value: 1245, color: "text-green-400" },
                { label: "Rejected", value: 45, color: "text-red-400" },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10"
                >
                  <p className="text-sm text-gray-300">{item.label}</p>
                  <p className={`text-lg font-bold ${item.color}`}>
                    {item.value}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Referral Performance */}
          <div
            className="glass-card p-8"
            style={{
              boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
            }}
          >
            <h2 className="text-xl font-bold text-white mb-6">
              Referral Performance
            </h2>
            <div className="space-y-4">
              {[
                { label: "Total Referrals", value: "3,421" },
                { label: "Active Referrals", value: "2,156" },
                { label: "Referral Rate", value: "28%" },
                { label: "Avg Points per Referral", value: "200" },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10"
                >
                  <p className="text-sm text-gray-300">{item.label}</p>
                  <p className="text-lg font-bold text-cyan-400">
                    {item.value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

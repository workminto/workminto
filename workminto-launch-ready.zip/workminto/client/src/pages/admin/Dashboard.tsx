import { AdminLayout } from "@/components/AdminLayout";
import { StatCard } from "@/components/StatCard";
import { GradientButton } from "@/components/GradientButton";
import {
  Users,
  TrendingUp,
  Coins,
  AlertCircle,
  CheckCircle2,
  Activity,
  ArrowUpRight,
} from "lucide-react";

/**
 * Workminto Admin Dashboard
 * Overview of platform metrics and recent activity
 */
export default function AdminDashboard() {
  const stats = [
    {
      icon: Users,
      label: "Total Users",
      value: "12,543",
      change: { value: 12, isPositive: true },
      color: "pink" as const,
    },
    {
      icon: Activity,
      label: "Active Users (24h)",
      value: "3,421",
      change: { value: 8, isPositive: true },
      color: "cyan" as const,
    },
    {
      icon: Coins,
      label: "Points Distributed",
      value: "2.4M",
      change: { value: 5, isPositive: true },
      color: "orange" as const,
    },
    {
      icon: AlertCircle,
      label: "Pending Withdrawals",
      value: "234",
      change: { value: 3, isPositive: false },
      color: "purple" as const,
    },
  ];

  const recentActivity = [
    {
      id: 1,
      user: "John Doe",
      action: "Completed Daily Check-in",
      points: "+50",
      time: "2 mins ago",
      icon: CheckCircle2,
    },
    {
      id: 2,
      user: "Sarah Johnson",
      action: "Requested Withdrawal",
      points: "-1000",
      time: "5 mins ago",
      icon: AlertCircle,
    },
    {
      id: 3,
      user: "Rohit Sharma",
      action: "Completed Survey",
      points: "+150",
      time: "12 mins ago",
      icon: CheckCircle2,
    },
    {
      id: 4,
      user: "Priya Singh",
      action: "Joined via Referral",
      points: "+200",
      time: "18 mins ago",
      icon: TrendingUp,
    },
    {
      id: 5,
      user: "Amit Kumar",
      action: "Profile Completed",
      points: "+75",
      time: "25 mins ago",
      icon: CheckCircle2,
    },
  ];

  const systemStatus = [
    { label: "API Status", status: "Operational", color: "green" },
    { label: "Database", status: "Healthy", color: "green" },
    { label: "Email Service", status: "Operational", color: "green" },
    { label: "Payment Gateway", status: "Operational", color: "green" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-400">
            Platform overview and key metrics
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => (
            <StatCard key={idx} {...stat} />
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2 glass-card p-8" style={{ boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)" }}>
            <h2 className="text-2xl font-bold text-white mb-6">
              Recent Activity
            </h2>
            <div className="space-y-4">
              {recentActivity.map((activity) => {
                const Icon = activity.icon;
                return (
                  <div
                    key={activity.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 transition-all duration-200"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-10 h-10 rounded-lg bg-pink-500/20 border border-pink-500/50 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-pink-400" />
                      </div>
                      <div>
                        <p className="font-semibold text-white">
                          {activity.user}
                        </p>
                        <p className="text-xs text-gray-400">
                          {activity.action}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-pink-400">
                        {activity.points}
                      </p>
                      <p className="text-xs text-gray-400">{activity.time}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* System Status */}
          <div className="glass-card p-8" style={{ boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)" }}>
            <h2 className="text-2xl font-bold text-white mb-6">
              System Status
            </h2>
            <div className="space-y-4">
              {systemStatus.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10"
                >
                  <p className="text-sm text-gray-300">{item.label}</p>
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        item.color === "green"
                          ? "bg-green-400"
                          : "bg-yellow-400"
                      }`}
                    />
                    <p className="text-xs font-semibold text-gray-300">
                      {item.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="mt-8 space-y-3">
              <h3 className="text-sm font-semibold text-gray-300">
                Quick Actions
              </h3>
              <GradientButton className="w-full text-sm py-2">
                Create Announcement
              </GradientButton>
              <button className="w-full px-4 py-2 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold text-sm">
                View Audit Logs
              </button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

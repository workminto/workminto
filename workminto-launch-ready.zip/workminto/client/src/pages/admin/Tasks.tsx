import { AdminLayout } from "@/components/AdminLayout";
import { AdminTable } from "@/components/AdminTable";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";
import { Plus, Edit, Trash2 } from "lucide-react";

interface Task {
  id: string;
  name: string;
  type: string;
  reward: number;
  completions: number;
  status: "active" | "inactive" | "archived";
  createdDate: string;
}

/**
 * Workminto Task Management
 * Create, edit, delete tasks and manage rewards
 */
export default function TasksPage() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const tasks: Task[] = [
    {
      id: "1",
      name: "Daily Check-in",
      type: "Daily",
      reward: 50,
      completions: 8234,
      status: "active",
      createdDate: "June 1, 2024",
    },
    {
      id: "2",
      name: "Quiz Time",
      type: "Quiz",
      reward: 100,
      completions: 5621,
      status: "active",
      createdDate: "June 5, 2024",
    },
    {
      id: "3",
      name: "Watch Video",
      type: "Video",
      reward: 25,
      completions: 12450,
      status: "active",
      createdDate: "June 10, 2024",
    },
    {
      id: "4",
      name: "Profile Completion",
      type: "Bonus",
      reward: 75,
      completions: 3421,
      status: "active",
      createdDate: "June 15, 2024",
    },
    {
      id: "5",
      name: "Old Survey",
      type: "Survey",
      reward: 150,
      completions: 234,
      status: "archived",
      createdDate: "May 20, 2024",
    },
  ];

  const columns = [
    { key: "name" as const, label: "Task Name", sortable: true },
    { key: "type" as const, label: "Type", sortable: true },
    {
      key: "reward" as const,
      label: "Reward",
      sortable: true,
      render: (value: number) => (
        <span className="text-pink-400 font-semibold">+{value} pts</span>
      ),
    },
    {
      key: "completions" as const,
      label: "Completions",
      sortable: true,
    },
    {
      key: "status" as const,
      label: "Status",
      render: (value: string) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${
            value === "active"
              ? "bg-green-500/20 text-green-400 border border-green-500/50"
              : value === "inactive"
              ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/50"
              : "bg-gray-500/20 text-gray-400 border border-gray-500/50"
          }`}
        >
          {value.charAt(0).toUpperCase() + value.slice(1)}
        </span>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Task Management
            </h1>
            <p className="text-gray-400">
              Create and manage tasks for users
            </p>
          </div>
          <GradientButton
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Create Task
          </GradientButton>
        </div>

        {/* Task Table */}
        <AdminTable
          columns={columns}
          data={tasks}
          title="Tasks"
          onRowClick={setSelectedTask}
        />

        {/* Create Task Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div
              className="glass-card p-8 max-w-2xl w-full"
              style={{
                boxShadow: "0 0 40px rgba(255, 20, 147, 0.3)",
              }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">
                  Create New Task
                </h2>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Task Name
                  </label>
                  <input
                    type="text"
                    placeholder="Enter task name"
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Type
                    </label>
                    <select className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white transition-all duration-200">
                      <option>Daily</option>
                      <option>Quiz</option>
                      <option>Video</option>
                      <option>Survey</option>
                      <option>Bonus</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-2">
                      Reward Points
                    </label>
                    <input
                      type="number"
                      placeholder="Enter reward"
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    placeholder="Enter task description"
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
                  />
                </div>

                <div className="flex gap-4">
                  <GradientButton className="flex-1">
                    Create Task
                  </GradientButton>
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 px-4 py-3 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Task Details Modal */}
        {selectedTask && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div
              className="glass-card p-8 max-w-2xl w-full"
              style={{
                boxShadow: "0 0 40px rgba(255, 20, 147, 0.3)",
              }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">
                  {selectedTask.name}
                </h2>
                <button
                  onClick={() => setSelectedTask(null)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-400">Type</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedTask.type}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Reward</p>
                    <p className="text-lg font-semibold text-pink-400">
                      +{selectedTask.reward} points
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Completions</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedTask.completions}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Created</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedTask.createdDate}
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <GradientButton className="flex-1 flex items-center justify-center gap-2">
                    <Edit className="w-4 h-4" />
                    Edit Task
                  </GradientButton>
                  <button className="flex-1 px-4 py-3 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold flex items-center justify-center gap-2">
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

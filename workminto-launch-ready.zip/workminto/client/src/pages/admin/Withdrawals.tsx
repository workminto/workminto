import { AdminLayout } from "@/components/AdminLayout";
import { AdminTable } from "@/components/AdminTable";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";
import { CheckCircle2, XCircle, Clock } from "lucide-react";

interface Withdrawal {
  id: string;
  user: string;
  amount: string;
  points: number;
  method: string;
  requestedDate: string;
  status: "pending" | "approved" | "rejected";
}

/**
 * Workminto Withdrawal Management
 * Review and manage withdrawal requests
 */
export default function WithdrawalsPage() {
  const [selectedTab, setSelectedTab] = useState<"pending" | "approved" | "rejected">("pending");
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null);

  const withdrawals: Withdrawal[] = [
    {
      id: "1",
      user: "John Doe",
      amount: "$10.00",
      points: 1000,
      method: "PayPal",
      requestedDate: "June 20, 2024",
      status: "pending",
    },
    {
      id: "2",
      user: "Sarah Johnson",
      amount: "$25.00",
      points: 2500,
      method: "Amazon Gift Card",
      requestedDate: "June 19, 2024",
      status: "pending",
    },
    {
      id: "3",
      user: "Rohit Sharma",
      amount: "$15.00",
      points: 1500,
      method: "Google Play",
      requestedDate: "June 18, 2024",
      status: "approved",
    },
    {
      id: "4",
      user: "Priya Singh",
      amount: "$5.00",
      points: 500,
      method: "PayPal",
      requestedDate: "June 17, 2024",
      status: "approved",
    },
    {
      id: "5",
      user: "Amit Kumar",
      amount: "$20.00",
      points: 2000,
      method: "iTunes Card",
      requestedDate: "June 16, 2024",
      status: "rejected",
    },
  ];

  const filteredWithdrawals = withdrawals.filter((w) => w.status === selectedTab);

  const columns = [
    { key: "user" as const, label: "User", sortable: true },
    { key: "amount" as const, label: "Amount", sortable: true },
    { key: "method" as const, label: "Method", sortable: true },
    {
      key: "requestedDate" as const,
      label: "Requested",
      sortable: true,
    },
    {
      key: "status" as const,
      label: "Status",
      render: (value: string) => {
        const Icon =
          value === "pending"
            ? Clock
            : value === "approved"
            ? CheckCircle2
            : XCircle;
        return (
          <div className="flex items-center gap-2">
            <Icon
              className={`w-4 h-4 ${
                value === "pending"
                  ? "text-yellow-400"
                  : value === "approved"
                  ? "text-green-400"
                  : "text-red-400"
              }`}
            />
            <span
              className={`text-xs font-semibold ${
                value === "pending"
                  ? "text-yellow-400"
                  : value === "approved"
                  ? "text-green-400"
                  : "text-red-400"
              }`}
            >
              {value.charAt(0).toUpperCase() + value.slice(1)}
            </span>
          </div>
        );
      },
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Withdrawal Management
          </h1>
          <p className="text-gray-400">
            Review and manage user withdrawal requests
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-white/10">
          {(["pending", "approved", "rejected"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setSelectedTab(tab)}
              className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
                selectedTab === tab
                  ? "border-pink-500 text-white"
                  : "border-transparent text-gray-400 hover:text-white"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)} (
              {withdrawals.filter((w) => w.status === tab).length})
            </button>
          ))}
        </div>

        {/* Withdrawals Table */}
        <AdminTable
          columns={columns}
          data={filteredWithdrawals}
          title={`${selectedTab.charAt(0).toUpperCase() + selectedTab.slice(1)} Withdrawals`}
          onRowClick={setSelectedWithdrawal}
        />

        {/* Withdrawal Details Modal */}
        {selectedWithdrawal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div
              className="glass-card p-8 max-w-2xl w-full"
              style={{
                boxShadow: "0 0 40px rgba(255, 20, 147, 0.3)",
              }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">
                  Withdrawal Request
                </h2>
                <button
                  onClick={() => setSelectedWithdrawal(null)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                {/* Request Details */}
                <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-white/5 border border-white/10">
                  <div>
                    <p className="text-sm text-gray-400">User</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedWithdrawal.user}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Amount</p>
                    <p className="text-lg font-semibold text-pink-400">
                      {selectedWithdrawal.amount}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Points</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedWithdrawal.points}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Method</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedWithdrawal.method}
                    </p>
                  </div>
                </div>

                {/* Status Info */}
                <div>
                  <p className="text-sm text-gray-400 mb-2">Current Status</p>
                  <div
                    className={`px-4 py-3 rounded-lg border ${
                      selectedWithdrawal.status === "pending"
                        ? "bg-yellow-500/20 border-yellow-500/50 text-yellow-400"
                        : selectedWithdrawal.status === "approved"
                        ? "bg-green-500/20 border-green-500/50 text-green-400"
                        : "bg-red-500/20 border-red-500/50 text-red-400"
                    }`}
                  >
                    {selectedWithdrawal.status.charAt(0).toUpperCase() +
                      selectedWithdrawal.status.slice(1)}
                  </div>
                </div>

                {/* Actions */}
                {selectedWithdrawal.status === "pending" && (
                  <div className="flex gap-4">
                    <GradientButton className="flex-1 flex items-center justify-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Approve
                    </GradientButton>
                    <button className="flex-1 px-4 py-3 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold flex items-center justify-center gap-2">
                      <XCircle className="w-4 h-4" />
                      Reject
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

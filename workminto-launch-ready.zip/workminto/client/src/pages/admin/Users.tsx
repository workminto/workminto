import { AdminLayout } from "@/components/AdminLayout";
import { AdminTable } from "@/components/AdminTable";
import { GradientButton } from "@/components/GradientButton";
import { useState } from "react";
import { MoreVertical, Shield, Ban } from "lucide-react";

interface User {
  id: string;
  name: string;
  email: string;
  joinedDate: string;
  points: number;
  status: "active" | "suspended" | "banned";
  referrals: number;
  totalEarned: string;
}

/**
 * Workminto User Management
 * Manage users, view details, suspend/ban users
 */
export default function UsersPage() {
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const users: User[] = [
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      joinedDate: "June 15, 2024",
      points: 1250,
      status: "active",
      referrals: 5,
      totalEarned: "$12.50",
    },
    {
      id: "2",
      name: "Sarah Johnson",
      email: "sarah@example.com",
      joinedDate: "June 10, 2024",
      points: 2100,
      status: "active",
      referrals: 8,
      totalEarned: "$21.00",
    },
    {
      id: "3",
      name: "Rohit Sharma",
      email: "rohit@example.com",
      joinedDate: "June 5, 2024",
      points: 3450,
      status: "active",
      referrals: 12,
      totalEarned: "$34.50",
    },
    {
      id: "4",
      name: "Priya Singh",
      email: "priya@example.com",
      joinedDate: "May 28, 2024",
      points: 890,
      status: "suspended",
      referrals: 2,
      totalEarned: "$8.90",
    },
    {
      id: "5",
      name: "Amit Kumar",
      email: "amit@example.com",
      joinedDate: "May 20, 2024",
      points: 5600,
      status: "active",
      referrals: 18,
      totalEarned: "$56.00",
    },
  ];

  const columns = [
    { key: "name" as const, label: "Name", sortable: true },
    { key: "email" as const, label: "Email", sortable: true },
    {
      key: "joinedDate" as const,
      label: "Joined",
      sortable: true,
    },
    {
      key: "points" as const,
      label: "Points",
      sortable: true,
      render: (value: number) => <span className="text-pink-400 font-semibold">{value}</span>,
    },
    {
      key: "referrals" as const,
      label: "Referrals",
      sortable: true,
    },
    {
      key: "status" as const,
      label: "Status",
      render: (value: string) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${
            value === "active"
              ? "bg-green-500/20 text-green-400 border border-green-500/50"
              : value === "suspended"
              ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/50"
              : "bg-red-500/20 text-red-400 border border-red-500/50"
          }`}
        >
          {value.charAt(0).toUpperCase() + value.slice(1)}
        </span>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              User Management
            </h1>
            <p className="text-gray-400">
              Manage users, view details, and take actions
            </p>
          </div>
          <GradientButton>Add User</GradientButton>
        </div>

        {/* User Table */}
        <AdminTable
          columns={columns}
          data={users}
          title="Users"
          onRowClick={setSelectedUser}
        />

        {/* User Details Modal */}
        {selectedUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div
              className="glass-card p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              style={{
                boxShadow: "0 0 40px rgba(255, 20, 147, 0.3)",
              }}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">
                  User Details
                </h2>
                <button
                  onClick={() => setSelectedUser(null)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-6">
                {/* User Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-400">Name</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedUser.name}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Email</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedUser.email}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Joined</p>
                    <p className="text-lg font-semibold text-white">
                      {selectedUser.joinedDate}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Status</p>
                    <p
                      className={`text-lg font-semibold ${
                        selectedUser.status === "active"
                          ? "text-green-400"
                          : "text-yellow-400"
                      }`}
                    >
                      {selectedUser.status.charAt(0).toUpperCase() +
                        selectedUser.status.slice(1)}
                    </p>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 p-4 rounded-lg bg-white/5 border border-white/10">
                  <div>
                    <p className="text-xs text-gray-400">Points</p>
                    <p className="text-2xl font-bold text-pink-400">
                      {selectedUser.points}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Referrals</p>
                    <p className="text-2xl font-bold text-cyan-400">
                      {selectedUser.referrals}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Total Earned</p>
                    <p className="text-2xl font-bold text-orange-400">
                      {selectedUser.totalEarned}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-4">
                  <GradientButton className="flex-1">
                    View Activity
                  </GradientButton>
                  {selectedUser.status === "active" && (
                    <>
                      <button className="flex-1 px-4 py-3 rounded-lg border border-yellow-500/50 hover:border-yellow-500 transition-all duration-200 text-yellow-400 font-semibold flex items-center justify-center gap-2">
                        <Shield className="w-4 h-4" />
                        Suspend
                      </button>
                      <button className="flex-1 px-4 py-3 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold flex items-center justify-center gap-2">
                        <Ban className="w-4 h-4" />
                        Ban
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

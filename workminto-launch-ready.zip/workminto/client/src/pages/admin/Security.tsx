import { AdminLayout } from "@/components/AdminLayout";
import { GradientButton } from "@/components/GradientButton";
import { Lock, Key, Shield, AlertTriangle, CheckCircle2 } from "lucide-react";

/**
 * Workminto Security Settings
 * Admin security configuration and monitoring
 */
export default function SecurityPage() {
  const securitySettings = [
    {
      icon: Lock,
      title: "Two-Factor Authentication",
      description: "Require 2FA for all admin accounts",
      status: "enabled",
      action: "Manage",
    },
    {
      icon: Key,
      title: "API Keys",
      description: "Manage API keys and access tokens",
      status: "enabled",
      action: "View Keys",
    },
    {
      icon: Shield,
      title: "IP Whitelist",
      description: "Restrict admin access to specific IPs",
      status: "disabled",
      action: "Configure",
    },
    {
      icon: AlertTriangle,
      title: "Rate Limiting",
      description: "Prevent brute force attacks",
      status: "enabled",
      action: "Settings",
    },
  ];

  const sessionActivity = [
    {
      id: 1,
      admin: "Admin Sarah",
      action: "Logged in",
      ip: "192.168.1.100",
      device: "Chrome on Windows",
      time: "2 hours ago",
      status: "active",
    },
    {
      id: 2,
      admin: "Admin John",
      action: "Logged in",
      ip: "192.168.1.101",
      device: "Safari on macOS",
      time: "5 hours ago",
      status: "active",
    },
    {
      id: 3,
      admin: "Admin Mike",
      action: "Logged out",
      ip: "192.168.1.102",
      device: "Chrome on Windows",
      time: "12 hours ago",
      status: "inactive",
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Security Settings
          </h1>
          <p className="text-gray-400">
            Configure security policies and monitor access
          </p>
        </div>

        {/* Security Features */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-white">Security Features</h2>
          {securitySettings.map((setting, idx) => {
            const Icon = setting.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 flex items-center justify-between"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/20 border border-pink-500/50 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <p className="font-bold text-white">{setting.title}</p>
                    <p className="text-sm text-gray-400">
                      {setting.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      setting.status === "enabled"
                        ? "bg-green-500/20 text-green-400 border border-green-500/50"
                        : "bg-gray-500/20 text-gray-400 border border-gray-500/50"
                    }`}
                  >
                    {setting.status.charAt(0).toUpperCase() +
                      setting.status.slice(1)}
                  </div>
                  <button className="px-4 py-2 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold text-sm">
                    {setting.action}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Active Sessions */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-white">Active Admin Sessions</h2>
          <div className="space-y-4">
            {sessionActivity.map((session) => (
              <div
                key={session.id}
                className="glass-card p-6"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="font-bold text-white">{session.admin}</p>
                    <p className="text-sm text-gray-400 mt-1">
                      {session.action} • {session.time}
                    </p>
                  </div>
                  <div
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      session.status === "active"
                        ? "bg-green-500/20 text-green-400 border border-green-500/50"
                        : "bg-gray-500/20 text-gray-400 border border-gray-500/50"
                    }`}
                  >
                    {session.status.charAt(0).toUpperCase() +
                      session.status.slice(1)}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">IP Address</p>
                    <p className="text-white font-mono">{session.ip}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Device</p>
                    <p className="text-white">{session.device}</p>
                  </div>
                </div>

                {session.status === "active" && (
                  <button className="mt-4 px-4 py-2 rounded-lg border border-red-500/50 hover:border-red-500 transition-all duration-200 text-red-400 font-semibold text-sm">
                    Revoke Session
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Security Policies */}
        <div
          className="glass-card p-8"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <h2 className="text-xl font-bold text-white mb-6">
            Security Policies
          </h2>

          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-white">
                  Password Requirements
                </p>
                <p className="text-sm text-gray-400 mt-1">
                  Minimum 12 characters, uppercase, lowercase, numbers, and
                  symbols
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-white">Session Timeout</p>
                <p className="text-sm text-gray-400 mt-1">
                  30 minutes of inactivity before automatic logout
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-white">
                  Encryption Standards
                </p>
                <p className="text-sm text-gray-400 mt-1">
                  All data encrypted with AES-256 at rest and TLS 1.3 in transit
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-white">
                  Compliance Standards
                </p>
                <p className="text-sm text-gray-400 mt-1">
                  GDPR, CCPA, and SOC 2 Type II compliant
                </p>
              </div>
            </div>
          </div>

          <GradientButton className="w-full mt-8">
            Update Security Policies
          </GradientButton>
        </div>
      </div>
    </AdminLayout>
  );
}

import { Header } from "@/components/Header";

/**
 * Workminto Privacy Policy Page
 */
export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Privacy Policy
          </h1>
          <p className="text-gray-400 mt-4">
            Last updated: June 2024
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="glass-card p-8 md:p-12 max-w-3xl space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                1. Introduction
              </h2>
              <p className="text-gray-300 leading-relaxed">
                Workminto ("we", "us", or "our") operates the Workminto platform.
                This page informs you of our policies regarding the collection, use,
                and disclosure of personal data when you use our service.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                2. Information Collection and Use
              </h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                We collect several different types of information for various purposes
                to provide and improve our service to you.
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>• Personal Data: Name, email address, phone number</li>
                <li>• Usage Data: Browser type, IP address, pages visited</li>
                <li>• Cookies and tracking technologies</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                3. Use of Data
              </h2>
              <p className="text-gray-300 leading-relaxed">
                Workminto uses the collected data for various purposes:
              </p>
              <ul className="space-y-2 text-gray-300 mt-4">
                <li>• To provide and maintain our service</li>
                <li>• To notify you about changes to our service</li>
                <li>• To allow you to participate in interactive features</li>
                <li>• To provide customer support</li>
                <li>• To gather analysis or valuable information</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                4. Security of Data
              </h2>
              <p className="text-gray-300 leading-relaxed">
                The security of your data is important to us but remember that no
                method of transmission over the Internet or method of electronic storage
                is 100% secure. While we strive to use commercially acceptable means to
                protect your personal data, we cannot guarantee its absolute security.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                5. Contact Us
              </h2>
              <p className="text-gray-300 leading-relaxed">
                If you have any questions about this Privacy Policy, please contact us at:
              </p>
              <p className="text-gray-300 mt-4">
                Email: privacy@workminto.com
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

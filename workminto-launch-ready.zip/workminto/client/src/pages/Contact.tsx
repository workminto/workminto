import { Header } from "@/components/Header";
import { AuthInput } from "@/components/AuthInput";
import { GradientButton } from "@/components/GradientButton";
import { Mail, Phone, MapPin, Loader2 } from "lucide-react";
import { useState } from "react";

/**
 * Workminto Contact Page
 * Contact form and support information
 */
export default function Contact() {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setLoading(false);
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="flex flex-col gap-6 max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Get in Touch
            </h1>
            <p className="text-lg md:text-xl text-gray-400">
              Have a question? We'd love to hear from you.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {/* Email */}
            <div className="glass-card p-8 flex flex-col gap-4 text-center">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white mx-auto">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Email</h3>
              <p className="text-gray-400">support@workminto.com</p>
            </div>

            {/* Phone */}
            <div className="glass-card p-8 flex flex-col gap-4 text-center">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white mx-auto">
                <Phone className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Phone</h3>
              <p className="text-gray-400">+1 (555) 123-4567</p>
            </div>

            {/* Address */}
            <div className="glass-card p-8 flex flex-col gap-4 text-center">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white mx-auto">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Address</h3>
              <p className="text-gray-400">San Francisco, CA</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="glass-card p-8 md:p-12 max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-white mb-8">Send us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <AuthInput
                label="Name"
                name="name"
                type="text"
                placeholder="Your name"
                value={formData.name}
                onChange={handleChange}
              />

              <AuthInput
                label="Email"
                name="email"
                type="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={handleChange}
              />

              <AuthInput
                label="Subject"
                name="subject"
                type="text"
                placeholder="How can we help?"
                value={formData.subject}
                onChange={handleChange}
              />

              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-gray-300">
                  Message
                </label>
                <textarea
                  name="message"
                  placeholder="Your message..."
                  value={formData.message}
                  onChange={handleChange}
                  rows={6}
                  className="bg-white/5 border border-white/10 text-white placeholder-gray-500 rounded-lg p-3 focus:border-pink-500 focus:ring-pink-500/20 transition-all duration-200"
                />
              </div>

              <GradientButton
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  "Send Message"
                )}
              </GradientButton>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

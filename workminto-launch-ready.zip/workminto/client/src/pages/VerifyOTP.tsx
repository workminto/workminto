import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { AuthLayout } from "@/components/AuthLayout";
import { AuthCard } from "@/components/AuthCard";
import { GradientButton } from "@/components/GradientButton";
import { Mail, Loader2, RotateCcw } from "lucide-react";

/**
 * Workminto OTP Verification Page
 * Premium OTP input with 6 digit code
 * Routes to dashboard on successful verification
 */
export default function VerifyOTP() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState("");
  const [resendTimer, setResendTimer] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setError("");

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const otpCode = otp.join("");
    if (otpCode.length !== 6) {
      setError("Please enter all 6 digits");
      return;
    }

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Route to dashboard
    setTimeout(() => {
      setLocation("/");
    }, 800);
  };

  const handleResend = async () => {
    setResendTimer(60);
    setOtp(["", "", "", "", "", ""]);
    inputRefs.current[0]?.focus();
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500));
  };

  return (
    <AuthLayout>
      <AuthCard>
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Verify Email
          </h1>
          <p className="text-gray-400">
            Enter the 6-digit code sent to your email
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          {/* OTP Inputs */}
          <div className="flex flex-col gap-4">
            <div className="flex gap-2 md:gap-3 justify-center">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  ref={(el) => {
                    inputRefs.current[index] = el;
                  }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className="w-12 h-12 md:w-14 md:h-14 text-center text-2xl font-bold rounded-lg bg-white/5 border border-white/10 text-white focus:border-pink-500 focus:ring-pink-500/20 transition-all duration-200"
                />
              ))}
            </div>

            {error && (
              <p className="text-center text-sm text-red-400">{error}</p>
            )}
          </div>

          {/* Submit Button */}
          <GradientButton
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify Email"
            )}
          </GradientButton>
        </form>

        {/* Resend Code */}
        <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
          <p className="text-sm text-gray-400 text-center">
            Didn't receive the code?
          </p>
          <button
            onClick={handleResend}
            disabled={resendTimer > 0}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-full border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RotateCcw className="w-4 h-4" />
            {resendTimer > 0 ? `Resend in ${resendTimer}s` : "Resend Code"}
          </button>
        </div>

        {/* Email Info */}
        <div className="flex items-start gap-3 p-4 rounded-lg bg-white/5 border border-white/10">
          <Mail className="w-5 h-5 text-pink-400 flex-shrink-0 mt-0.5" />
          <p className="text-xs md:text-sm text-gray-300">
            Check your email for the verification code. It may take a few
            minutes to arrive.
          </p>
        </div>
      </AuthCard>
    </AuthLayout>
  );
}

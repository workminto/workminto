import { Header } from "@/components/Header";
import { GradientButton } from "@/components/GradientButton";
import { ArrowRight, Check } from "lucide-react";

/**
 * Workminto Pricing Page
 * Shows pricing tiers and plans
 */
export default function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "$0",
      description: "Perfect for getting started",
      features: [
        "Daily check-ins",
        "Basic tasks",
        "Email support",
        "Instant rewards",
      ],
    },
    {
      name: "Premium",
      price: "$4.99",
      period: "/month",
      description: "For serious earners",
      features: [
        "Everything in Free",
        "Priority tasks",
        "Exclusive surveys",
        "Bonus multipliers",
        "Priority support",
      ],
      highlighted: true,
    },
    {
      name: "Elite",
      price: "$9.99",
      period: "/month",
      description: "Maximum earning potential",
      features: [
        "Everything in Premium",
        "VIP tasks",
        "Cashback rewards",
        "Referral bonuses",
        "Dedicated support",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="flex flex-col gap-6 max-w-3xl text-center mx-auto">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Simple, Transparent Pricing
            </h1>
            <p className="text-lg md:text-xl text-gray-400">
              Choose the plan that works for you. Upgrade or downgrade anytime.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, idx) => (
              <div
                key={idx}
                className={`glass-card p-8 flex flex-col gap-6 ${
                  plan.highlighted ? "md:scale-105" : ""
                }`}
                style={{
                  boxShadow: plan.highlighted
                    ? "0 0 40px rgba(255, 20, 147, 0.3)"
                    : "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div>
                  <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
                  <p className="text-sm text-gray-400 mt-1">
                    {plan.description}
                  </p>
                </div>

                <div>
                  <span className="text-4xl font-bold text-white">
                    {plan.price}
                  </span>
                  {plan.period && (
                    <span className="text-gray-400">{plan.period}</span>
                  )}
                </div>

                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-pink-400 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <a href="/auth/signup" className="w-full">
                  <GradientButton className="w-full">
                    Get Started
                  </GradientButton>
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

import { Header } from "@/components/Header";

/**
 * Workminto Cookie Policy Page
 */
export default function CookiePolicy() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Cookie Policy
          </h1>
          <p className="text-gray-400 mt-4">
            Last updated: June 2024
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="glass-card p-8 md:p-12 max-w-3xl space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                1. What are Cookies?
              </h2>
              <p className="text-gray-300 leading-relaxed">
                Cookies are small pieces of text stored on your device when you visit
                our website. They help us remember your preferences and improve your
                experience on Workminto.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                2. Types of Cookies We Use
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    Essential Cookies
                  </h3>
                  <p className="text-gray-300">
                    These cookies are necessary for the website to function properly.
                    They enable core functionality such as security and network management.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    Performance Cookies
                  </h3>
                  <p className="text-gray-300">
                    These cookies help us understand how visitors interact with our website
                    by collecting and reporting information anonymously.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    Functional Cookies
                  </h3>
                  <p className="text-gray-300">
                    These cookies enable enhanced functionality and personalization,
                    such as remembering your login information.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                3. Managing Cookies
              </h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                Most web browsers allow you to control cookies through their settings.
                You can typically find these settings in your browser's "Preferences" or
                "Settings" menu. Please note that disabling cookies may affect the
                functionality of our website.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                4. Third-Party Cookies
              </h2>
              <p className="text-gray-300 leading-relaxed">
                We may allow third-party service providers to place cookies on your device
                for analytics and advertising purposes. These third parties have their own
                privacy policies governing their use of cookies.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                5. Contact Us
              </h2>
              <p className="text-gray-300 leading-relaxed">
                If you have any questions about this Cookie Policy, please contact us at:
              </p>
              <p className="text-gray-300 mt-4">
                Email: cookies@workminto.com
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

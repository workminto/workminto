import { Header } from "@/components/Header";

/**
 * Workminto Terms of Service Page
 */
export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            Terms of Service
          </h1>
          <p className="text-gray-400 mt-4">
            Last updated: June 2024
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="glass-card p-8 md:p-12 max-w-3xl space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                1. Agreement to Terms
              </h2>
              <p className="text-gray-300 leading-relaxed">
                By accessing and using this website, you accept and agree to be bound
                by the terms and provision of this agreement. If you do not agree to
                abide by the above, please do not use this service.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                2. Use License
              </h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                Permission is granted to temporarily download one copy of the materials
                (information or software) on Workminto's website for personal,
                non-commercial transitory viewing only. This is the grant of a license,
                not a transfer of title, and under this license you may not:
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>• Modifying or copying the materials</li>
                <li>• Using the materials for any commercial purpose</li>
                <li>• Attempting to decompile or reverse engineer any software</li>
                <li>• Removing any copyright or other proprietary notations</li>
                <li>• Transferring the materials to another person or "mirroring"</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                3. Disclaimer
              </h2>
              <p className="text-gray-300 leading-relaxed">
                The materials on Workminto's website are provided on an 'as is' basis.
                Workminto makes no warranties, expressed or implied, and hereby disclaims
                and negates all other warranties including, without limitation, implied
                warranties or conditions of merchantability, fitness for a particular
                purpose, or non-infringement of intellectual property or other violation
                of rights.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                4. Limitations
              </h2>
              <p className="text-gray-300 leading-relaxed">
                In no event shall Workminto or its suppliers be liable for any damages
                (including, without limitation, damages for loss of data or profit, or
                due to business interruption) arising out of the use or inability to use
                the materials on Workminto's website.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                5. Accuracy of Materials
              </h2>
              <p className="text-gray-300 leading-relaxed">
                The materials appearing on Workminto's website could include technical,
                typographical, or photographic errors. Workminto does not warrant that
                any of the materials on its website are accurate, complete, or current.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-white mb-4">
                6. Contact Us
              </h2>
              <p className="text-gray-300 leading-relaxed">
                If you have any questions about these Terms of Service, please contact us at:
              </p>
              <p className="text-gray-300 mt-4">
                Email: legal@workminto.com
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { AuthLayout } from "@/components/AuthLayout";
import { AuthCard } from "@/components/AuthCard";
import { AuthInput } from "@/components/AuthInput";
import { GradientButton } from "@/components/GradientButton";
import { Mail, Loader2, ArrowLeft } from "lucide-react";

/**
 * Workminto Forgot Password Page
 * Premium forgot password form with email input
 * Routes to OTP verification on successful submission
 */
export default function ForgotPassword() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    if (error) setError("");
  };

  const validateForm = () => {
    if (!email.trim()) {
      setError("Email is required");
      return false;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setSuccess(true);
    setSubmitted(true);

    // Route to reset password after delay
    setTimeout(() => {
      setLocation("/auth/reset-password");
    }, 2000);
  };

  return (
    <AuthLayout>
      <AuthCard>
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Reset Password
          </h1>
          <p className="text-gray-400">
            Enter your email to receive a reset link
          </p>
        </div>

        {!submitted ? (
          <>
            {/* Form */}
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <AuthInput
                label="Email Address"
                name="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={handleChange}
                error={error}
                success={success}
                icon={<Mail className="w-5 h-5" />}
              />

              {/* Submit Button */}
              <GradientButton
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Sending...
                  </>
                ) : (
                  "Send Reset Link"
                )}
              </GradientButton>
            </form>

            {/* Back to Login */}
            <button
              onClick={() => setLocation("/auth/login")}
              className="flex items-center justify-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Sign In
            </button>
          </>
        ) : (
          <>
            {/* Success Message */}
            <div className="flex flex-col gap-4 py-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-500/20 border border-green-500/50 mx-auto">
                <svg
                  className="w-6 h-6 text-green-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div className="text-center">
                <h2 className="text-xl font-bold text-white mb-2">
                  Check Your Email
                </h2>
                <p className="text-gray-400">
                  We've sent a password reset link to{" "}
                  <span className="text-pink-400 font-semibold">{email}</span>
                </p>
              </div>
            </div>

            {/* Info Box */}
            <div className="flex items-start gap-3 p-4 rounded-lg bg-white/5 border border-white/10">
              <Mail className="w-5 h-5 text-pink-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs md:text-sm text-gray-300">
                The link will expire in 1 hour. If you don't receive it, check
                your spam folder.
              </p>
            </div>

            {/* Redirecting Message */}
            <p className="text-center text-sm text-gray-500">
              Redirecting to reset password...
            </p>
          </>
        )}
      </AuthCard>
    </AuthLayout>
  );
}

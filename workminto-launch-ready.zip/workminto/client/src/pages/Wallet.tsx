import { AppLayout } from "@/components/AppLayout";
import { GradientButton } from "@/components/GradientButton";
import { Wallet as WalletIcon, TrendingDown, History, ArrowUpRight } from "lucide-react";
import { useState } from "react";

/**
 * Workminto Wallet Page
 * Display points balance, redemption history, and withdrawal options
 */
export default function Wallet() {
  const [activeTab, setActiveTab] = useState<"balance" | "history">("balance");

  const redeemOptions = [
    {
      id: 1,
      name: "Amazon Gift Card",
      minPoints: 1000,
      value: "$10",
      icon: "🛍️",
    },
    {
      id: 2,
      name: "PayPal Cash",
      minPoints: 500,
      value: "$5",
      icon: "💰",
    },
    {
      id: 3,
      name: "Google Play",
      minPoints: 750,
      value: "$7.50",
      icon: "🎮",
    },
    {
      id: 4,
      name: "iTunes Card",
      minPoints: 750,
      value: "$7.50",
      icon: "🎵",
    },
  ];

  const redemptionHistory = [
    {
      id: 1,
      item: "Amazon Gift Card",
      points: -1000,
      value: "$10",
      date: "June 15, 2024",
      status: "Completed",
    },
    {
      id: 2,
      item: "PayPal Cash",
      points: -500,
      value: "$5",
      date: "June 10, 2024",
      status: "Completed",
    },
    {
      id: 3,
      item: "Google Play",
      points: -750,
      value: "$7.50",
      date: "June 5, 2024",
      status: "Completed",
    },
  ];

  return (
    <AppLayout activeTab="wallet">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Wallet
          </h1>
          <p className="text-gray-400">
            Manage your points and redeem rewards
          </p>
        </div>

        {/* Points Balance Card */}
        <div
          className="glass-card p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8"
          style={{
            boxShadow: "0 0 40px rgba(255, 20, 147, 0.2)",
          }}
        >
          <div className="flex flex-col gap-4">
            <p className="text-gray-400 text-sm font-medium">Available Points</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white">1,250</h1>
            <p className="text-gray-400 text-sm">≈ $12.50 USD</p>
          </div>
          <div className="flex gap-4 flex-col sm:flex-row w-full md:w-auto">
            <GradientButton className="flex-1 md:flex-none">
              Redeem Points
            </GradientButton>
            <button className="px-6 py-3 rounded-full border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold">
              Withdraw
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-white/10">
          <button
            onClick={() => setActiveTab("balance")}
            className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
              activeTab === "balance"
                ? "border-pink-500 text-white"
                : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            Redeem Options
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
              activeTab === "history"
                ? "border-pink-500 text-white"
                : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            Redemption History
          </button>
        </div>

        {/* Redeem Options */}
        {activeTab === "balance" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {redeemOptions.map((option) => (
              <div
                key={option.id}
                className="glass-card p-6 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-3xl mb-2">{option.icon}</p>
                    <h3 className="text-lg font-bold text-white">
                      {option.name}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">
                      Minimum {option.minPoints} points
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-pink-400">
                      {option.value}
                    </p>
                  </div>
                </div>

                <GradientButton className="w-full text-sm py-2">
                  Redeem
                </GradientButton>
              </div>
            ))}
          </div>
        )}

        {/* Redemption History */}
        {activeTab === "history" && (
          <div className="space-y-4">
            {redemptionHistory.map((item) => (
              <div
                key={item.id}
                className="glass-card p-6 flex items-center justify-between"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/20 border border-pink-500/50 flex items-center justify-center">
                    <ArrowUpRight className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <p className="font-bold text-white">{item.item}</p>
                    <p className="text-xs text-gray-400">{item.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-pink-400">{item.points}</p>
                  <p className="text-xs text-gray-400">{item.value}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Withdrawal Section */}
        <div
          className="glass-card p-8"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <h2 className="text-2xl font-bold text-white mb-6">
            Withdrawal Requests
          </h2>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-white/5 border border-white/10">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-white">No pending requests</p>
                  <p className="text-sm text-gray-400">
                    Request a withdrawal to cash out your points
                  </p>
                </div>
                <GradientButton className="text-sm py-2 px-4">
                  Request Withdrawal
                </GradientButton>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

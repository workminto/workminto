import { Header } from "@/components/Header";
import { Shield, Lock, Eye, AlertCircle } from "lucide-react";

/**
 * Workminto Security Page
 * Details about security practices and data protection
 */
export default function Security() {
  const features = [
    {
      icon: <Shield className="w-8 h-8" />,
      title: "SSL Encryption",
      description:
        "All data is encrypted in transit using industry-standard SSL/TLS protocols.",
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: "Data Protection",
      description:
        "Your personal information is encrypted at rest and protected by multiple security layers.",
    },
    {
      icon: <Eye className="w-8 h-8" />,
      title: "Privacy First",
      description:
        "We never sell your data. Your privacy is our top priority.",
    },
    {
      icon: <AlertCircle className="w-8 h-8" />,
      title: "GDPR Compliant",
      description:
        "We fully comply with GDPR and other international data protection regulations.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="flex flex-col gap-6 max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Your Security is Our Priority
            </h1>
            <p className="text-lg md:text-xl text-gray-400">
              We use enterprise-grade security to protect your data and privacy.
            </p>
          </div>
        </div>
      </section>

      {/* Security Features */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, idx) => (
              <div
                key={idx}
                className="glass-card p-8 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-white">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Details Section */}
      <section className="w-full py-20 md:py-32 bg-gradient-to-b from-black/20 to-background">
        <div className="container">
          <div className="glass-card p-8 md:p-12 max-w-3xl">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">
              Security Measures
            </h2>
            <ul className="space-y-4 text-gray-300">
              <li className="flex gap-3">
                <span className="text-pink-400 font-bold">•</span>
                <span>
                  Two-factor authentication (2FA) for account protection
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-pink-400 font-bold">•</span>
                <span>
                  Regular security audits and penetration testing
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-pink-400 font-bold">•</span>
                <span>
                  Secure payment processing with PCI DSS compliance
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-pink-400 font-bold">•</span>
                <span>
                  Automatic backups and disaster recovery systems
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-pink-400 font-bold">•</span>
                <span>
                  Dedicated security team monitoring 24/7
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

import { AppLayout } from "@/components/AppLayout";
import { GradientButton } from "@/components/GradientButton";
import { Zap, Gift, Users, TrendingUp, Calendar, Clock } from "lucide-react";

/**
 * Workminto Dashboard
 * Main user dashboard showing points, tasks, and activity
 */
export default function Dashboard() {
  const stats = [
    { label: "Total Points", value: "1,250", icon: Zap, color: "from-pink-500 to-orange-500" },
    { label: "Tasks Done", value: "42", icon: Calendar, color: "from-purple-500 to-pink-500" },
    { label: "Referrals", value: "12", icon: Users, color: "from-blue-500 to-purple-500" },
    { label: "This Month", value: "+450", icon: TrendingUp, color: "from-green-500 to-blue-500" },
  ];

  const recentActivity = [
    {
      id: 1,
      title: "Daily Check-in",
      points: "+50",
      time: "Today, 08:30 AM",
      status: "completed",
    },
    {
      id: 2,
      title: "Quiz Time",
      points: "+100",
      time: "Today, 07:45 AM",
      status: "completed",
    },
    {
      id: 3,
      title: "Watch Video",
      points: "+25",
      time: "Yesterday, 09:15 PM",
      status: "completed",
    },
    {
      id: 4,
      title: "Refer a Friend",
      points: "+200",
      time: "3 days ago",
      status: "completed",
    },
  ];

  return (
    <AppLayout activeTab="dashboard">
      <div className="space-y-8">
        {/* Points Balance Card */}
        <div
          className="glass-card p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8"
          style={{
            boxShadow: "0 0 40px rgba(255, 20, 147, 0.2)",
          }}
        >
          <div className="flex flex-col gap-4">
            <p className="text-gray-400 text-sm font-medium">Your Points Balance</p>
            <h1 className="text-5xl md:text-6xl font-bold text-white">1,250</h1>
            <p className="text-gray-400 text-sm">≈ $12.50 USD</p>
          </div>
          <div className="flex gap-4 flex-col sm:flex-row w-full md:w-auto">
            <GradientButton className="flex-1 md:flex-none">
              Redeem Now
            </GradientButton>
            <button className="px-6 py-3 rounded-full border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold">
              History
            </button>
          </div>
        </div>

        {/* Daily Check-in Card */}
        <div
          className="glass-card p-8 flex flex-col gap-4"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white">Daily Check-in</h3>
              <p className="text-gray-400 text-sm">Get 50 points every day</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-pink-400">+50</p>
              <p className="text-xs text-gray-400">points</p>
            </div>
          </div>
          <GradientButton className="w-full">Claim Now</GradientButton>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div
                  className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center text-white`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{stat.label}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Recent Activity */}
        <div className="glass-card p-8" style={{ boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)" }}>
          <h2 className="text-2xl font-bold text-white mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 transition-all duration-200"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/20 border border-pink-500/50 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">{activity.title}</p>
                    <p className="text-xs text-gray-400">{activity.time}</p>
                  </div>
                </div>
                <p className="font-bold text-pink-400">{activity.points}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <a href="/app/tasks">
            <div className="glass-card p-6 flex flex-col gap-4 cursor-pointer hover:border-pink-500/50 transition-all duration-200 h-full">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-white">Complete Tasks</h3>
              <p className="text-sm text-gray-400">Earn points by completing tasks</p>
            </div>
          </a>

          <a href="/app/offers">
            <div className="glass-card p-6 flex flex-col gap-4 cursor-pointer hover:border-pink-500/50 transition-all duration-200 h-full">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white">
                <Gift className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-white">Offers & Surveys</h3>
              <p className="text-sm text-gray-400">Participate in surveys for rewards</p>
            </div>
          </a>

          <a href="/app/referrals">
            <div className="glass-card p-6 flex flex-col gap-4 cursor-pointer hover:border-pink-500/50 transition-all duration-200 h-full">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-white">Invite Friends</h3>
              <p className="text-sm text-gray-400">Earn bonuses for referrals</p>
            </div>
          </a>
        </div>
      </div>
    </AppLayout>
  );
}

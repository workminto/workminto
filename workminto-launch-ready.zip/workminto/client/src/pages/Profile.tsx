import { AppLayout } from "@/components/AppLayout";
import { GradientButton } from "@/components/GradientButton";
import {
  User,
  Mail,
  Lock,
  Bell,
  HelpCircle,
  ChevronRight,
  LogOut,
} from "lucide-react";

/**
 * Workminto Profile Page
 * User profile, settings, and account management
 */
export default function Profile() {
  const profileSections = [
    {
      icon: User,
      title: "Account Settings",
      description: "Manage your profile information",
      items: [
        { label: "Full Name", value: "John Doe", action: undefined },
        { label: "Email", value: "john@example.com", action: undefined },
        { label: "Phone", value: "+1 (555) 123-4567", action: undefined },
        { label: "Member Since", value: "June 2024", action: undefined },
      ],
    },
    {
      icon: Lock,
      title: "Security",
      description: "Manage your account security",
      items: [
        { label: "Password", value: "••••••••", action: "Change" },
        { label: "Two-Factor Auth", value: "Enabled", action: "Manage" },
        { label: "Login History", value: "View", action: "View" },
      ],
    },
    {
      icon: Bell,
      title: "Notifications",
      description: "Manage notification preferences",
      items: [
        { label: "Email Notifications", value: "On", action: undefined },
        { label: "Push Notifications", value: "On", action: undefined },
        { label: "SMS Alerts", value: "Off", action: undefined },
      ],
    },
  ];

  const supportItems = [
    {
      icon: HelpCircle,
      title: "Help & Support",
      description: "Get help with your account",
    },
    {
      icon: Mail,
      title: "Contact Us",
      description: "Reach out to our support team",
    },
  ];

  return (
    <AppLayout activeTab="profile">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Profile
          </h1>
          <p className="text-gray-400">
            Manage your account and preferences
          </p>
        </div>

        {/* User Profile Card */}
        <div
          className="glass-card p-8 md:p-12 flex flex-col md:flex-row items-center gap-8"
          style={{
            boxShadow: "0 0 40px rgba(255, 20, 147, 0.2)",
          }}
        >
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white text-4xl font-bold flex-shrink-0">
            JD
          </div>
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-2xl md:text-3xl font-bold text-white">
              John Doe
            </h2>
            <p className="text-gray-400 mt-1">john@example.com</p>
            <div className="flex items-center gap-4 mt-4 flex-wrap justify-center md:justify-start">
              <div>
                <p className="text-xs text-gray-400">Level</p>
                <p className="font-bold text-white">12</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Member Since</p>
                <p className="font-bold text-white">June 2024</p>
              </div>
              <div>
                <p className="text-xs text-gray-400">Total Earned</p>
                <p className="font-bold text-pink-400">$125.50</p>
              </div>
            </div>
          </div>
          <GradientButton className="md:ml-auto">Edit Profile</GradientButton>
        </div>

        {/* Settings Sections */}
        {profileSections.map((section, idx) => {
          const Icon = section.icon;
          return (
            <div
              key={idx}
              className="glass-card p-8"
              style={{
                boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
              }}
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {section.title}
                  </h3>
                  <p className="text-xs text-gray-400">
                    {section.description}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {section.items.map((item, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 transition-all duration-200"
                  >
                    <div>
                      <p className="text-sm text-gray-400">{item.label}</p>
                      <p className="font-semibold text-white mt-1">
                        {item.value}
                      </p>
                    </div>
                    {item.action && (
                      <button className="text-pink-400 hover:text-pink-300 transition-colors text-sm font-semibold">
                        {item.action}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Support Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {supportItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <a
                key={idx}
                href="#"
                className="glass-card p-6 flex items-center justify-between hover:border-pink-500/50 transition-all duration-200"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-white">{item.title}</p>
                    <p className="text-xs text-gray-400">
                      {item.description}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </a>
            );
          })}
        </div>

        {/* Logout Button */}
        <div className="flex gap-4">
          <button className="flex-1 px-6 py-3 rounded-full border border-destructive/50 hover:border-destructive transition-all duration-200 text-destructive font-semibold flex items-center justify-center gap-2">
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>
      </div>
    </AppLayout>
  );
}

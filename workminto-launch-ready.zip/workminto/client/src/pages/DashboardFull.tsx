import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { AppLayout } from '@/components/AppLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GradientButton } from '@/components/GradientButton';
import { Loader2, Zap, TrendingUp, Users, Gift, ArrowRight } from 'lucide-react';
import { useWallet } from '@/hooks/useWallet';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

/**
 * Workminto Dashboard
 * Main user dashboard showing points balance, daily check-in, recent activity, and earning options
 */
export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { wallet, fetchWallet, isLoading: walletLoading } = useWallet();
  const [dailyCheckInDone, setDailyCheckInDone] = useState(false);
  const [checkInLoading, setCheckInLoading] = useState(false);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  useEffect(() => {
    // Load wallet data
    if (isAuthenticated) {
      fetchWallet();
      loadRecentActivity();
    } else {
      setLocation('/auth/login');
    }
  }, [isAuthenticated]);

  const loadRecentActivity = async () => {
    try {
      // TODO: Replace with actual API call when endpoint is available
      setRecentActivity([
        { id: 1, type: 'task', title: 'Daily Check-in', points: 50, time: 'Today, 08:30 AM' },
        { id: 2, type: 'referral', title: 'Friend Joined', points: 200, time: 'Yesterday' },
        { id: 3, type: 'task', title: 'Quiz Completed', points: 100, time: '2 days ago' },
      ]);
    } catch (error) {
      console.error('Failed to load activity:', error);
    }
  };

  const handleDailyCheckIn = async () => {
    setCheckInLoading(true);
    try {
      // TODO: Connect to actual daily check-in API endpoint
      toast.success('Daily check-in completed! +50 points');
      setDailyCheckInDone(true);
      await fetchWallet();
    } catch (error: any) {
      toast.error(error.message || 'Daily check-in failed');
    } finally {
      setCheckInLoading(false);
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-4xl font-bold text-white">
            Hello, {user?.first_name || 'User'}! 👋
          </h1>
          <p className="text-gray-400">Keep going, great things take time.</p>
        </div>

        {/* Points Balance Card */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/20 p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-400 text-sm mb-2">Your Points Balance</p>
              <h2 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-orange-400">
                {walletLoading ? <Loader2 className="w-8 h-8 animate-spin" /> : wallet?.available_points || 0}
              </h2>
              <p className="text-gray-500 text-sm mt-2">≈ ${((wallet?.available_points || 0) * 0.01).toFixed(2)} USD</p>
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm mb-2">Level</p>
              <div className="text-3xl font-bold text-purple-400">{wallet?.level || 1}</div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-purple-500/20">
            <Button
              onClick={() => setLocation('/wallet')}
              className="w-full bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 text-white font-semibold"
            >
              Redeem Now <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>

        {/* Daily Check-in Card */}
        <Card className="bg-gradient-to-br from-blue-900/30 to-purple-900/30 border-blue-500/20 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white mb-2">Daily Check-in</h3>
              <p className="text-gray-400 text-sm">Get 50 Points Everyday!</p>
            </div>
            <Zap className="w-8 h-8 text-yellow-400" />
          </div>
          <Button
            onClick={handleDailyCheckIn}
            disabled={dailyCheckInDone || checkInLoading}
            className="w-full mt-4 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-semibold disabled:opacity-50"
          >
            {checkInLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Checking In...
              </>
            ) : dailyCheckInDone ? (
              '✓ Checked In Today'
            ) : (
              'Claim Now'
            )}
          </Button>
        </Card>

        {/* Earning Options Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Tasks */}
          <Card
            onClick={() => setLocation('/tasks')}
            className="bg-gradient-to-br from-pink-900/30 to-red-900/30 border-pink-500/20 p-6 cursor-pointer hover:border-pink-500/40 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Tasks</h3>
              <Gift className="w-6 h-6 text-pink-400" />
            </div>
            <p className="text-gray-400 text-sm mb-4">Complete easy tasks and earn points</p>
            <div className="text-2xl font-bold text-pink-400">Up to 500 pts</div>
          </Card>

          {/* Surveys & Offers */}
          <Card
            onClick={() => setLocation('/offers')}
            className="bg-gradient-to-br from-orange-900/30 to-yellow-900/30 border-orange-500/20 p-6 cursor-pointer hover:border-orange-500/40 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Surveys</h3>
              <TrendingUp className="w-6 h-6 text-orange-400" />
            </div>
            <p className="text-gray-400 text-sm mb-4">Share your opinion and get rewarded</p>
            <div className="text-2xl font-bold text-orange-400">Up to 1000 pts</div>
          </Card>

          {/* Referrals */}
          <Card
            onClick={() => setLocation('/referrals')}
            className="bg-gradient-to-br from-green-900/30 to-teal-900/30 border-green-500/20 p-6 cursor-pointer hover:border-green-500/40 transition-all"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Referrals</h3>
              <Users className="w-6 h-6 text-green-400" />
            </div>
            <p className="text-gray-400 text-sm mb-4">Invite friends and earn bonuses</p>
            <div className="text-2xl font-bold text-green-400">+200 pts each</div>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="bg-gray-900/50 border-gray-800 p-6">
          <h3 className="text-lg font-bold text-white mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {recentActivity.length > 0 ? (
              recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                  <div>
                    <p className="text-white font-medium">{activity.title}</p>
                    <p className="text-gray-400 text-sm">{activity.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 font-semibold">+{activity.points}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-gray-400 text-center py-4">No recent activity</p>
            )}
          </div>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <Card className="bg-gray-900/50 border-gray-800 p-4 text-center">
            <p className="text-gray-400 text-sm mb-2">Total Earned</p>
            <p className="text-2xl font-bold text-white">{wallet?.total_points || 0}</p>
          </Card>
          <Card className="bg-gray-900/50 border-gray-800 p-4 text-center">
            <p className="text-gray-400 text-sm mb-2">Pending</p>
            <p className="text-2xl font-bold text-yellow-400">{(wallet?.total_points || 0) - (wallet?.available_points || 0)}</p>
          </Card>
          <Card className="bg-gray-900/50 border-gray-800 p-4 text-center">
            <p className="text-gray-400 text-sm mb-2">Redeemed</p>
            <p className="text-2xl font-bold text-green-400">0</p>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

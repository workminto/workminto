import { AppLayout } from "@/components/AppLayout";
import { GradientButton } from "@/components/GradientButton";
import { Users, Copy, Share2, TrendingUp, CheckCircle2 } from "lucide-react";
import { useState } from "react";

/**
 * Workminto Referrals Page
 * Display referral code, share options, and referral history
 */
export default function Referrals() {
  const [copied, setCopied] = useState(false);
  const referralCode = "WORKMINTO25";
  const referralLink = "https://workminto.com/ref/WORKMINTO25";

  const handleCopy = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const referralStats = [
    { label: "Total Referrals", value: "12", icon: Users },
    { label: "Points Earned", value: "2,400", icon: TrendingUp },
    { label: "Active Referrals", value: "8", icon: CheckCircle2 },
  ];

  const referralHistory = [
    {
      id: 1,
      name: "Rohit Sharma",
      joinedDate: "2 days ago",
      pointsEarned: 200,
      status: "Active",
    },
    {
      id: 2,
      name: "Priya Singh",
      joinedDate: "5 days ago",
      pointsEarned: 200,
      status: "Active",
    },
    {
      id: 3,
      name: "Amit Kumar",
      joinedDate: "1 week ago",
      pointsEarned: 200,
      status: "Active",
    },
    {
      id: 4,
      name: "Sarah Johnson",
      joinedDate: "2 weeks ago",
      pointsEarned: 200,
      status: "Active",
    },
  ];

  return (
    <AppLayout activeTab="referrals">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Referrals
          </h1>
          <p className="text-gray-400">
            Invite friends and earn rewards together
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {referralStats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{stat.label}</p>
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Referral Code Card */}
        <div
          className="glass-card p-8 md:p-12"
          style={{
            boxShadow: "0 0 40px rgba(255, 20, 147, 0.2)",
          }}
        >
          <h2 className="text-2xl font-bold text-white mb-6">
            Your Referral Code
          </h2>

          <div className="space-y-6">
            {/* Code */}
            <div>
              <p className="text-gray-400 text-sm mb-3">Referral Code</p>
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-3 flex items-center gap-3">
                  <span className="text-2xl font-bold text-pink-400">
                    {referralCode}
                  </span>
                </div>
                <button
                  onClick={handleCopy}
                  className="px-4 py-3 rounded-lg bg-pink-500/20 border border-pink-500/50 hover:border-pink-500 transition-all duration-200 text-pink-400 font-semibold flex items-center gap-2"
                >
                  <Copy className="w-4 h-4" />
                  {copied ? "Copied!" : "Copy"}
                </button>
              </div>
            </div>

            {/* Link */}
            <div>
              <p className="text-gray-400 text-sm mb-3">Referral Link</p>
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-gray-300 text-sm truncate">
                  {referralLink}
                </div>
                <button className="px-4 py-3 rounded-lg bg-pink-500/20 border border-pink-500/50 hover:border-pink-500 transition-all duration-200 text-pink-400 font-semibold flex items-center gap-2">
                  <Copy className="w-4 h-4" />
                  Copy
                </button>
              </div>
            </div>

            {/* Share Buttons */}
            <div>
              <p className="text-gray-400 text-sm mb-3">Share With Friends</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <button className="px-4 py-3 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold flex items-center justify-center gap-2">
                  <Share2 className="w-4 h-4" />
                  <span className="hidden sm:inline">WhatsApp</span>
                </button>
                <button className="px-4 py-3 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold flex items-center justify-center gap-2">
                  <Share2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Telegram</span>
                </button>
                <button className="px-4 py-3 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold flex items-center justify-center gap-2">
                  <Share2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Facebook</span>
                </button>
                <button className="px-4 py-3 rounded-lg border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold flex items-center justify-center gap-2">
                  <Share2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Twitter</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Referral History */}
        <div
          className="glass-card p-8"
          style={{
            boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
          }}
        >
          <h2 className="text-2xl font-bold text-white mb-6">
            Recent Referrals
          </h2>
          <div className="space-y-4">
            {referralHistory.map((referral) => (
              <div
                key={referral.id}
                className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 transition-all duration-200"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white font-bold">
                    {referral.name[0]}
                  </div>
                  <div>
                    <p className="font-semibold text-white">{referral.name}</p>
                    <p className="text-xs text-gray-400">{referral.joinedDate}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-pink-400">+{referral.pointsEarned}</p>
                  <p className="text-xs text-gray-400">{referral.status}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

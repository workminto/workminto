import { Header } from "@/components/Header";
import { Users, Target, Heart } from "lucide-react";

/**
 * Workminto About Page
 * Company mission, vision, and values
 */
export default function About() {
  const values = [
    {
      icon: <Target className="w-8 h-8" />,
      title: "Our Mission",
      description:
        "To empower people to earn rewards on their own terms by completing tasks they enjoy.",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Our Community",
      description:
        "We've built a thriving community of over 25,000 users earning rewards together.",
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Our Values",
      description:
        "Transparency, security, and user empowerment are at the heart of everything we do.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="flex flex-col gap-6 max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              About Workminto
            </h1>
            <p className="text-lg md:text-xl text-gray-400">
              We're on a mission to make earning rewards simple, transparent, and rewarding.
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="glass-card p-8 md:p-12 max-w-3xl">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-6">
              Our Story
            </h2>
            <div className="space-y-4 text-gray-300 leading-relaxed">
              <p>
                Workminto was founded in 2023 with a simple idea: what if earning rewards could be easy, fun, and transparent?
              </p>
              <p>
                We noticed that many reward platforms were complicated, had hidden terms, and didn't value their users' time. So we decided to build something different.
              </p>
              <p>
                Today, Workminto is a trusted platform where thousands of users earn real rewards by completing tasks they actually enjoy. We're proud of the community we've built and excited about the future.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="w-full py-20 md:py-32 bg-gradient-to-b from-black/20 to-background">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            What We Stand For
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, idx) => (
              <div
                key={idx}
                className="glass-card p-8 flex flex-col gap-4 text-center"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center text-white mx-auto">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-white">{value.title}</h3>
                <p className="text-gray-400">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl md:text-5xl font-bold text-pink-400 mb-2">
                25K+
              </div>
              <p className="text-gray-400">Active Users</p>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-pink-400 mb-2">
                1M+
              </div>
              <p className="text-gray-400">Tasks Completed</p>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold text-pink-400 mb-2">
                $500K+
              </div>
              <p className="text-gray-400">Rewards Distributed</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

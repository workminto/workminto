import { Header } from "@/components/Header";
import { GradientButton } from "@/components/GradientButton";
import { FeatureCard } from "@/components/FeatureCard";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { useState } from "react";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/workminto-logo-8TkXm59QVr7XQkJ4WqoAGR.webp";

const HERO_BG_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/hero-background-5zAyKSERep3ahjoVudS7aU.webp";

const FEATURE_ICONS = {
  safe: "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/feature-icon-1-NbP9mqXGimLGT74iGWwuFE.webp",
  instant:
    "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/feature-icon-2-ms9pmiVGatCEodU3oEVQ6o.webp",
  exciting:
    "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/feature-icon-3-Xc5WcRcbvAydEXePpmtaHJ.webp",
  trusted:
    "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/feature-icon-4-KNmSnSjLcjG8HHyWDYqKxx.webp",
};

/**
 * Workminto Landing Page
 * Premium, mobile-first design with neon gradients and glass morphism
 * Sections: Hero, Features, How It Works, Trust, FAQ, Footer
 */
export default function Home() {
  const [faqOpen, setFaqOpen] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <Header />

      {/* Hero Section */}
      <section
        className="relative w-full min-h-screen flex items-center justify-center overflow-hidden pt-20 md:pt-0"
        style={{
          backgroundImage: `url(${HERO_BG_URL})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Overlay for better text contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60" />

        <div className="relative container grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center py-20 md:py-0">
          {/* Left Content */}
          <div className="flex flex-col gap-6 md:gap-8 z-10">
            <div className="flex flex-col gap-4">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                <span className="text-white">Complete </span>
                <span className="gradient-text">Tasks.</span>
                <br />
                <span className="text-white">Earn </span>
                <span className="gradient-text">Rewards.</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-300 leading-relaxed max-w-lg">
                Join thousands of users earning points by completing tasks,
                quizzes, surveys and more. Turn your time into real rewards.
              </p>
            </div>

            {/* Trust Badges */}
            <div className="flex flex-col gap-3">
              {[
                "100% Safe & Secure",
                "Instant Points",
                "Exciting Rewards",
                "Trusted by Thousands",
              ].map((badge, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-pink-400" />
                  <span className="text-sm md:text-base text-gray-300">
                    {badge}
                  </span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a href="/auth/signup">
                <GradientButton className="flex items-center justify-center gap-2">
                  Get Started <ArrowRight className="w-5 h-5" />
                </GradientButton>
              </a>
              <button className="px-6 py-3 rounded-full border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold">
                Learn More
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-white/10">
              <div>
                <div className="text-2xl md:text-3xl font-bold gradient-text">
                  25K+
                </div>
                <p className="text-xs md:text-sm text-gray-400">Users</p>
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold gradient-text">
                  1M+
                </div>
                <p className="text-xs md:text-sm text-gray-400">Tasks Done</p>
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold gradient-text">
                  4.8
                </div>
                <p className="text-xs md:text-sm text-gray-400">Rating</p>
              </div>
            </div>
          </div>

          {/* Right Visual - Empty space for visual balance */}
          <div className="hidden md:block h-96 relative">
            <div className="absolute inset-0 opacity-20">
              <div className="absolute top-10 right-10 w-32 h-32 bg-pink-500 rounded-full blur-3xl" />
              <div className="absolute bottom-20 left-10 w-40 h-40 bg-purple-500 rounded-full blur-3xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section
        id="features"
        className="w-full py-20 md:py-32 bg-gradient-to-b from-background to-black/40"
      >
        <div className="container">
          <div className="flex flex-col gap-4 mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold">
              Why Choose Workminto?
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl">
              We've built the most trusted rewards platform with premium
              features and real payouts.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <FeatureCard
              icon={
                <img
                  src={FEATURE_ICONS.safe}
                  alt="Safe & Secure"
                  className="w-full h-full"
                />
              }
              title="100% Safe & Secure"
              description="Your data is encrypted and protected with enterprise-grade security."
            />
            <FeatureCard
              icon={
                <img
                  src={FEATURE_ICONS.instant}
                  alt="Instant Points"
                  className="w-full h-full"
                />
              }
              title="Instant Points"
              description="Earn points immediately after completing tasks. No waiting."
            />
            <FeatureCard
              icon={
                <img
                  src={FEATURE_ICONS.exciting}
                  alt="Exciting Rewards"
                  className="w-full h-full"
                />
              }
              title="Exciting Rewards"
              description="Redeem points for gift cards, cash, and exclusive perks."
            />
            <FeatureCard
              icon={
                <img
                  src={FEATURE_ICONS.trusted}
                  alt="Trusted by Thousands"
                  className="w-full h-full"
                />
              }
              title="Trusted by Thousands"
              description="Join a community of real users earning real rewards daily."
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section
        id="how-it-works"
        className="w-full py-20 md:py-32 bg-black/20"
      >
        <div className="container">
          <div className="flex flex-col gap-4 mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold">
              How It Works
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl">
              Get started in minutes and start earning rewards today.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                title: "Sign Up",
                description:
                  "Create your free account in seconds. No credit card required.",
              },
              {
                step: "2",
                title: "Complete Tasks",
                description:
                  "Browse available tasks, quizzes, and surveys. Pick what interests you.",
              },
              {
                step: "3",
                title: "Earn & Redeem",
                description:
                  "Collect points and redeem them for rewards whenever you want.",
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="glass-card p-8 flex flex-col gap-4 relative group"
              >
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-pink-500 to-orange-500 rounded-full flex items-center justify-center font-bold text-lg text-white shadow-lg">
                  {item.step}
                </div>
                <h3 className="text-xl md:text-2xl font-bold pt-4">
                  {item.title}
                </h3>
                <p className="text-gray-400 leading-relaxed">
                  {item.description}
                </p>
                {idx < 2 && (
                  <div className="hidden md:block absolute -right-4 top-1/2 transform -translate-y-1/2">
                    <ArrowRight className="w-8 h-8 text-pink-500/50" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="w-full py-20 md:py-32 bg-gradient-to-b from-black/20 to-background">
        <div className="container">
          <div className="glass-card p-8 md:p-12 text-center flex flex-col gap-8">
            <h2 className="text-3xl md:text-4xl font-bold">
              Trusted & Secure Platform
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              We prioritize your security and privacy with industry-leading
              standards.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
              {[
                {
                  title: "SSL Secured",
                  description: "Enterprise-grade encryption for all data",
                },
                {
                  title: "Data Protected",
                  description: "Your personal information is never shared",
                },
                {
                  title: "Safe Earnings",
                  description: "Verified payouts to real users daily",
                },
              ].map((item, idx) => (
                <div key={idx} className="flex flex-col gap-2">
                  <h3 className="text-lg font-bold text-pink-400">
                    {item.title}
                  </h3>
                  <p className="text-sm text-gray-400">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section
        id="faq"
        className="w-full py-20 md:py-32 bg-black/20"
      >
        <div className="container max-w-3xl">
          <div className="flex flex-col gap-4 mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold">
              Frequently Asked Questions
            </h2>
            <p className="text-lg text-gray-400">
              Everything you need to know about Workminto.
            </p>
          </div>

          <Accordion
            type="single"
            collapsible
            value={faqOpen || ""}
            onValueChange={setFaqOpen}
            className="space-y-4"
          >
            {[
              {
                id: "faq-1",
                question: "Is Workminto really free?",
                answer:
                  "Yes! Workminto is completely free to join and use. You never pay to earn rewards. We make money through our partners, not from you.",
              },
              {
                id: "faq-2",
                question: "How do I withdraw my earnings?",
                answer:
                  "You can withdraw your points as gift cards, PayPal transfers, or other rewards. Minimum withdrawal is 100 points ($1 USD). Withdrawals are processed within 24-48 hours.",
              },
              {
                id: "faq-3",
                question: "What tasks are available?",
                answer:
                  "We offer surveys, quizzes, app testing, video watching, and more. New tasks are added daily. You can choose tasks that match your interests.",
              },
              {
                id: "faq-4",
                question: "How much can I earn?",
                answer:
                  "Earnings vary based on tasks and your location. Most users earn $5-20 per month with casual participation. Active users can earn significantly more.",
              },
              {
                id: "faq-5",
                question: "Is my data safe?",
                answer:
                  "Absolutely. We use SSL encryption, comply with GDPR, and never sell your data. Your privacy is our top priority.",
              },
              {
                id: "faq-6",
                question: "Can I use Workminto on mobile?",
                answer:
                  "Yes! Workminto works perfectly on mobile devices. Download our app or use the mobile web version for the best experience.",
              },
            ].map((item) => (
              <AccordionItem
                key={item.id}
                value={item.id}
                className="glass-card px-6 py-4 border-0"
              >
                <AccordionTrigger className="text-lg font-semibold hover:text-pink-400 transition-colors">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-400 leading-relaxed pt-4">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-20 md:py-32 bg-gradient-to-b from-black/20 to-background">
        <div className="container">
          <div className="glass-card p-8 md:p-16 text-center flex flex-col gap-8 items-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold max-w-2xl">
              Ready to Start Earning?
            </h2>
            <p className="text-lg text-gray-400 max-w-xl">
              Join thousands of users already earning rewards on Workminto.
              It's free, fast, and fun.
            </p>
            <a href="/auth/signup">
              <GradientButton className="flex items-center justify-center gap-2">
                Get Started Now <ArrowRight className="w-5 h-5" />
              </GradientButton>
            </a>
            <p className="text-sm text-gray-500">
              No credit card required • Takes 2 minutes to sign up
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-2">
                <img
                  src={LOGO_URL}
                  alt="Workminto"
                  className="w-8 h-8"
                />
                <span className="font-bold text-white">Workminto</span>
              </div>
              <p className="text-sm text-gray-400">
                Earn points. Unlock rewards. Join the community.
              </p>
            </div>

            {/* Links */}
            <div className="flex flex-col gap-4">
              <h4 className="font-semibold text-white">Product</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="/features" className="hover:text-white transition-colors">
                    Features
                  </a>
                </li>
                <li>
                  <a href="/pricing" className="hover:text-white transition-colors">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="/security" className="hover:text-white transition-colors">
                    Security
                  </a>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div className="flex flex-col gap-4">
              <h4 className="font-semibold text-white">Company</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="/about" className="hover:text-white transition-colors">
                    About
                  </a>
                </li>
                <li>
                  <a href="/blog" className="hover:text-white transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="/contact" className="hover:text-white transition-colors">
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div className="flex flex-col gap-4">
              <h4 className="font-semibold text-white">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="/privacy" className="hover:text-white transition-colors">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="/terms" className="hover:text-white transition-colors">
                    Terms
                  </a>
                </li>
                <li>
                  <a href="/cookies" className="hover:text-white transition-colors">
                    Cookies
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom */}
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
            <p>&copy; 2024 Workminto. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-gray-300 transition-colors">
                Twitter
              </a>
              <a href="#" className="hover:text-gray-300 transition-colors">
                Discord
              </a>
              <a href="#" className="hover:text-gray-300 transition-colors">
                Instagram
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

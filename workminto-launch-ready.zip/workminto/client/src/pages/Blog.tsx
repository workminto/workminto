import { Header } from "@/components/Header";
import { Calendar, ArrowRight } from "lucide-react";

/**
 * Workminto Blog Page
 * Blog posts and articles
 */
export default function Blog() {
  const posts = [
    {
      id: 1,
      title: "10 Tips to Maximize Your Earnings on Workminto",
      excerpt:
        "Learn strategies to earn more rewards and complete tasks faster.",
      date: "June 15, 2024",
      category: "Tips",
    },
    {
      id: 2,
      title: "How We Ensure Your Data Security",
      excerpt:
        "An inside look at our security practices and data protection measures.",
      date: "June 10, 2024",
      category: "Security",
    },
    {
      id: 3,
      title: "Referral Program Update: Earn More Together",
      excerpt:
        "Introducing new referral bonuses and exclusive rewards for your friends.",
      date: "June 5, 2024",
      category: "Updates",
    },
    {
      id: 4,
      title: "Success Story: How Sarah Earned $500 in 3 Months",
      excerpt:
        "Real user story about earning rewards while working from home.",
      date: "May 28, 2024",
      category: "Stories",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="flex flex-col gap-6 max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white">
              Workminto Blog
            </h1>
            <p className="text-lg md:text-xl text-gray-400">
              Tips, stories, and updates from the Workminto community.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="w-full py-20 md:py-32">
        <div className="container">
          <div className="space-y-6">
            {posts.map((post) => (
              <div
                key={post.id}
                className="glass-card p-8 hover:border-pink-500/50 transition-all duration-300 cursor-pointer group"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-4 flex-wrap">
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-pink-500/20 border border-pink-500/50 text-pink-300">
                      {post.category}
                    </span>
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <Calendar className="w-4 h-4" />
                      {post.date}
                    </div>
                  </div>

                  <h3 className="text-2xl font-bold text-white group-hover:text-pink-400 transition-colors">
                    {post.title}
                  </h3>

                  <p className="text-gray-400">{post.excerpt}</p>

                  <div className="flex items-center gap-2 text-pink-400 group-hover:gap-3 transition-all">
                    <span className="font-semibold">Read More</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full border-t border-white/10 bg-black/40 py-12 md:py-16">
        <div className="container text-center text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { AppLayout } from '@/components/AppLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { GradientButton } from '@/components/GradientButton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, ArrowDown, ArrowUp, Send } from 'lucide-react';
import { useWallet } from '@/hooks/useWallet';
import { useWithdrawal } from '@/hooks/useWithdrawal';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

/**
 * Workminto Wallet Page
 * View points balance, transaction history, and manage withdrawals
 */
export default function Wallet() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const { wallet, transactions, fetchWallet, fetchTransactions, isLoading: walletLoading } = useWallet();
  const { withdrawals, createWithdrawal, fetchWithdrawals, isLoading: withdrawalLoading } = useWithdrawal();
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState('bank_transfer');

  useEffect(() => {
    if (isAuthenticated) {
      fetchWallet();
      fetchWithdrawals();
      fetchTransactions();
    } else {
      setLocation('/auth/login');
    }
  }, [isAuthenticated]);

  const handleWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (parseFloat(withdrawAmount) > (wallet?.available_points || 0)) {
      toast.error('Insufficient points');
      return;
    }

    try {
      await createWithdrawal(
        parseFloat(withdrawAmount),
        withdrawMethod,
      {}
      toast.success('Withdrawal request submitted!');
      setWithdrawAmount('');
      fetchWallet();
      fetchWithdrawals();
    } catch (error: any) {
      toast.error(error.message || 'Withdrawal failed');
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-4xl font-bold text-white">Wallet</h1>
          <p className="text-gray-400">Manage your points and redeem rewards</p>
        </div>

        {/* Points Balance Card */}
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/20 p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Available Points */}
            <div>
              <p className="text-gray-400 text-sm mb-2">Available Points</p>
              <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-orange-400">
                {walletLoading ? <Loader2 className="w-8 h-8 animate-spin" /> : wallet?.available_points || 0}
              </h2>
              <p className="text-gray-500 text-sm mt-2">≈ ${((wallet?.available_points || 0) * 0.01).toFixed(2)}</p>
            </div>

            {/* Pending Points */}
            <div>
              <p className="text-gray-400 text-sm mb-2">Pending Points</p>
              <h2 className="text-4xl font-bold text-yellow-400">
                {walletLoading ? <Loader2 className="w-8 h-8 animate-spin" /> : wallet?.pending_points || 0}
              </h2>
              <p className="text-gray-500 text-sm mt-2">Will be available soon</p>
            </div>

            {/* Total Points */}
            <div>
              <p className="text-gray-400 text-sm mb-2">Total Earned</p>
              <h2 className="text-4xl font-bold text-green-400">
                {walletLoading ? <Loader2 className="w-8 h-8 animate-spin" /> : wallet?.total_points || 0}
              </h2>
              <p className="text-gray-500 text-sm mt-2">All time</p>
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="transactions" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-gray-900/50 border border-gray-800">
            <TabsTrigger value="transactions">Transaction History</TabsTrigger>
            <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
          </TabsList>

          {/* Transaction History Tab */}
          <TabsContent value="transactions" className="space-y-4">
            <Card className="bg-gray-900/50 border-gray-800 p-6">
              {transactions && transactions.length > 0 ? (
                <div className="space-y-3">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`p-3 rounded-lg ${tx.type === 'earned' ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                          {tx.type === 'earned' ? (
                            <ArrowDown className={`w-5 h-5 ${tx.type === 'earned' ? 'text-green-400' : 'text-red-400'}`} />
                          ) : (
                            <ArrowUp className={`w-5 h-5 ${tx.type === 'earned' ? 'text-green-400' : 'text-red-400'}`} />
                          )}
                        </div>
                        <div>
                          <p className="text-white font-medium capitalize">{tx.type}</p>
                          <p className="text-gray-400 text-sm">{tx.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`text-lg font-bold ${tx.type === 'earned' ? 'text-green-400' : 'text-red-400'}`}>
                          {tx.type === 'earned' ? '+' : '-'}{tx.amount}
                        </p>
                        <p className="text-gray-400 text-sm">{new Date(tx.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-400 text-center py-8">No transactions yet</p>
              )}
            </Card>
          </TabsContent>

          {/* Withdraw Tab */}
          <TabsContent value="withdraw" className="space-y-4">
            <Card className="bg-gray-900/50 border-gray-800 p-6">
              <form onSubmit={handleWithdrawal} className="space-y-4">
                {/* Amount Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Amount (Points)</label>
                  <input
                    type="number"
                    min="0"
                    max={wallet?.available_points || 0}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder:text-gray-500 focus:border-pink-500 focus:outline-none"
                  />
                  <p className="text-gray-400 text-sm mt-2">Available: {wallet?.available_points || 0} points</p>
                </div>

                {/* Withdrawal Method */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Withdrawal Method</label>
                  <select
                    value={withdrawMethod}
                    onChange={(e) => setWithdrawMethod(e.target.value)}
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-pink-500 focus:outline-none"
                  >
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="paypal">PayPal</option>
                    <option value="crypto">Cryptocurrency</option>
                  </select>
                </div>

                {/* Estimated Amount */}
                {withdrawAmount && (
                  <div className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                    <p className="text-gray-400 text-sm mb-2">Estimated USD Amount</p>
                    <p className="text-2xl font-bold text-green-400">${(parseFloat(withdrawAmount) * 0.01).toFixed(2)}</p>
                  </div>
                )}

                {/* Submit Button */}
                <GradientButton
                  type="submit"
                  disabled={withdrawalLoading || !withdrawAmount}
                  className="w-full flex items-center justify-center gap-2"
                >
                  {withdrawalLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Request Withdrawal
                    </>
                  )}
                </GradientButton>
              </form>
            </Card>

            {/* Recent Withdrawals */}
            {withdrawals && withdrawals.length > 0 && (
              <Card className="bg-gray-900/50 border-gray-800 p-6">
                <h3 className="text-lg font-bold text-white mb-4">Recent Withdrawals</h3>
                <div className="space-y-3">
                  {withdrawals.slice(0, 5).map((withdrawal) => (
                    <div key={withdrawal.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                      <div>
                        <p className="text-white font-medium capitalize">{withdrawal.method}</p>
                        <p className="text-gray-400 text-sm capitalize">{withdrawal.status}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-white">{withdrawal.amount_points} pts</p>
                        <p className="text-gray-400 text-sm">{new Date(withdrawal.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}

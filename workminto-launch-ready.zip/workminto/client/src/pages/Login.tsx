import { useState } from "react";
import { useLocation } from "wouter";
import { AuthLayout } from "@/components/AuthLayout";
import { AuthCard } from "@/components/AuthCard";
import { AuthInput } from "@/components/AuthInput";
import { GradientButton } from "@/components/GradientButton";
import { useAuth } from "@/hooks/useAuth";
import { Mail, Lock, Loader2 } from "lucide-react";

/**
 * Workminto Login Page
 * Premium login form with email and password
 * Routes to dashboard on successful login
 */
export default function Login() {
  const [, setLocation] = useLocation();
  const { login, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState<Record<string, boolean>>({});
  const [apiError, setApiError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }
    if (!formData.password) {
      newErrors.password = "Password is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setApiError("");

    if (!validateForm()) {
      return;
    }

    try {
      await login(formData.email, formData.password);
      setSuccess({
        email: true,
        password: true,
      });
      setTimeout(() => {
        setLocation("/dashboard");
      }, 500);
    } catch (error: any) {
      setApiError(error.message || "Login failed");
    }
  };

  return (
    <AuthLayout>
      <AuthCard>
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Welcome Back
          </h1>
          <p className="text-gray-400">Sign in to your Workminto account</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <AuthInput
            label="Email Address"
            name="email"
            type="email"
            placeholder="you@example.com"
            value={formData.email}
            onChange={handleChange}
            error={errors.email}
            success={success.email}
            icon={<Mail className="w-5 h-5" />}
          />

          <AuthInput
            label="Password"
            name="password"
            type="password"
            placeholder="••••••••"
            value={formData.password}
            onChange={handleChange}
            error={errors.password}
            success={success.password}
            icon={<Lock className="w-5 h-5" />}
          />

          {/* Forgot Password Link */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => setLocation("/auth/forgot-password")}
              className="text-sm text-pink-400 hover:text-pink-300 transition-colors"
            >
              Forgot password?
            </button>
          </div>

          {/* API Error Message */}
        {apiError && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-sm">
            {apiError}
          </div>
        )}

        {/* Submit Button */}
          <GradientButton
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Signing In...
              </>
            ) : (
              "Sign In"
            )}
          </GradientButton>
        </form>

        {/* Signup Link */}
        <div className="text-center text-sm text-gray-400">
          Don't have an account?{" "}
          <button
            onClick={() => setLocation("/auth/signup")}
            className="text-pink-400 hover:text-pink-300 font-semibold transition-colors"
          >
            Create one
          </button>
        </div>
      </AuthCard>
    </AuthLayout>
  );
}

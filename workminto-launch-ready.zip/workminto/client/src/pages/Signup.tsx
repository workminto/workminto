import { useState } from "react";
import { useLocation } from "wouter";
import { AuthLayout } from "@/components/AuthLayout";
import { AuthCard } from "@/components/AuthCard";
import { AuthInput } from "@/components/AuthInput";
import { GradientButton } from "@/components/GradientButton";
import { Mail, Lock, User, Loader2 } from "lucide-react";

/**
 * Workminto Signup Page
 * Premium signup form with email, name, and password
 * Routes to OTP verification on successful submission
 */
export default function Signup() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState<Record<string, boolean>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }
    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters";
    }
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Mark fields as successful
    setSuccess({
      name: true,
      email: true,
      password: true,
      confirmPassword: true,
    });

    // Route to OTP verification
    setTimeout(() => {
      setLocation("/auth/verify-otp");
    }, 800);
  };

  return (
    <AuthLayout>
      <AuthCard>
        {/* Header */}
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl md:text-4xl font-bold text-white">
            Create Account
          </h1>
          <p className="text-gray-400">
            Join thousands earning rewards today
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <AuthInput
            label="Full Name"
            name="name"
            type="text"
            placeholder="John Doe"
            value={formData.name}
            onChange={handleChange}
            error={errors.name}
            success={success.name}
            icon={<User className="w-5 h-5" />}
          />

          <AuthInput
            label="Email Address"
            name="email"
            type="email"
            placeholder="you@example.com"
            value={formData.email}
            onChange={handleChange}
            error={errors.email}
            success={success.email}
            icon={<Mail className="w-5 h-5" />}
          />

          <AuthInput
            label="Password"
            name="password"
            type="password"
            placeholder="••••••••"
            value={formData.password}
            onChange={handleChange}
            error={errors.password}
            success={success.password}
            icon={<Lock className="w-5 h-5" />}
          />

          <AuthInput
            label="Confirm Password"
            name="confirmPassword"
            type="password"
            placeholder="••••••••"
            value={formData.confirmPassword}
            onChange={handleChange}
            error={errors.confirmPassword}
            success={success.confirmPassword}
            icon={<Lock className="w-5 h-5" />}
          />

          {/* Agreement */}
          <p className="text-xs text-gray-400 leading-relaxed">
            By signing up, you agree to our{" "}
            <a href="#" className="text-pink-400 hover:text-pink-300">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className="text-pink-400 hover:text-pink-300">
              Privacy Policy
            </a>
          </p>

          {/* Submit Button */}
          <GradientButton
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Creating Account...
              </>
            ) : (
              "Create Account"
            )}
          </GradientButton>
        </form>

        {/* Login Link */}
        <div className="text-center text-sm text-gray-400">
          Already have an account?{" "}
          <button
            onClick={() => setLocation("/auth/login")}
            className="text-pink-400 hover:text-pink-300 font-semibold transition-colors"
          >
            Sign In
          </button>
        </div>
      </AuthCard>
    </AuthLayout>
  );
}

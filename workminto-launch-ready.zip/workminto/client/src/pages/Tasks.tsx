import { AppLayout } from "@/components/AppLayout";
import { GradientButton } from "@/components/GradientButton";
import { Zap, CheckCircle2, Clock } from "lucide-react";
import { useState } from "react";

/**
 * Workminto Tasks Page
 * Display available tasks and completed tasks
 */
export default function Tasks() {
  const [activeTab, setActiveTab] = useState<"available" | "completed">(
    "available"
  );

  const availableTasks = [
    {
      id: 1,
      title: "Daily Check-in",
      description: "Check in daily to earn points",
      points: 50,
      category: "Daily",
      time: "1 min",
      completed: false,
    },
    {
      id: 2,
      title: "Quiz Time",
      description: "Answer 5 quick questions",
      points: 100,
      category: "Quiz",
      time: "5 mins",
      completed: false,
    },
    {
      id: 3,
      title: "Watch Video",
      description: "Watch a 2-minute video",
      points: 25,
      category: "Video",
      time: "2 mins",
      completed: false,
    },
    {
      id: 4,
      title: "Referral Bonus",
      description: "Invite a friend and earn",
      points: 200,
      category: "Referral",
      time: "Varies",
      completed: false,
    },
    {
      id: 5,
      title: "Profile Completion",
      description: "Complete your profile",
      points: 75,
      category: "Bonus",
      time: "3 mins",
      completed: false,
    },
    {
      id: 6,
      title: "Survey",
      description: "Participate in a survey",
      points: 150,
      category: "Survey",
      time: "10 mins",
      completed: false,
    },
  ];

  const completedTasks = [
    {
      id: 7,
      title: "Daily Check-in",
      points: 50,
      completedAt: "Today, 08:30 AM",
    },
    {
      id: 8,
      title: "Quiz Time",
      points: 100,
      completedAt: "Today, 07:45 AM",
    },
    {
      id: 9,
      title: "Watch Video",
      points: 25,
      completedAt: "Yesterday, 09:15 PM",
    },
  ];

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Daily: "from-pink-500 to-orange-500",
      Quiz: "from-purple-500 to-pink-500",
      Video: "from-blue-500 to-purple-500",
      Referral: "from-green-500 to-blue-500",
      Bonus: "from-yellow-500 to-orange-500",
      Survey: "from-indigo-500 to-purple-500",
    };
    return colors[category] || "from-pink-500 to-orange-500";
  };

  return (
    <AppLayout activeTab="tasks">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Tasks
          </h1>
          <p className="text-gray-400">
            Complete tasks to earn points and rewards
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-white/10">
          <button
            onClick={() => setActiveTab("available")}
            className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
              activeTab === "available"
                ? "border-pink-500 text-white"
                : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            Available Tasks
          </button>
          <button
            onClick={() => setActiveTab("completed")}
            className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
              activeTab === "completed"
                ? "border-pink-500 text-white"
                : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            Completed
          </button>
        </div>

        {/* Available Tasks */}
        {activeTab === "available" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {availableTasks.map((task) => (
              <div
                key={task.id}
                className="glass-card p-6 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <div
                        className={`w-8 h-8 rounded-lg bg-gradient-to-br ${getCategoryColor(
                          task.category
                        )} flex items-center justify-center text-white text-xs font-bold`}
                      >
                        {task.category[0]}
                      </div>
                      <span className="text-xs font-semibold text-gray-400 uppercase">
                        {task.category}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-white">
                      {task.title}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">
                      {task.description}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-pink-400">
                      +{task.points}
                    </p>
                    <p className="text-xs text-gray-400">points</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Clock className="w-4 h-4" />
                    {task.time}
                  </div>
                  <GradientButton className="text-sm py-2 px-4">
                    Start
                  </GradientButton>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Completed Tasks */}
        {activeTab === "completed" && (
          <div className="space-y-4">
            {completedTasks.map((task) => (
              <div
                key={task.id}
                className="glass-card p-6 flex items-center justify-between"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 border border-green-500/50 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <p className="font-bold text-white">{task.title}</p>
                    <p className="text-xs text-gray-400">{task.completedAt}</p>
                  </div>
                </div>
                <p className="font-bold text-green-400">+{task.points}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}

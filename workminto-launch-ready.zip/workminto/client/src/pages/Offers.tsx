import { AppLayout } from "@/components/AppLayout";
import { GradientButton } from "@/components/GradientButton";
import { Gift, TrendingUp } from "lucide-react";
import { useState } from "react";

/**
 * Workminto Offers & Surveys Page
 * Display available offers and surveys
 */
export default function Offers() {
  const [activeTab, setActiveTab] = useState<"offers" | "surveys">("offers");

  const offers = [
    {
      id: 1,
      title: "CPX Research",
      description: "Complete surveys and earn points",
      points: 300,
      status: "Available",
      reward: "Up to",
    },
    {
      id: 2,
      title: "BillLabs Offers",
      description: "Try apps and services",
      points: 500,
      status: "Available",
      reward: "Up to",
    },
    {
      id: 3,
      title: "Pollfish Surveys",
      description: "Share your opinion",
      points: 200,
      status: "Available",
      reward: "Up to",
    },
    {
      id: 4,
      title: "AdGem Offers",
      description: "Complete mobile offers",
      points: 400,
      status: "Available",
      reward: "Up to",
    },
  ];

  const surveys = [
    {
      id: 1,
      title: "Shopping Habits Survey",
      description: "Tell us about your shopping preferences",
      points: 150,
      time: "10 mins",
      status: "Available",
    },
    {
      id: 2,
      title: "Technology Usage",
      description: "Share your tech preferences",
      points: 120,
      time: "8 mins",
      status: "Available",
    },
    {
      id: 3,
      title: "Entertainment Preferences",
      description: "What do you like to watch?",
      points: 100,
      time: "5 mins",
      status: "Available",
    },
    {
      id: 4,
      title: "Travel & Lifestyle",
      description: "Tell us about your travel habits",
      points: 180,
      time: "12 mins",
      status: "Available",
    },
  ];

  return (
    <AppLayout activeTab="offers">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
            Offers & Surveys
          </h1>
          <p className="text-gray-400">
            Participate in offers and surveys to earn rewards
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-white/10">
          <button
            onClick={() => setActiveTab("offers")}
            className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
              activeTab === "offers"
                ? "border-pink-500 text-white"
                : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            Offers
          </button>
          <button
            onClick={() => setActiveTab("surveys")}
            className={`px-4 py-3 font-semibold transition-all duration-200 border-b-2 ${
              activeTab === "surveys"
                ? "border-pink-500 text-white"
                : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            Surveys
          </button>
        </div>

        {/* Offers */}
        {activeTab === "offers" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {offers.map((offer) => (
              <div
                key={offer.id}
                className="glass-card p-6 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Gift className="w-5 h-5 text-pink-400" />
                      <span className="text-xs font-semibold text-pink-400 uppercase">
                        {offer.status}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-white">
                      {offer.title}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">
                      {offer.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div>
                    <p className="text-xs text-gray-400">{offer.reward}</p>
                    <p className="text-2xl font-bold text-pink-400">
                      {offer.points}
                    </p>
                  </div>
                  <GradientButton className="text-sm py-2 px-4">
                    Start
                  </GradientButton>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Surveys */}
        {activeTab === "surveys" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {surveys.map((survey) => (
              <div
                key={survey.id}
                className="glass-card p-6 flex flex-col gap-4"
                style={{
                  boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
                }}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-5 h-5 text-purple-400" />
                      <span className="text-xs font-semibold text-purple-400 uppercase">
                        {survey.status}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-white">
                      {survey.title}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">
                      {survey.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div>
                    <p className="text-xs text-gray-400">{survey.time}</p>
                    <p className="text-2xl font-bold text-purple-400">
                      +{survey.points}
                    </p>
                  </div>
                  <GradientButton className="text-sm py-2 px-4">
                    Take Survey
                  </GradientButton>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}

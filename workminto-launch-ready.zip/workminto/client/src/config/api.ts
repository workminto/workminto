// API Configuration
const API_BASE_URL = process.env.VITE_API_URL || 'http://localhost:3001/api';

export const apiConfig = {
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
};

// API Endpoints
export const endpoints = {
  // Auth
  auth: {
    signup: '/auth/signup',
    login: '/auth/login',
    logout: '/auth/logout',
    refreshToken: '/auth/refresh-token',
    sendOTP: '/auth/send-otp',
    verifyOTP: '/auth/verify-otp',
    forgotPassword: '/auth/forgot-password',
    resetPassword: '/auth/reset-password',
  },

  // Wallet
  wallet: {
    get: '/wallet',
    getTransactions: '/wallet/transactions',
    addPoints: '/wallet/add-points',
    deductPoints: '/wallet/deduct-points',
  },

  // Referrals
  referrals: {
    getStats: '/referrals/stats',
    getHistory: '/referrals/history',
    validateCode: '/referrals/validate-code',
    awardBonus: '/referrals/award-bonus',
  },

  // Withdrawals
  withdrawals: {
    create: '/withdrawals',
    getList: '/withdrawals',
    getDetails: (id: number) => `/withdrawals/${id}`,
  },

  // Admin
  admin: {
    dashboard: {
      stats: '/admin/dashboard/stats',
    },
    users: {
      list: '/admin/users',
      details: (id: number) => `/admin/users/${id}`,
      suspend: (id: number) => `/admin/users/${id}/suspend`,
      ban: (id: number) => `/admin/users/${id}/ban`,
    },
    tasks: {
      list: '/admin/tasks',
      create: '/admin/tasks',
      update: (id: number) => `/admin/tasks/${id}`,
      delete: (id: number) => `/admin/tasks/${id}`,
    },
    withdrawals: {
      pending: '/admin/withdrawals/pending',
      approve: (id: number) => `/admin/withdrawals/${id}/approve`,
      reject: (id: number) => `/admin/withdrawals/${id}/reject`,
    },
    announcements: {
      list: '/admin/announcements',
      create: '/admin/announcements',
    },
    auditLogs: '/admin/audit-logs',
  },
};

// API Client Helper
export class APIClient {
  private baseURL: string;
  private token: string | null = null;

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL;
    this.loadToken();
  }

  private loadToken() {
    this.token = localStorage.getItem('access_token');
  }

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('access_token', token);
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
  }

  private getHeaders() {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    return headers;
  }

  async request(
    method: 'GET' | 'POST' | 'PUT' | 'DELETE',
    endpoint: string,
    data?: any
  ): Promise<any> {
    const url = `${this.baseURL}${endpoint}`;
    const options: RequestInit = {
      method,
      headers: this.getHeaders(),
    };

    if (data && (method === 'POST' || method === 'PUT')) {
      options.body = JSON.stringify(data);
    }

    try {
      const response = await fetch(url, options);

      if (response.status === 401) {
        // Token expired, try to refresh
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          // Retry the request
          return this.request(method, endpoint, data);
        } else {
          // Redirect to login
          window.location.href = '/login';
          throw new Error('Unauthorized');
        }
      }

      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(responseData.message || 'API Error');
      }

      return responseData;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  private async refreshAccessToken() {
    const refreshToken = localStorage.getItem('refresh_token');
    if (!refreshToken) return false;

    try {
      const response = await fetch(`${this.baseURL}/auth/refresh-token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });

      const data = await response.json();
      if (data.access_token) {
        this.setToken(data.access_token);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  get(endpoint: string) {
    return this.request('GET', endpoint);
  }

  post(endpoint: string, data?: any) {
    return this.request('POST', endpoint, data);
  }

  put(endpoint: string, data?: any) {
    return this.request('PUT', endpoint, data);
  }

  delete(endpoint: string) {
    return this.request('DELETE', endpoint);
  }
}

export const apiClient = new APIClient();

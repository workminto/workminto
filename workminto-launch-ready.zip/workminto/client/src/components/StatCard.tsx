import { LucideIcon } from "lucide-react";

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  change?: {
    value: number;
    isPositive: boolean;
  };
  color?: "pink" | "purple" | "cyan" | "orange";
}

/**
 * Workminto Stat Card
 * Displays key metrics with icon and optional change indicator
 */
export function StatCard({
  icon: Icon,
  label,
  value,
  change,
  color = "pink",
}: StatCardProps) {
  const colorClasses = {
    pink: "bg-pink-500/20 border-pink-500/50 text-pink-400",
    purple: "bg-purple-500/20 border-purple-500/50 text-purple-400",
    cyan: "bg-cyan-500/20 border-cyan-500/50 text-cyan-400",
    orange: "bg-orange-500/20 border-orange-500/50 text-orange-400",
  };

  return (
    <div
      className="glass-card p-6 flex flex-col gap-4"
      style={{
        boxShadow: "0 0 30px rgba(255, 20, 147, 0.1)",
      }}
    >
      <div className={`w-10 h-10 rounded-lg border flex items-center justify-center ${colorClasses[color]}`}>
        <Icon className="w-5 h-5" />
      </div>

      <div>
        <p className="text-sm text-gray-400">{label}</p>
        <div className="flex items-baseline gap-2 mt-2">
          <p className="text-3xl font-bold text-white">{value}</p>
          {change && (
            <span
              className={`text-xs font-semibold ${
                change.isPositive ? "text-green-400" : "text-red-400"
              }`}
            >
              {change.isPositive ? "+" : "-"}
              {Math.abs(change.value)}%
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

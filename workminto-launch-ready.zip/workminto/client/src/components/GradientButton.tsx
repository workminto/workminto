import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface GradientButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: "default" | "secondary" | "outline";
  size?: "sm" | "lg";
}

/**
 * Workminto Gradient Button
 * Premium neon pink-to-orange gradient with glow effect
 * Used for primary CTAs throughout the landing page
 */
export function GradientButton({
  children,
  className,
  variant = "default",
  size = "lg",
  ...props
}: GradientButtonProps) {
  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    lg: "px-8 py-4 text-lg",
  };

  if (variant === "default") {
    return (
      <button
        className={cn(
          "btn-gradient",
          sizeClasses[size],
          "rounded-full font-semibold",
          "transition-all duration-200",
          "hover:shadow-lg hover:scale-105",
          "active:scale-95",
          className
        )}
        {...props}
      >
        {children}
      </button>
    );
  }

  return (
    <Button variant={variant} size={size} className={className} {...props}>
      {children}
    </Button>
  );
}

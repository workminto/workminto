import { useState } from "react";
import { Menu, X, LogOut, Settings, BarChart3, Users, FileText, Bell, Lock } from "lucide-react";
import { Link, useLocation } from "wouter";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/workminto-logo-8TkXm59QVr7XQkJ4WqoAGR.webp";

interface AdminLayoutProps {
  children: React.ReactNode;
}

/**
 * Workminto Admin Layout
 * Sidebar navigation with admin-only routes
 * Premium dark theme with neon accents
 */
export function AdminLayout({ children }: AdminLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [location] = useLocation();

  const adminNavItems = [
    { label: "Dashboard", href: "/admin", icon: BarChart3 },
    { label: "Users", href: "/admin/users", icon: Users },
    { label: "Tasks", href: "/admin/tasks", icon: FileText },
    { label: "Offers", href: "/admin/offers", icon: Bell },
    { label: "Withdrawals", href: "/admin/withdrawals", icon: FileText },
    { label: "Announcements", href: "/admin/announcements", icon: Bell },
    { label: "Analytics", href: "/admin/analytics", icon: BarChart3 },
    { label: "Audit Logs", href: "/admin/audit-logs", icon: Lock },
    { label: "Security", href: "/admin/security", icon: Lock },
    { label: "Settings", href: "/admin/settings", icon: Settings },
  ];

  const isActive = (href: string) => location === href;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-black/40 backdrop-blur-xl">
        <div className="flex items-center justify-between px-4 md:px-6 h-16 md:h-20">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden p-2 text-white hover:text-pink-400 transition-colors"
            >
              {sidebarOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
            <Link href="/admin" className="flex items-center gap-2 group">
              <img
                src={LOGO_URL}
                alt="Workminto"
                className="w-8 h-8 md:w-10 md:h-10 transition-transform duration-300 group-hover:scale-110"
              />
              <span className="hidden sm:inline font-bold text-lg md:text-xl text-white">
                Workminto Admin
              </span>
            </Link>
          </div>

          {/* Header Actions */}
          <div className="flex items-center gap-4">
            <button className="px-4 py-2 rounded-lg text-gray-400 hover:text-white transition-colors text-sm font-medium">
              Admin
            </button>
            <button className="px-4 py-2 rounded-full border border-destructive/50 hover:border-destructive transition-all duration-200 text-destructive font-semibold text-sm flex items-center gap-2">
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="fixed md:sticky top-20 md:top-20 left-0 w-64 h-[calc(100vh-80px)] md:h-[calc(100vh-80px)] bg-black/40 border-r border-white/10 overflow-y-auto z-30">
            <nav className="p-4 space-y-2">
              {adminNavItems.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);
                return (
                  <Link key={item.href} href={item.href}>
                    <a
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                        active
                          ? "bg-pink-500/20 border border-pink-500/50 text-pink-400"
                          : "text-gray-400 hover:text-white hover:bg-white/5"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </a>
                  </Link>
                );
              })}
            </nav>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex-1 w-full md:w-auto">
          <div className="p-4 md:p-8 max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
}

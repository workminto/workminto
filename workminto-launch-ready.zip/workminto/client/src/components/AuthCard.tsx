import { cn } from "@/lib/utils";

interface AuthCardProps {
  children: React.ReactNode;
  className?: string;
}

/**
 * Workminto Auth Card
 * Premium glass morphism card for authentication screens
 * Consistent styling across all auth pages
 */
export function AuthCard({ children, className }: AuthCardProps) {
  return (
    <div
      className={cn(
        "glass-card p-8 md:p-10 w-full max-w-md",
        "flex flex-col gap-6",
        className
      )}
      style={{
        boxShadow: "0 0 30px rgba(255, 20, 147, 0.15)",
      }}
    >
      {children}
    </div>
  );
}

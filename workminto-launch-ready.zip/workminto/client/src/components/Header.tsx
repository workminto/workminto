import { useState } from "react";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/workminto-logo-8TkXm59QVr7XQkJ4WqoAGR.webp";

/**
 * Workminto Header
 * Premium header with logo and mobile-responsive navigation
 * Features glass morphism design and neon accents
 */
export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: "Features", href: "/features" },
    { label: "Pricing", href: "/pricing" },
    { label: "Security", href: "/security" },
    { label: "About", href: "/about" },
    { label: "Blog", href: "/blog" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Glass morphism background */}
      <div
        className="absolute inset-0 glass-card border-b border-white/10"
        style={{
          background: "rgba(24, 30, 60, 0.5)",
          backdropFilter: "blur(10px)",
        }}
      />

      <div className="relative container flex items-center justify-between h-16 md:h-20">
        {/* Logo */}
        <a href="/" className="flex items-center gap-2 group">
          <img
            src={LOGO_URL}
            alt="Workminto"
            className="w-8 h-8 md:w-10 md:h-10 transition-transform duration-300 group-hover:scale-110"
          />
          <span className="hidden sm:inline font-bold text-lg md:text-xl text-white">
            Workminto
          </span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="text-gray-300 hover:text-white transition-colors duration-200 text-sm font-medium"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* CTA Button - Desktop */}
        <a href="/auth/signup">
          <button className="hidden md:block btn-gradient px-6 py-2 text-sm font-semibold rounded-full">
            Get Started
          </button>
        </a>

        {/* Mobile Menu Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-white hover:text-pink-400 transition-colors"
        >
          {mobileMenuOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <Menu className="w-6 h-6" />
          )}
        </button>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div
          className="md:hidden border-t border-white/10"
          style={{
            background: "rgba(24, 30, 60, 0.8)",
            backdropFilter: "blur(10px)",
          }}
        >
          <nav className="container py-4 flex flex-col gap-4">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-gray-300 hover:text-white transition-colors duration-200 text-sm font-medium py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <a href="/auth/signup" className="w-full">
              <button className="btn-gradient w-full py-2 text-sm font-semibold rounded-full mt-2">
                Get Started
              </button>
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import {
  Home,
  Zap,
  Gift,
  Wallet,
  Users,
  User,
  Menu,
  X,
  LogOut,
} from "lucide-react";

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/workminto-logo-8TkXm59QVr7XQkJ4WqoAGR.webp";

interface AppLayoutProps {
  children: React.ReactNode;
  activeTab?: string;
}

/**
 * Workminto App Layout
 * Main layout for authenticated user pages
 * Features top navigation and bottom navigation for mobile
 */
export function AppLayout({ children, activeTab = "dashboard" }: AppLayoutProps) {
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "dashboard", label: "Home", href: "/app/dashboard", icon: Home },
    { id: "tasks", label: "Tasks", href: "/app/tasks", icon: Zap },
    { id: "offers", label: "Offers", href: "/app/offers", icon: Gift },
    { id: "wallet", label: "Wallet", href: "/app/wallet", icon: Wallet },
    { id: "referrals", label: "Referrals", href: "/app/referrals", icon: Users },
    { id: "profile", label: "Profile", href: "/app/profile", icon: User },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top Navigation */}
      <header className="border-b border-white/10 bg-background/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="container py-4 flex items-center justify-between">
          <a href="/app/dashboard" className="flex items-center gap-2">
            <img
              src={LOGO_URL}
              alt="Workminto"
              className="w-8 h-8 md:w-10 md:h-10"
            />
            <span className="hidden sm:inline font-bold text-lg text-white">
              Workminto
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <a
                  key={item.id}
                  href={item.href}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
                    activeTab === item.id
                      ? "bg-pink-500/20 text-pink-400 border border-pink-500/50"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </a>
              );
            })}
          </nav>

          {/* Profile & Logout - Desktop */}
          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={() => setLocation("/")}
              className="px-4 py-2 rounded-full border border-white/20 hover:border-white/40 transition-all duration-200 text-white font-semibold text-sm"
            >
              Logout
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-white hover:text-pink-400 transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-white/10 bg-background/80">
            <nav className="container py-4 flex flex-col gap-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <a
                    key={item.id}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center gap-2 ${
                      activeTab === item.id
                        ? "bg-pink-500/20 text-pink-400 border border-pink-500/50"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </a>
                );
              })}
              <button
                onClick={() => setLocation("/")}
                className="px-4 py-2 rounded-lg text-sm font-medium text-gray-400 hover:text-white transition-all duration-200 flex items-center gap-2 mt-2 border-t border-white/10 pt-4"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 container py-8 md:py-12">{children}</main>

      {/* Bottom Navigation - Mobile Only */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t border-white/10 bg-background/80 backdrop-blur-xl">
        <div className="container flex items-center justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <a
                key={item.id}
                href={item.href}
                className={`flex-1 py-4 flex flex-col items-center gap-1 text-xs font-medium transition-all duration-200 ${
                  activeTab === item.id
                    ? "text-pink-400"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </a>
            );
          })}
        </div>
      </nav>

      {/* Padding for bottom nav on mobile */}
      <div className="md:hidden h-20" />
    </div>
  );
}

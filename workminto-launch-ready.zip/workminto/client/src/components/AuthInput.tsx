import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { AlertCircle, CheckCircle2 } from "lucide-react";

interface AuthInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  success?: boolean;
  icon?: React.ReactNode;
}

/**
 * Workminto Auth Input
 * Premium input field with error and success states
 * Used in all authentication forms
 */
export function AuthInput({
  label,
  error,
  success,
  icon,
  className,
  ...props
}: AuthInputProps) {
  return (
    <div className="flex flex-col gap-2">
      {label && (
        <label className="text-sm font-medium text-gray-300">{label}</label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            {icon}
          </div>
        )}
        <Input
          className={cn(
            "bg-white/5 border border-white/10 text-white placeholder-gray-500",
            "focus:border-pink-500 focus:ring-pink-500/20",
            "transition-all duration-200",
            icon && "pl-10",
            error && "border-red-500/50 focus:border-red-500",
            success && "border-green-500/50 focus:border-green-500",
            className
          )}
          {...props}
        />
        {error && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-red-400">
            <AlertCircle className="w-5 h-5" />
          </div>
        )}
        {success && !error && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-green-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        )}
      </div>
      {error && (
        <p className="text-xs text-red-400">{error}</p>
      )}
    </div>
  );
}

import { cn } from "@/lib/utils";

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  className?: string;
}

/**
 * Workminto Feature Card
 * Glass morphism card with icon, title, and description
 * Used in the features section of the landing page
 */
export function FeatureCard({
  icon,
  title,
  description,
  className,
}: FeatureCardProps) {
  return (
    <div
      className={cn(
        "glass-card p-6 md:p-8",
        "flex flex-col items-start gap-4",
        "transition-all duration-300",
        "hover:border-white/30 hover:shadow-lg",
        className
      )}
      style={{
        boxShadow: "0 0 20px rgba(255, 20, 147, 0.1)",
      }}
    >
      <div className="w-12 h-12 md:w-16 md:h-16 flex items-center justify-center">
        {icon}
      </div>
      <div className="flex flex-col gap-2">
        <h3 className="text-lg md:text-xl font-bold text-white">{title}</h3>
        <p className="text-sm md:text-base text-gray-400 leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
}

import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

interface AuthLayoutProps {
  children: React.ReactNode;
  showBackButton?: boolean;
}

const LOGO_URL =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663779475033/RmhigtDwAd4vRpmB67XUAM/workminto-logo-8TkXm59QVr7XQkJ4WqoAGR.webp";

/**
 * Workminto Auth Layout
 * Consistent layout for all authentication pages
 * Features dark background, logo, and optional back button
 */
export function AuthLayout({
  children,
  showBackButton = true,
}: AuthLayoutProps) {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="container py-6 md:py-8 flex items-center justify-between">
        <a href="/" className="flex items-center gap-2 group">
          <img
            src={LOGO_URL}
            alt="Workminto"
            className="w-8 h-8 md:w-10 md:h-10 transition-transform duration-300 group-hover:scale-110"
          />
          <span className="hidden sm:inline font-bold text-lg md:text-xl text-white">
            Workminto
          </span>
        </a>

        {showBackButton && (
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors duration-200"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm">Back</span>
          </button>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 container flex items-center justify-center py-12 md:py-0">
        {children}
      </div>

      {/* Footer */}
      <div className="border-t border-white/10 py-6 md:py-8">
        <div className="container text-center text-xs md:text-sm text-gray-500">
          <p>&copy; 2024 Workminto. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}

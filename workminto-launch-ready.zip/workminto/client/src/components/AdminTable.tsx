import { ChevronDown, ChevronUp, Search } from "lucide-react";
import { useState } from "react";

interface Column<T> {
  key: keyof T;
  label: string;
  sortable?: boolean;
  render?: (value: any, row: T) => React.ReactNode;
}

interface AdminTableProps<T> {
  columns: Column<T>[];
  data: T[];
  title?: string;
  searchable?: boolean;
  onRowClick?: (row: T) => void;
}

/**
 * Workminto Admin Table
 * Reusable table component with sorting and search
 */
export function AdminTable<T extends { id: string | number }>({
  columns,
  data,
  title,
  searchable = true,
  onRowClick,
}: AdminTableProps<T>) {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortKey, setSortKey] = useState<keyof T | null>(null);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  const filteredData = data.filter((row) =>
    columns.some((col) => {
      const value = row[col.key];
      return value
        ?.toString()
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
    })
  );

  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortKey) return 0;
    const aVal = a[sortKey];
    const bVal = b[sortKey];
    if (aVal < bVal) return sortOrder === "asc" ? -1 : 1;
    if (aVal > bVal) return sortOrder === "asc" ? 1 : -1;
    return 0;
  });

  const handleSort = (key: keyof T) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  return (
    <div className="space-y-6">
      {title && (
        <div>
          <h2 className="text-2xl font-bold text-white">{title}</h2>
        </div>
      )}

      {searchable && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 focus:border-pink-500/50 focus:outline-none text-white placeholder-gray-500 transition-all duration-200"
          />
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/10">
              {columns.map((col) => (
                <th
                  key={String(col.key)}
                  className="px-4 py-4 text-left text-sm font-semibold text-gray-300"
                >
                  <button
                    onClick={() => col.sortable && handleSort(col.key)}
                    className={`flex items-center gap-2 ${
                      col.sortable ? "cursor-pointer hover:text-white" : ""
                    }`}
                  >
                    {col.label}
                    {col.sortable && sortKey === col.key && (
                      <>
                        {sortOrder === "asc" ? (
                          <ChevronUp className="w-4 h-4 text-pink-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-pink-400" />
                        )}
                      </>
                    )}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedData.map((row) => (
              <tr
                key={row.id}
                onClick={() => onRowClick?.(row)}
                className={`border-b border-white/5 hover:bg-white/5 transition-colors ${
                  onRowClick ? "cursor-pointer" : ""
                }`}
              >
                {columns.map((col) => (
                  <td
                    key={String(col.key)}
                    className="px-4 py-4 text-sm text-gray-300"
                  >
                    {col.render
                      ? col.render(row[col.key], row)
                      : String(row[col.key])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {sortedData.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-400">No data found</p>
        </div>
      )}
    </div>
  );
}

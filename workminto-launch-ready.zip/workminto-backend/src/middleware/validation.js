import validator from 'validator';

export const validateEmail = (email) => {
  return validator.isEmail(email);
};

export const validatePassword = (password) => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special char
  const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return regex.test(password);
};

export const validateUsername = (username) => {
  // 3-50 characters, alphanumeric and underscore only
  const regex = /^[a-zA-Z0-9_]{3,50}$/;
  return regex.test(username);
};

export const validatePhoneNumber = (phone) => {
  return validator.isMobilePhone(phone);
};

export const validateOTP = (otp) => {
  return /^\d{6}$/.test(otp);
};

export const sanitizeInput = (input) => {
  if (typeof input !== 'string') return input;
  return validator.trim(validator.escape(input));
};

export const validateSignupInput = (data) => {
  const errors = {};

  if (!data.email || !validateEmail(data.email)) {
    errors.email = 'Valid email is required';
  }

  if (!data.password || !validatePassword(data.password)) {
    errors.password = 'Password must be at least 8 characters with uppercase, lowercase, number, and special character';
  }

  if (!data.first_name || data.first_name.trim().length === 0) {
    errors.first_name = 'First name is required';
  }

  if (!data.last_name || data.last_name.trim().length === 0) {
    errors.last_name = 'Last name is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

export const validateLoginInput = (data) => {
  const errors = {};

  if (!data.email || !validateEmail(data.email)) {
    errors.email = 'Valid email is required';
  }

  if (!data.password || data.password.length === 0) {
    errors.password = 'Password is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

export const validateWithdrawalInput = (data) => {
  const errors = {};

  if (!data.amount_points || data.amount_points < 500) {
    errors.amount_points = 'Minimum withdrawal is 500 points';
  }

  if (!data.method || !['paypal', 'bank', 'crypto'].includes(data.method)) {
    errors.method = 'Valid withdrawal method is required';
  }

  if (!data.payment_details || Object.keys(data.payment_details).length === 0) {
    errors.payment_details = 'Payment details are required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

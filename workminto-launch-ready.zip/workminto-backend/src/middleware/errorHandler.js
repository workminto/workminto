export class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
  }
}

export const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

export const errorHandler = (err, req, res, next) => {
  console.error('Error:', err);

  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      error: err.message.toLowerCase().replace(/\s+/g, '_'),
      message: err.message,
    });
  }

  if (err.code === '23505') {
    // Unique constraint violation
    const field = err.constraint?.split('_')[1] || 'field';
    return res.status(409).json({
      error: 'conflict',
      message: `${field} already exists`,
    });
  }

  if (err.code === '23503') {
    // Foreign key violation
    return res.status(400).json({
      error: 'invalid_reference',
      message: 'Referenced record does not exist',
    });
  }

  res.status(500).json({
    error: 'internal_server_error',
    message: 'An unexpected error occurred',
  });
};

export const notFoundHandler = (req, res) => {
  res.status(404).json({
    error: 'not_found',
    message: 'Resource not found',
  });
};

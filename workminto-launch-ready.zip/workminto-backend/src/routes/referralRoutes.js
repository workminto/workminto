import express from 'express';
import * as referralController from '../controllers/referralController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Public route
router.post('/validate-code', referralController.validateReferralCode);

// Protected routes
router.use(authenticateToken);

router.get('/stats', referralController.getReferralStats);
router.get('/history', referralController.getReferralHistory);
router.post('/award-bonus', referralController.awardReferralBonus);

export default router;

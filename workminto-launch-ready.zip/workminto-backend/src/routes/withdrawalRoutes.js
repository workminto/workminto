import express from 'express';
import * as withdrawalController from '../controllers/withdrawalController.js';
import { authenticateToken, authorizeAdmin } from '../middleware/auth.js';

const router = express.Router();

// User routes
router.use(authenticateToken);

router.post('/', withdrawalController.createWithdrawal);
router.get('/', withdrawalController.getUserWithdrawals);
router.get('/:withdrawalId', withdrawalController.getWithdrawalDetails);

// Admin routes
router.get('/admin/pending', authorizeAdmin, withdrawalController.getPendingWithdrawals);
router.post('/admin/:withdrawalId/approve', authorizeAdmin, withdrawalController.approveWithdrawal);
router.post('/admin/:withdrawalId/reject', authorizeAdmin, withdrawalController.rejectWithdrawal);

export default router;

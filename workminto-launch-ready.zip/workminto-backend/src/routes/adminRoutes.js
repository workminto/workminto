import express from 'express';
import * as adminController from '../controllers/adminController.js';
import { authenticateToken, authorizeAdmin } from '../middleware/auth.js';

const router = express.Router();

// All admin routes require authentication and admin role
router.use(authenticateToken);
router.use(authorizeAdmin);

// Dashboard
router.get('/dashboard/stats', adminController.getDashboardStats);

// Users
router.get('/users', adminController.getUsers);
router.get('/users/:userId', adminController.getUserDetails);
router.post('/users/:userId/suspend', adminController.suspendUser);
router.post('/users/:userId/ban', adminController.banUser);

// Tasks
router.get('/tasks', adminController.getTasks);
router.post('/tasks', adminController.createTask);
router.put('/tasks/:taskId', adminController.updateTask);
router.delete('/tasks/:taskId', adminController.deleteTask);

// Announcements
router.get('/announcements', adminController.getAnnouncements);
router.post('/announcements', adminController.createAnnouncement);

// Audit Logs
router.get('/audit-logs', adminController.getAuditLogs);

export default router;

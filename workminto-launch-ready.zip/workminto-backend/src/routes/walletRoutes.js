import express from 'express';
import * as walletController from '../controllers/walletController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get wallet
router.get('/', walletController.getWallet);

// Get transactions
router.get('/transactions', walletController.getTransactions);

// Add points (internal use)
router.post('/add-points', walletController.addPoints);

// Deduct points (internal use)
router.post('/deduct-points', walletController.deductPoints);

export default router;

import { query } from '../config/database.js';
import { AppError, asyncHandler } from '../middleware/errorHandler.js';

// Get admin dashboard stats
export const getDashboardStats = asyncHandler(async (req, res) => {
  // Total users
  const usersResult = await query('SELECT COUNT(*) as total FROM users WHERE status = $1', ['active']);
  const totalUsers = parseInt(usersResult.rows[0].total);

  // Active users (logged in last 7 days)
  const activeUsersResult = await query(
    'SELECT COUNT(*) as total FROM users WHERE last_login > CURRENT_TIMESTAMP - INTERVAL \'7 days\''
  );
  const activeUsers = parseInt(activeUsersResult.rows[0].total);

  // Total points distributed
  const pointsResult = await query(
    'SELECT SUM(total_points) as total FROM wallets'
  );
  const totalPointsDistributed = parseInt(pointsResult.rows[0].total) || 0;

  // Pending withdrawals
  const pendingResult = await query(
    'SELECT COUNT(*) as total FROM withdrawals WHERE status = $1',
    ['pending']
  );
  const pendingWithdrawals = parseInt(pendingResult.rows[0].total);

  // Completed withdrawals
  const completedResult = await query(
    'SELECT COUNT(*) as total FROM withdrawals WHERE status = $1',
    ['completed']
  );
  const completedWithdrawals = parseInt(completedResult.rows[0].total);

  // Recent activity
  const activityResult = await query(
    `SELECT 
      'user_signup' as type, u.created_at as timestamp, u.email as description
     FROM users u
     WHERE u.created_at > CURRENT_TIMESTAMP - INTERVAL '24 hours'
     UNION ALL
     SELECT 
      'withdrawal_request' as type, w.requested_at as timestamp, 
      CONCAT(u.email, ' - ', w.amount_points, ' points') as description
     FROM withdrawals w
     JOIN users u ON w.user_id = u.id
     WHERE w.requested_at > CURRENT_TIMESTAMP - INTERVAL '24 hours'
     ORDER BY timestamp DESC
     LIMIT 10`
  );

  res.json({
    total_users: totalUsers,
    active_users: activeUsers,
    total_points_distributed: totalPointsDistributed,
    pending_withdrawals: pendingWithdrawals,
    completed_withdrawals: completedWithdrawals,
    recent_activity: activityResult.rows,
  });
});

// Get users list
export const getUsers = asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const offset = parseInt(req.query.offset) || 0;
  const status = req.query.status || 'active';
  const search = req.query.search;

  let sql = `SELECT u.id, u.email, u.first_name, u.last_name, u.status, u.level, 
             w.total_points_earned, u.created_at
             FROM users u
             LEFT JOIN wallets w ON u.id = w.user_id
             WHERE u.status = $1`;
  const params = [status];

  if (search) {
    sql += ' AND (u.email ILIKE $' + (params.length + 1) + ' OR u.first_name ILIKE $' + (params.length + 1) + ')';
    params.push(`%${search}%`);
  }

  sql += ' ORDER BY u.created_at DESC LIMIT $' + (params.length + 1) + ' OFFSET $' + (params.length + 2);
  params.push(limit, offset);

  const result = await query(sql, params);

  // Get count
  let countSql = 'SELECT COUNT(*) as total FROM users WHERE status = $1';
  const countParams = [status];

  if (search) {
    countSql += ' AND (email ILIKE $2 OR first_name ILIKE $2)';
    countParams.push(`%${search}%`);
  }

  const countResult = await query(countSql, countParams);

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Get user details
export const getUserDetails = asyncHandler(async (req, res) => {
  const { userId } = req.params;

  const userResult = await query(
    `SELECT u.*, w.total_points, w.available_points FROM users u
     LEFT JOIN wallets w ON u.id = w.user_id
     WHERE u.id = $1`,
    [userId]
  );

  if (userResult.rows.length === 0) {
    throw new AppError('User not found', 404);
  }

  const user = userResult.rows[0];

  // Get referral stats
  const referralResult = await query(
    `SELECT COUNT(*) as total_referrals, 
            SUM(CASE WHEN bonus_awarded = TRUE THEN 1 ELSE 0 END) as completed_referrals
     FROM referrals WHERE referrer_id = $1`,
    [userId]
  );

  // Get task completions
  const taskResult = await query(
    'SELECT COUNT(*) as total_tasks FROM task_completions WHERE user_id = $1',
    [userId]
  );

  res.json({
    ...user,
    referral_stats: referralResult.rows[0],
    task_completions: parseInt(taskResult.rows[0].total_tasks),
  });
});

// Suspend user
export const suspendUser = asyncHandler(async (req, res) => {
  const { userId } = req.params;
  const { reason } = req.body;
  const adminId = req.user.id;

  // Update user status
  await query('UPDATE users SET status = $1 WHERE id = $2', ['suspended', userId]);

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id, changes)
     VALUES ($1, $2, $3, $4, $5)`,
    [adminId, 'suspend_user', 'user', userId, JSON.stringify({ reason })]
  );

  res.json({
    message: 'User suspended successfully',
  });
});

// Ban user
export const banUser = asyncHandler(async (req, res) => {
  const { userId } = req.params;
  const { reason } = req.body;
  const adminId = req.user.id;

  // Update user status
  await query('UPDATE users SET status = $1 WHERE id = $2', ['banned', userId]);

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id, changes)
     VALUES ($1, $2, $3, $4, $5)`,
    [adminId, 'ban_user', 'user', userId, JSON.stringify({ reason })]
  );

  res.json({
    message: 'User banned successfully',
  });
});

// Get tasks
export const getTasks = asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const offset = parseInt(req.query.offset) || 0;
  const status = req.query.status || 'active';

  const result = await query(
    `SELECT * FROM tasks WHERE status = $1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
    [status, limit, offset]
  );

  const countResult = await query(
    'SELECT COUNT(*) as total FROM tasks WHERE status = $1',
    [status]
  );

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Create task
export const createTask = asyncHandler(async (req, res) => {
  const { title, description, category, reward_points } = req.body;
  const adminId = req.user.id;

  if (!title || !category || !reward_points) {
    throw new AppError('Title, category, and reward_points are required', 400);
  }

  const result = await query(
    `INSERT INTO tasks (title, description, category, reward_points, created_by)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [title, description, category, reward_points, adminId]
  );

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id)
     VALUES ($1, $2, $3, $4)`,
    [adminId, 'create_task', 'task', result.rows[0].id]
  );

  res.status(201).json(result.rows[0]);
});

// Update task
export const updateTask = asyncHandler(async (req, res) => {
  const { taskId } = req.params;
  const { title, description, category, reward_points, status } = req.body;
  const adminId = req.user.id;

  const result = await query(
    `UPDATE tasks SET title = COALESCE($1, title), 
                     description = COALESCE($2, description),
                     category = COALESCE($3, category),
                     reward_points = COALESCE($4, reward_points),
                     status = COALESCE($5, status)
     WHERE id = $6
     RETURNING *`,
    [title, description, category, reward_points, status, taskId]
  );

  if (result.rows.length === 0) {
    throw new AppError('Task not found', 404);
  }

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id)
     VALUES ($1, $2, $3, $4)`,
    [adminId, 'update_task', 'task', taskId]
  );

  res.json(result.rows[0]);
});

// Delete task
export const deleteTask = asyncHandler(async (req, res) => {
  const { taskId } = req.params;
  const adminId = req.user.id;

  const result = await query('DELETE FROM tasks WHERE id = $1 RETURNING id', [taskId]);

  if (result.rows.length === 0) {
    throw new AppError('Task not found', 404);
  }

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id)
     VALUES ($1, $2, $3, $4)`,
    [adminId, 'delete_task', 'task', taskId]
  );

  res.json({
    message: 'Task deleted successfully',
  });
});

// Get announcements
export const getAnnouncements = asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const offset = parseInt(req.query.offset) || 0;
  const status = req.query.status || 'published';

  const result = await query(
    `SELECT * FROM announcements WHERE status = $1 ORDER BY published_at DESC LIMIT $2 OFFSET $3`,
    [status, limit, offset]
  );

  const countResult = await query(
    'SELECT COUNT(*) as total FROM announcements WHERE status = $1',
    [status]
  );

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Create announcement
export const createAnnouncement = asyncHandler(async (req, res) => {
  const { title, content, type, target_audience, status } = req.body;
  const adminId = req.user.id;

  if (!title || !content) {
    throw new AppError('Title and content are required', 400);
  }

  const result = await query(
    `INSERT INTO announcements (title, content, type, target_audience, status, created_by, published_at)
     VALUES ($1, $2, $3, $4, $5, $6, CASE WHEN $5 = 'published' THEN CURRENT_TIMESTAMP ELSE NULL END)
     RETURNING *`,
    [title, content, type || 'info', target_audience || 'all_users', status || 'draft', adminId]
  );

  res.status(201).json(result.rows[0]);
});

// Get audit logs
export const getAuditLogs = asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const offset = parseInt(req.query.offset) || 0;
  const action_type = req.query.action_type;

  let sql = `SELECT * FROM audit_logs WHERE 1=1`;
  const params = [];

  if (action_type) {
    sql += ' AND action_type = $' + (params.length + 1);
    params.push(action_type);
  }

  sql += ' ORDER BY created_at DESC LIMIT $' + (params.length + 1) + ' OFFSET $' + (params.length + 2);
  params.push(limit, offset);

  const result = await query(sql, params);

  const countResult = await query('SELECT COUNT(*) as total FROM audit_logs');

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

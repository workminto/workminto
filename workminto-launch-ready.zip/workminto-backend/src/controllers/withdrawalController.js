import { query } from '../config/database.js';
import { sendWithdrawalApprovedEmail, sendWithdrawalRejectedEmail, sendEmail } from '../utils/email.js';
import { validateWithdrawalInput } from '../middleware/validation.js';
import { AppError, asyncHandler } from '../middleware/errorHandler.js';

// Create withdrawal request
export const createWithdrawal = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const { amount_points, method, payment_details } = req.body;

  // Validate input
  const validation = validateWithdrawalInput({ amount_points, method, payment_details });
  if (!validation.isValid) {
    return res.status(400).json({
      error: 'validation_error',
      details: validation.errors,
    });
  }

  // Get wallet
  const walletResult = await query(
    'SELECT * FROM wallets WHERE user_id = $1',
    [userId]
  );

  if (walletResult.rows.length === 0) {
    throw new AppError('Wallet not found', 404);
  }

  const wallet = walletResult.rows[0];

  if (wallet.available_points < amount_points) {
    throw new AppError('Insufficient points', 400);
  }

  // Calculate currency amount (1 point = $0.01)
  const amountCurrency = (amount_points / 100).toFixed(2);

  // Create withdrawal request
  const withdrawalResult = await query(
    `INSERT INTO withdrawals (user_id, amount_points, amount_currency, method, payment_details, status)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, status, requested_at`,
    [userId, amount_points, amountCurrency, method, JSON.stringify(payment_details), 'pending']
  );

  const withdrawal = withdrawalResult.rows[0];

  // Move points to pending
  await query(
    `UPDATE wallets SET available_points = available_points - $1, pending_points = pending_points + $1
     WHERE user_id = $2`,
    [amount_points, userId]
  );

  // Record transaction
  await query(
    `INSERT INTO wallet_transactions (user_id, type, amount, description, reference_id)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, 'withdrawal', amount_points, `Withdrawal request for ${amountCurrency}`, `withdrawal_${withdrawal.id}`]
  );

  // Get user info
  const userResult = await query(
    'SELECT email, first_name FROM users WHERE id = $1',
    [userId]
  );

  const user = userResult.rows[0];

  // Send email to user
  try {
    const subject = 'Withdrawal Request Submitted';
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Withdrawal Request Submitted</h2>
        <p>Hi ${user.first_name},</p>
        <p>Your withdrawal request has been submitted and is pending review.</p>
        <div style="background-color: #f0f0f0; padding: 20px; border-radius: 5px; margin: 20px 0;">
          <p><strong>Amount:</strong> ${amount_points} points (${amountCurrency})</p>
          <p><strong>Method:</strong> ${method}</p>
          <p><strong>Status:</strong> Pending</p>
        </div>
        <p>We'll review your request and notify you within 24 hours.</p>
      </div>
    `;
    await sendEmail(user.email, subject, html);
  } catch (error) {
    console.error('Failed to send withdrawal email:', error);
  }

  // Notify admin
  try {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@workminto.com';
    const subject = 'New Withdrawal Request - Requires Approval';
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>New Withdrawal Request</h2>
        <p><strong>User:</strong> ${user.first_name} (${user.email})</p>
        <p><strong>Amount:</strong> ${amount_points} points (${amountCurrency})</p>
        <p><strong>Method:</strong> ${method}</p>
        <p><a href="${process.env.API_URL}/admin/withdrawals/${withdrawal.id}">Review in Admin Panel</a></p>
      </div>
    `;
    await sendEmail(adminEmail, subject, html);
  } catch (error) {
    console.error('Failed to send admin notification:', error);
  }

  res.status(201).json({
    id: withdrawal.id,
    amount_points,
    amount_currency: parseFloat(amountCurrency),
    method,
    status: withdrawal.status,
    requested_at: withdrawal.requested_at,
    message: 'Withdrawal request submitted successfully',
  });
});

// Get user withdrawals
export const getUserWithdrawals = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const limit = Math.min(parseInt(req.query.limit) || 20, 100);
  const offset = parseInt(req.query.offset) || 0;
  const status = req.query.status;

  let sql = 'SELECT * FROM withdrawals WHERE user_id = $1';
  const params = [userId];

  if (status) {
    sql += ' AND status = $2';
    params.push(status);
  }

  sql += ' ORDER BY requested_at DESC LIMIT $' + (params.length + 1) + ' OFFSET $' + (params.length + 2);
  params.push(limit, offset);

  const result = await query(sql, params);

  // Get total count
  let countSql = 'SELECT COUNT(*) as total FROM withdrawals WHERE user_id = $1';
  const countParams = [userId];

  if (status) {
    countSql += ' AND status = $2';
    countParams.push(status);
  }

  const countResult = await query(countSql, countParams);

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Get withdrawal details
export const getWithdrawalDetails = asyncHandler(async (req, res) => {
  const { withdrawalId } = req.params;
  const userId = req.user.id;

  const result = await query(
    'SELECT * FROM withdrawals WHERE id = $1 AND user_id = $2',
    [withdrawalId, userId]
  );

  if (result.rows.length === 0) {
    throw new AppError('Withdrawal not found', 404);
  }

  res.json(result.rows[0]);
});

// Admin: Get pending withdrawals
export const getPendingWithdrawals = asyncHandler(async (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 20, 100);
  const offset = parseInt(req.query.offset) || 0;

  const result = await query(
    `SELECT w.*, u.email, u.first_name, u.last_name FROM withdrawals w
     JOIN users u ON w.user_id = u.id
     WHERE w.status = 'pending'
     ORDER BY w.requested_at ASC
     LIMIT $1 OFFSET $2`,
    [limit, offset]
  );

  const countResult = await query(
    'SELECT COUNT(*) as total FROM withdrawals WHERE status = $1',
    ['pending']
  );

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Admin: Approve withdrawal
export const approveWithdrawal = asyncHandler(async (req, res) => {
  const { withdrawalId } = req.params;
  const { notes } = req.body;
  const adminId = req.user.id;

  // Get withdrawal
  const withdrawalResult = await query(
    'SELECT * FROM withdrawals WHERE id = $1',
    [withdrawalId]
  );

  if (withdrawalResult.rows.length === 0) {
    throw new AppError('Withdrawal not found', 404);
  }

  const withdrawal = withdrawalResult.rows[0];

  if (withdrawal.status !== 'pending') {
    throw new AppError('Only pending withdrawals can be approved', 400);
  }

  // Update withdrawal
  await query(
    `UPDATE withdrawals SET status = $1, processed_at = CURRENT_TIMESTAMP, admin_notes = $2, approved_by = $3
     WHERE id = $4`,
    ['approved', notes || '', adminId, withdrawalId]
  );

  // Update wallet: move from pending_points to spent
  await query(
    `UPDATE wallets SET pending_points = pending_points - $1 WHERE user_id = $2`,
    [withdrawal.amount_points, withdrawal.user_id]
  );

  // Record transaction
  await query(
    `INSERT INTO wallet_transactions (user_id, type, amount, description, reference_id)
     VALUES ($1, $2, $3, $4, $5)`,
    [withdrawal.user_id, 'withdrawal_approved', withdrawal.amount_points, 
     `Withdrawal approved for ${withdrawal.amount_currency || 'N/A'}`, `withdrawal_${withdrawalId}`]
  );

  // Get user info
  const userResult = await query(
    'SELECT email, first_name FROM users WHERE id = $1',
    [withdrawal.user_id]
  );

  const user = userResult.rows[0];

  // Send approval email
  try {
    await sendWithdrawalApprovedEmail(user.email, user.first_name, withdrawal.amount_points, withdrawal.amount_currency);
  } catch (error) {
    console.error('Failed to send approval email:', error);
  }

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id, changes)
     VALUES ($1, $2, $3, $4, $5)`,
    [adminId, 'approve_withdrawal', 'withdrawal', withdrawalId, JSON.stringify({ status: 'approved' })]
  );

  res.json({
    message: 'Withdrawal approved successfully',
    withdrawal_id: withdrawalId,
    status: 'approved',
  });
});

// Admin: Reject withdrawal
export const rejectWithdrawal = asyncHandler(async (req, res) => {
  const { withdrawalId } = req.params;
  const { reason } = req.body;
  const adminId = req.user.id;

  if (!reason) {
    throw new AppError('Rejection reason is required', 400);
  }

  // Get withdrawal
  const withdrawalResult = await query(
    'SELECT * FROM withdrawals WHERE id = $1',
    [withdrawalId]
  );

  if (withdrawalResult.rows.length === 0) {
    throw new AppError('Withdrawal not found', 404);
  }

  const withdrawal = withdrawalResult.rows[0];

  if (withdrawal.status !== 'pending') {
    throw new AppError('Only pending withdrawals can be rejected', 400);
  }

  // Update withdrawal
  await query(
    `UPDATE withdrawals SET status = $1, processed_at = CURRENT_TIMESTAMP, admin_notes = $2
     WHERE id = $3`,
    ['rejected', reason, withdrawalId]
  );

  // Return points to available
  await query(
    `UPDATE wallets SET available_points = available_points + $1, pending_points = pending_points - $1
     WHERE user_id = $2`,
    [withdrawal.amount_points, withdrawal.user_id]
  );

  // Get user info
  const userResult = await query(
    'SELECT email, first_name FROM users WHERE id = $1',
    [withdrawal.user_id]
  );

  const user = userResult.rows[0];

  // Send rejection email
  try {
    await sendWithdrawalRejectedEmail(user.email, user.first_name, withdrawal.amount_points, reason);
  } catch (error) {
    console.error('Failed to send rejection email:', error);
  }

  // Log audit
  await query(
    `INSERT INTO audit_logs (admin_id, action_type, target_entity_type, target_entity_id, changes)
     VALUES ($1, $2, $3, $4, $5)`,
    [adminId, 'reject_withdrawal', 'withdrawal', withdrawalId, JSON.stringify({ status: 'rejected', reason })]
  );

  res.json({
    message: 'Withdrawal rejected successfully',
    withdrawal_id: withdrawalId,
    status: 'rejected',
  });
});

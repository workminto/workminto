import bcrypt from 'bcryptjs';
import { query } from '../config/database.js';
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from '../utils/jwt.js';
import { sendEmail, sendOTPEmail, sendPasswordResetEmail, sendWelcomeEmail } from '../utils/email.js';
import { validateSignupInput, validateLoginInput, validateEmail, validateOTP } from '../middleware/validation.js';
import { AppError, asyncHandler } from '../middleware/errorHandler.js';
import crypto from 'crypto';

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Generate referral code
const generateReferralCode = (username) => {
  return `${username.toUpperCase().substring(0, 4)}${Math.floor(Math.random() * 1000)}`;
};

// Signup
export const signup = asyncHandler(async (req, res) => {
  const { email, password, first_name, last_name, referral_code } = req.body;

  // Validate input
  const validation = validateSignupInput({ email, password, first_name, last_name });
  if (!validation.isValid) {
    return res.status(400).json({
      error: 'validation_error',
      details: validation.errors,
    });
  }

  // Check if user exists
  const existingUser = await query('SELECT id FROM users WHERE email = $1', [email]);
  if (existingUser.rows.length > 0) {
    throw new AppError('Email already registered', 409);
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, 10);

  // Generate username from email
  const username = email.split('@')[0] + Math.random().toString(36).substring(7);

  // Create user
  const userResult = await query(
    `INSERT INTO users (username, email, password_hash, first_name, last_name, status)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, email, first_name, last_name, created_at`,
    [username, email, passwordHash, first_name, last_name, 'active']
  );

  const userId = userResult.rows[0].id;

  // Create wallet
  await query(
    'INSERT INTO wallets (user_id, total_points, available_points) VALUES ($1, $2, $3)',
    [userId, 0, 0]
  );

  // Generate referral code
  const newReferralCode = generateReferralCode(email.split('@')[0]);
  await query(
    `INSERT INTO referrals (referrer_id, referred_user_id, referral_code, status)
     VALUES ($1, $2, $3, $4)`,
    [userId, userId, newReferralCode, 'active']
  );

  // Handle referral bonus
  if (referral_code) {
    const referrerResult = await query(
      'SELECT referrer_id FROM referrals WHERE referral_code = $1 LIMIT 1',
      [referral_code]
    );

    if (referrerResult.rows.length > 0) {
      const referrerId = referrerResult.rows[0].referrer_id;
      await query(
        `INSERT INTO referrals (referrer_id, referred_user_id, referral_code, status)
         VALUES ($1, $2, $3, $4)`,
        [referrerId, userId, newReferralCode, 'pending']
      );
    }
  }

  // Send welcome email
  try {
    await sendWelcomeEmail(email, first_name);
  } catch (error) {
    console.error('Failed to send welcome email:', error);
  }

  // Generate tokens
  const accessToken = generateAccessToken(userId, email, 'user');
  const refreshToken = generateRefreshToken(userId);

  // Store refresh token
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await query(
    'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
    [userId, refreshToken, expiresAt]
  );

  res.status(201).json({
    message: 'User registered successfully',
    access_token: accessToken,
    refresh_token: refreshToken,
    user: {
      id: userId,
      email: userResult.rows[0].email,
      first_name: userResult.rows[0].first_name,
      last_name: userResult.rows[0].last_name,
      status: 'active',
    },
  });
});

// Login
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // Validate input
  const validation = validateLoginInput({ email, password });
  if (!validation.isValid) {
    return res.status(400).json({
      error: 'validation_error',
      details: validation.errors,
    });
  }

  // Find user
  const userResult = await query(
    'SELECT id, email, password_hash, first_name, last_name, status, is_admin FROM users WHERE email = $1',
    [email]
  );

  if (userResult.rows.length === 0) {
    throw new AppError('Invalid email or password', 401);
  }

  const user = userResult.rows[0];

  // Check password
  const passwordMatch = await bcrypt.compare(password, user.password_hash);
  if (!passwordMatch) {
    throw new AppError('Invalid email or password', 401);
  }

  // Update last login
  await query('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1', [user.id]);

  // Generate tokens
  const role = user.is_admin ? 'admin' : 'user';
  const accessToken = generateAccessToken(user.id, user.email, role);
  const refreshToken = generateRefreshToken(user.id);

  // Store refresh token
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await query(
    'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
    [user.id, refreshToken, expiresAt]
  );

  res.json({
    message: 'Login successful',
    access_token: accessToken,
    refresh_token: refreshToken,
    user: {
      id: user.id,
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name,
      status: user.status,
    },
  });
});

// Refresh token
export const refreshToken = asyncHandler(async (req, res) => {
  const { refresh_token } = req.body;

  if (!refresh_token) {
    throw new AppError('Refresh token required', 400);
  }

  try {
    const decoded = verifyRefreshToken(refresh_token);
    const userId = decoded.sub;

    // Check if token exists and is not revoked
    const tokenResult = await query(
      'SELECT * FROM refresh_tokens WHERE user_id = $1 AND token = $2 AND revoked = FALSE',
      [userId, refresh_token]
    );

    if (tokenResult.rows.length === 0) {
      throw new AppError('Invalid or revoked refresh token', 401);
    }

    // Get user
    const userResult = await query('SELECT id, email FROM users WHERE id = $1', [userId]);
    if (userResult.rows.length === 0) {
      throw new AppError('User not found', 404);
    }

    const user = userResult.rows[0];

    // Generate new access token
    const accessToken = generateAccessToken(user.id, user.email, 'user');

    res.json({
      access_token: accessToken,
    });
  } catch (error) {
    throw new AppError('Invalid refresh token', 401);
  }
});

// Request password reset
export const requestPasswordReset = asyncHandler(async (req, res) => {
  const { email } = req.body;

  if (!validateEmail(email)) {
    throw new AppError('Valid email is required', 400);
  }

  // Find user
  const userResult = await query('SELECT id, first_name FROM users WHERE email = $1', [email]);
  if (userResult.rows.length === 0) {
    // Don't reveal if email exists
    return res.json({
      message: 'If email exists, password reset link will be sent',
    });
  }

  const user = userResult.rows[0];

  // Generate reset token
  const resetToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = await bcrypt.hash(resetToken, 10);
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

  // Store reset token
  await query(
    'INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
    [user.id, tokenHash, expiresAt]
  );

  // Send email
  try {
    await sendPasswordResetEmail(email, resetToken);
  } catch (error) {
    console.error('Failed to send password reset email:', error);
  }

  res.json({
    message: 'If email exists, password reset link will be sent',
  });
});

// Reset password
export const resetPassword = asyncHandler(async (req, res) => {
  const { reset_token, new_password } = req.body;

  if (!reset_token || !new_password) {
    throw new AppError('Reset token and new password are required', 400);
  }

  // Find token
  const tokenResult = await query(
    `SELECT user_id, token FROM password_reset_tokens 
     WHERE expires_at > CURRENT_TIMESTAMP AND used = FALSE
     LIMIT 1`,
    []
  );

  if (tokenResult.rows.length === 0) {
    throw new AppError('Invalid or expired reset token', 400);
  }

  // Verify token
  const token = tokenResult.rows[0];
  const tokenValid = await bcrypt.compare(reset_token, token.token);
  if (!tokenValid) {
    throw new AppError('Invalid reset token', 400);
  }

  // Hash new password
  const passwordHash = await bcrypt.hash(new_password, 10);

  // Update password
  await query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, token.user_id]);

  // Mark token as used
  await query('UPDATE password_reset_tokens SET used = TRUE WHERE token = $1', [token.token]);

  res.json({
    message: 'Password reset successfully',
  });
});

// Send OTP
export const sendOTP = asyncHandler(async (req, res) => {
  const { email } = req.body;

  if (!validateEmail(email)) {
    throw new AppError('Valid email is required', 400);
  }

  // Check if user exists
  const userResult = await query('SELECT id FROM users WHERE email = $1', [email]);
  if (userResult.rows.length === 0) {
    throw new AppError('User not found', 404);
  }

  const userId = userResult.rows[0].id;

  // Generate OTP
  const otp = generateOTP();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  // Store OTP
  await query(
    'INSERT INTO otp_codes (user_id, email, code, expires_at) VALUES ($1, $2, $3, $4)',
    [userId, email, otp, expiresAt]
  );

  // Send OTP email
  try {
    await sendOTPEmail(email, otp);
  } catch (error) {
    console.error('Failed to send OTP email:', error);
    throw new AppError('Failed to send OTP', 500);
  }

  res.json({
    message: 'OTP sent to email',
  });
});

// Verify OTP
export const verifyOTP = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;

  if (!validateEmail(email) || !validateOTP(otp)) {
    throw new AppError('Valid email and 6-digit OTP are required', 400);
  }

  // Find OTP
  const otpResult = await query(
    `SELECT id, user_id FROM otp_codes 
     WHERE email = $1 AND code = $2 AND verified = FALSE AND expires_at > CURRENT_TIMESTAMP
     ORDER BY created_at DESC LIMIT 1`,
    [email, otp]
  );

  if (otpResult.rows.length === 0) {
    throw new AppError('Invalid or expired OTP', 400);
  }

  const otpRecord = otpResult.rows[0];

  // Mark OTP as verified
  await query('UPDATE otp_codes SET verified = TRUE WHERE id = $1', [otpRecord.id]);

  // Mark email as verified
  await query('UPDATE users SET email_verified = TRUE WHERE id = $1', [otpRecord.user_id]);

  res.json({
    message: 'Email verified successfully',
  });
});

// Logout
export const logout = asyncHandler(async (req, res) => {
  const { refresh_token } = req.body;

  if (refresh_token) {
    // Revoke refresh token
    await query('UPDATE refresh_tokens SET revoked = TRUE WHERE token = $1', [refresh_token]);
  }

  res.json({
    message: 'Logout successful',
  });
});

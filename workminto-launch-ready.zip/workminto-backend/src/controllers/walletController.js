import { query } from '../config/database.js';
import { sendPointsEarnedEmail } from '../utils/email.js';
import { AppError, asyncHandler } from '../middleware/errorHandler.js';

// Get wallet
export const getWallet = asyncHandler(async (req, res) => {
  const userId = req.user.id;

  const walletResult = await query(
    'SELECT * FROM wallets WHERE user_id = $1',
    [userId]
  );

  if (walletResult.rows.length === 0) {
    throw new AppError('Wallet not found', 404);
  }

  const wallet = walletResult.rows[0];

  // Get user level
  const userResult = await query(
    'SELECT level FROM users WHERE id = $1',
    [userId]
  );

  res.json({
    id: wallet.id,
    user_id: wallet.user_id,
    total_points: wallet.total_points,
    available_points: wallet.available_points,
    pending_points: wallet.pending_points,
    level: userResult.rows[0].level,
    created_at: wallet.created_at,
    updated_at: wallet.updated_at,
  });
});

// Get transactions
export const getTransactions = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const offset = parseInt(req.query.offset) || 0;
  const type = req.query.type;

  let sql = 'SELECT * FROM wallet_transactions WHERE user_id = $1';
  const params = [userId];

  if (type) {
    sql += ' AND type = $2';
    params.push(type);
  }

  sql += ' ORDER BY created_at DESC LIMIT $' + (params.length + 1) + ' OFFSET $' + (params.length + 2);
  params.push(limit, offset);

  const result = await query(sql, params);

  // Get total count
  let countSql = 'SELECT COUNT(*) as total FROM wallet_transactions WHERE user_id = $1';
  const countParams = [userId];

  if (type) {
    countSql += ' AND type = $2';
    countParams.push(type);
  }

  const countResult = await query(countSql, countParams);

  res.json({
    data: result.rows,
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Add points (internal use)
export const addPoints = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const { points, type, description, reference_id } = req.body;

  if (!points || points <= 0) {
    throw new AppError('Points must be greater than 0', 400);
  }

  if (!type) {
    throw new AppError('Type is required', 400);
  }

  // Get wallet
  const walletResult = await query(
    'SELECT * FROM wallets WHERE user_id = $1',
    [userId]
  );

  if (walletResult.rows.length === 0) {
    throw new AppError('Wallet not found', 404);
  }

  const wallet = walletResult.rows[0];

  // Update wallet
  await query(
    `UPDATE wallets SET total_points = total_points + $1, available_points = available_points + $1 
     WHERE user_id = $2`,
    [points, userId]
  );

  // Record transaction
  await query(
    `INSERT INTO wallet_transactions (user_id, type, amount, description, reference_id)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, type, points, description, reference_id]
  );

  // Get user info for email
  const userResult = await query(
    'SELECT email, first_name FROM users WHERE id = $1',
    [userId]
  );

  // Send email
  try {
    await sendPointsEarnedEmail(userResult.rows[0].email, userResult.rows[0].first_name, points, description);
  } catch (error) {
    console.error('Failed to send points email:', error);
  }

  res.json({
    message: 'Points added successfully',
    points_added: points,
    new_balance: wallet.available_points + points,
  });
});

// Deduct points (internal use)
export const deductPoints = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const { points, reason } = req.body;

  if (!points || points <= 0) {
    throw new AppError('Points must be greater than 0', 400);
  }

  // Get wallet
  const walletResult = await query(
    'SELECT * FROM wallets WHERE user_id = $1',
    [userId]
  );

  if (walletResult.rows.length === 0) {
    throw new AppError('Wallet not found', 404);
  }

  const wallet = walletResult.rows[0];

  if (wallet.available_points < points) {
    throw new AppError('Insufficient points', 400);
  }

  // Update wallet
  await query(
    `UPDATE wallets SET available_points = available_points - $1 
     WHERE user_id = $2`,
    [points, userId]
  );

  // Record transaction
  await query(
    `INSERT INTO wallet_transactions (user_id, type, amount, description)
     VALUES ($1, $2, $3, $4)`,
    [userId, 'spent', points, reason]
  );

  res.json({
    message: 'Points deducted successfully',
    points_deducted: points,
    new_balance: wallet.available_points - points,
  });
});

import { query } from '../config/database.js';
import { AppError, asyncHandler } from '../middleware/errorHandler.js';

// Get referral stats
export const getReferralStats = asyncHandler(async (req, res) => {
  const userId = req.user.id;

  // Get referral code
  const codeResult = await query(
    `SELECT referral_code FROM referrals 
     WHERE referrer_id = $1 AND referred_user_id = $1 LIMIT 1`,
    [userId]
  );

  if (codeResult.rows.length === 0) {
    throw new AppError('Referral code not found', 404);
  }

  const referralCode = codeResult.rows[0].referral_code;

  // Get stats
  const statsResult = await query(
    `SELECT 
      COUNT(*) as total_referrals,
      SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_referrals,
      SUM(CASE WHEN bonus_awarded = TRUE THEN 1 ELSE 0 END) as completed_referrals,
      SUM(CASE WHEN bonus_awarded = TRUE THEN bonus_points ELSE 0 END) as total_bonus_earned
     FROM referrals 
     WHERE referrer_id = $1`,
    [userId]
  );

  const stats = statsResult.rows[0];

  res.json({
    referral_code: referralCode,
    referral_link: `${process.env.FRONTEND_URL}?ref=${referralCode}`,
    total_referrals: parseInt(stats.total_referrals) || 0,
    active_referrals: parseInt(stats.active_referrals) || 0,
    completed_referrals: parseInt(stats.completed_referrals) || 0,
    total_bonus_earned: parseInt(stats.total_bonus_earned) || 0,
  });
});

// Get referral history
export const getReferralHistory = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const limit = Math.min(parseInt(req.query.limit) || 20, 100);
  const offset = parseInt(req.query.offset) || 0;

  const result = await query(
    `SELECT 
      r.id,
      r.referred_user_id,
      u.first_name,
      u.last_name,
      u.email,
      r.status,
      r.bonus_points,
      r.bonus_awarded,
      r.created_at
     FROM referrals r
     JOIN users u ON r.referred_user_id = u.id
     WHERE r.referrer_id = $1 AND r.referrer_id != r.referred_user_id
     ORDER BY r.created_at DESC
     LIMIT $2 OFFSET $3`,
    [userId, limit, offset]
  );

  // Get total count
  const countResult = await query(
    `SELECT COUNT(*) as total FROM referrals 
     WHERE referrer_id = $1 AND referrer_id != referred_user_id`,
    [userId]
  );

  res.json({
    data: result.rows.map(row => ({
      id: row.id,
      referred_user: {
        id: row.referred_user_id,
        name: `${row.first_name} ${row.last_name}`,
        email: row.email,
      },
      status: row.status,
      bonus_points: row.bonus_points,
      bonus_awarded: row.bonus_awarded,
      referred_at: row.created_at,
    })),
    pagination: {
      total: parseInt(countResult.rows[0].total),
      limit,
      offset,
    },
  });
});

// Award referral bonus (called when referred user completes first task)
export const awardReferralBonus = asyncHandler(async (req, res) => {
  const referredUserId = req.user.id;

  // Find referral record
  const referralResult = await query(
    `SELECT * FROM referrals 
     WHERE referred_user_id = $1 AND bonus_awarded = FALSE
     LIMIT 1`,
    [referredUserId]
  );

  if (referralResult.rows.length === 0) {
    return res.json({
      message: 'No pending referral bonus',
    });
  }

  const referral = referralResult.rows[0];

  // Add bonus points to referrer
  await query(
    `UPDATE wallets SET total_points = total_points + $1, available_points = available_points + $1 
     WHERE user_id = $2`,
    [referral.bonus_points, referral.referrer_id]
  );

  // Record transaction
  await query(
    `INSERT INTO wallet_transactions (user_id, type, amount, description, reference_id)
     VALUES ($1, $2, $3, $4, $5)`,
    [referral.referrer_id, 'referral_bonus', referral.bonus_points, 
     `Referral bonus from ${referredUserId}`, `referral_${referral.id}`]
  );

  // Mark bonus as awarded
  await query(
    `UPDATE referrals SET bonus_awarded = TRUE, status = 'completed' WHERE id = $1`,
    [referral.id]
  );

  res.json({
    message: 'Referral bonus awarded',
    bonus_points: referral.bonus_points,
  });
});

// Validate referral code
export const validateReferralCode = asyncHandler(async (req, res) => {
  const { code } = req.body;

  if (!code) {
    throw new AppError('Referral code is required', 400);
  }

  const result = await query(
    `SELECT r.referrer_id, u.first_name, u.last_name FROM referrals r
     JOIN users u ON r.referrer_id = u.id
     WHERE r.referral_code = $1 AND r.status = 'active'
     LIMIT 1`,
    [code]
  );

  if (result.rows.length === 0) {
    throw new AppError('Invalid referral code', 400);
  }

  const referrer = result.rows[0];

  res.json({
    valid: true,
    referrer: {
      id: referrer.referrer_id,
      name: `${referrer.first_name} ${referrer.last_name}`,
    },
  });
});

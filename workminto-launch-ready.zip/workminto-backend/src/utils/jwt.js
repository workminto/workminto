import jwt from 'jsonwebtoken';

export const generateAccessToken = (userId, email, role = 'user') => {
  return jwt.sign(
    {
      sub: userId,
      email,
      role,
    },
    process.env.JWT_SECRET || 'your_secret_key',
    {
      expiresIn: process.env.JWT_EXPIRE || '7d',
      issuer: 'workminto',
      audience: 'workminto-app',
    }
  );
};

export const generateRefreshToken = (userId) => {
  return jwt.sign(
    {
      sub: userId,
      type: 'refresh',
    },
    process.env.JWT_REFRESH_SECRET || 'your_refresh_secret_key',
    {
      expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d',
      issuer: 'workminto',
    }
  );
};

export const verifyAccessToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET || 'your_secret_key', {
      issuer: 'workminto',
      audience: 'workminto-app',
    });
  } catch (error) {
    throw new Error('Invalid or expired token');
  }
};

export const verifyRefreshToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_REFRESH_SECRET || 'your_refresh_secret_key', {
      issuer: 'workminto',
    });
  } catch (error) {
    throw new Error('Invalid or expired refresh token');
  }
};

export const decodeToken = (token) => {
  try {
    return jwt.decode(token);
  } catch (error) {
    return null;
  }
};

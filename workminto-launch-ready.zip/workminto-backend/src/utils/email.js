import nodemailer from 'nodemailer';

let transporter;

// Initialize email transporter
export const initializeEmailService = () => {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.sendgrid.net',
    port: process.env.SMTP_PORT || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER || 'apikey',
      pass: process.env.SMTP_PASS || '',
    },
  });
};

export const sendEmail = async (to, subject, html) => {
  try {
    if (!transporter) {
      initializeEmailService();
    }

    const mailOptions = {
      from: process.env.SMTP_FROM || 'noreply@workminto.com',
      to,
      subject,
      html,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.messageId);
    return info;
  } catch (error) {
    console.error('Email sending error:', error);
    throw error;
  }
};

export const sendOTPEmail = async (email, otp) => {
  const subject = 'Your Workminto OTP Code';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Email Verification</h2>
      <p>Your one-time password (OTP) is:</p>
      <div style="background-color: #f0f0f0; padding: 20px; text-align: center; border-radius: 5px; margin: 20px 0;">
        <h1 style="letter-spacing: 5px; color: #333;">${otp}</h1>
      </div>
      <p>This code will expire in 10 minutes.</p>
      <p>If you didn't request this code, please ignore this email.</p>
      <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
      <p style="color: #666; font-size: 12px;">© 2024 Workminto. All rights reserved.</p>
    </div>
  `;

  return sendEmail(email, subject, html);
};

export const sendPasswordResetEmail = async (email, resetToken) => {
  const resetLink = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;
  const subject = 'Reset Your Workminto Password';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Password Reset Request</h2>
      <p>We received a request to reset your password. Click the link below to proceed:</p>
      <div style="margin: 30px 0;">
        <a href="${resetLink}" style="background-color: #ff1493; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
          Reset Password
        </a>
      </div>
      <p>Or copy and paste this link in your browser:</p>
      <p style="word-break: break-all; color: #666;">${resetLink}</p>
      <p>This link will expire in 24 hours.</p>
      <p>If you didn't request this, please ignore this email.</p>
      <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
      <p style="color: #666; font-size: 12px;">© 2024 Workminto. All rights reserved.</p>
    </div>
  `;

  return sendEmail(email, subject, html);
};

export const sendWelcomeEmail = async (email, firstName) => {
  const subject = 'Welcome to Workminto!';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Welcome to Workminto, ${firstName}!</h2>
      <p>We're excited to have you on board. Start earning points by completing tasks, taking surveys, and referring friends.</p>
      <div style="background-color: #f0f0f0; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <h3>Get Started:</h3>
        <ul>
          <li>Complete daily check-ins for 50 points</li>
          <li>Take quizzes to earn 100 points each</li>
          <li>Refer friends and earn 200 bonus points</li>
          <li>Redeem your points for real rewards</li>
        </ul>
      </div>
      <p>Happy earning!</p>
      <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
      <p style="color: #666; font-size: 12px;">© 2024 Workminto. All rights reserved.</p>
    </div>
  `;

  return sendEmail(email, subject, html);
};

export const sendPointsEarnedEmail = async (email, firstName, points, description) => {
  const subject = `You earned ${points} points!`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Points Earned! 🎉</h2>
      <p>Hi ${firstName},</p>
      <p>You just earned <strong>${points} points</strong> from: ${description}</p>
      <div style="background-color: #f0f0f0; padding: 20px; text-align: center; border-radius: 5px; margin: 20px 0;">
        <h1 style="color: #ff1493;">+${points}</h1>
      </div>
      <p>Keep up the great work! View your wallet to see your total balance.</p>
      <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
      <p style="color: #666; font-size: 12px;">© 2024 Workminto. All rights reserved.</p>
    </div>
  `;

  return sendEmail(email, subject, html);
};

export const sendWithdrawalApprovedEmail = async (email, firstName, points, currency) => {
  const subject = 'Your Withdrawal Has Been Approved!';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Withdrawal Approved ✓</h2>
      <p>Hi ${firstName},</p>
      <p>Your withdrawal request has been approved!</p>
      <div style="background-color: #f0f0f0; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <p><strong>Amount:</strong> ${points} points (${currency})</p>
        <p><strong>Status:</strong> Approved</p>
        <p><strong>Processing Time:</strong> 1-3 business days</p>
      </div>
      <p>You'll receive your payment shortly. Thank you for using Workminto!</p>
      <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
      <p style="color: #666; font-size: 12px;">© 2024 Workminto. All rights reserved.</p>
    </div>
  `;

  return sendEmail(email, subject, html);
};

export const sendWithdrawalRejectedEmail = async (email, firstName, points, reason) => {
  const subject = 'Your Withdrawal Request Has Been Rejected';
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Withdrawal Rejected</h2>
      <p>Hi ${firstName},</p>
      <p>Your withdrawal request has been rejected.</p>
      <div style="background-color: #f0f0f0; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <p><strong>Amount:</strong> ${points} points</p>
        <p><strong>Reason:</strong> ${reason}</p>
      </div>
      <p>Your points have been returned to your wallet. If you have questions, please contact our support team.</p>
      <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
      <p style="color: #666; font-size: 12px;">© 2024 Workminto. All rights reserved.</p>
    </div>
  `;

  return sendEmail(email, subject, html);
};

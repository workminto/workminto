import pkg from 'pg';
import bcrypt from 'bcryptjs';
const { Pool } = pkg;

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'workminto',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
});

async function seedDatabase() {
  const client = await pool.connect();
  
  try {
    console.log('Seeding database...');
    
    // Hash passwords
    const adminPassword = await bcrypt.hash('Admin123!', 10);
    const userPassword = await bcrypt.hash('User123!', 10);
    
    // Create admin user
    const adminResult = await client.query(
      `INSERT INTO users (username, email, password_hash, first_name, last_name, status, email_verified, level)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (email) DO NOTHING
       RETURNING id`,
      ['admin', 'admin@workminto.com', adminPassword, 'Admin', 'User', 'active', true, 99]
    );
    
    if (adminResult.rows.length > 0) {
      const adminId = adminResult.rows[0].id;
      console.log(`✓ Admin user created (ID: ${adminId})`);
      
      // Create admin wallet
      await client.query(
        'INSERT INTO wallets (user_id, total_points, available_points) VALUES ($1, $2, $3)',
        [adminId, 0, 0]
      );
    }
    
    // Create test users
    const testUsers = [
      { username: 'john_doe', email: 'john@example.com', firstName: 'John', lastName: 'Doe' },
      { username: 'jane_smith', email: 'jane@example.com', firstName: 'Jane', lastName: 'Smith' },
      { username: 'bob_wilson', email: 'bob@example.com', firstName: 'Bob', lastName: 'Wilson' },
    ];
    
    for (const user of testUsers) {
      const result = await client.query(
        `INSERT INTO users (username, email, password_hash, first_name, last_name, status, email_verified, level)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         ON CONFLICT (email) DO NOTHING
         RETURNING id`,
        [user.username, user.email, userPassword, user.firstName, user.lastName, 'active', true, 1]
      );
      
      if (result.rows.length > 0) {
        const userId = result.rows[0].id;
        console.log(`✓ Test user created: ${user.email} (ID: ${userId})`);
        
        // Create wallet for user
        await client.query(
          'INSERT INTO wallets (user_id, total_points, available_points) VALUES ($1, $2, $3)',
          [userId, 1000, 1000]
        );
        
        // Create referral code
        const referralCode = `${user.username.toUpperCase()}${Math.floor(Math.random() * 1000)}`;
        await client.query(
          `INSERT INTO referrals (referrer_id, referred_user_id, referral_code, status)
           VALUES ($1, $2, $3, $4)`,
          [userId, userId, referralCode, 'active']
        );
      }
    }
    
    // Create sample tasks
    const tasks = [
      {
        title: 'Daily Check-in',
        description: 'Check in daily to earn points',
        category: 'daily_checkin',
        reward: 50,
      },
      {
        title: 'Complete Quiz',
        description: 'Answer 5 questions and earn points',
        category: 'quiz',
        reward: 100,
      },
      {
        title: 'Watch Video',
        description: 'Watch a short video and earn points',
        category: 'video',
        reward: 25,
      },
      {
        title: 'Refer a Friend',
        description: 'Invite a friend and earn bonus points',
        category: 'referral',
        reward: 200,
      },
    ];
    
    for (const task of tasks) {
      await client.query(
        `INSERT INTO tasks (title, description, category, reward_points, status)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT DO NOTHING`,
        [task.title, task.description, task.category, task.reward, 'active']
      );
      console.log(`✓ Task created: ${task.title}`);
    }
    
    console.log('Database seeding completed successfully!');
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seedDatabase();

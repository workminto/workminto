# Workminto Backend API

Production-ready Node.js/Express backend for the Workminto rewards platform.

## Features

- ✅ User authentication (signup, login, password reset, OTP verification)
- ✅ JWT-based authorization with refresh tokens
- ✅ Wallet system with points management
- ✅ Referral tracking and bonus rewards
- ✅ Withdrawal request management with admin approval
- ✅ Admin dashboard and user management
- ✅ Audit logging for all admin actions
- ✅ Email notifications
- ✅ Rate limiting and security headers
- ✅ PostgreSQL database with migrations
- ✅ Docker support for easy deployment

## Tech Stack

- **Runtime:** Node.js 18+
- **Framework:** Express.js 4
- **Database:** PostgreSQL 15
- **Authentication:** JWT (jsonwebtoken)
- **Security:** bcryptjs, helmet, cors, rate-limit
- **Email:** nodemailer (SendGrid)
- **Containerization:** Docker & Docker Compose

## Installation

### Prerequisites

- Node.js 18+ or Docker
- PostgreSQL 15+ (or use Docker Compose)
- npm or yarn

### Local Setup

1. **Clone and install dependencies:**
   ```bash
   cd workminto-backend
   npm install
   ```

2. **Configure environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Run database migrations:**
   ```bash
   npm run migrate
   ```

4. **Seed sample data (optional):**
   ```bash
   npm run seed
   ```

5. **Start development server:**
   ```bash
   npm run dev
   ```

The API will be available at `http://localhost:3001`

### Docker Setup

1. **Build and run with Docker Compose:**
   ```bash
   docker-compose up -d
   ```

2. **Run migrations inside container:**
   ```bash
   docker-compose exec api npm run migrate
   ```

3. **Seed data (optional):**
   ```bash
   docker-compose exec api npm run seed
   ```

## API Documentation

### Authentication Endpoints

#### Signup
```
POST /api/auth/signup
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "first_name": "John",
  "last_name": "Doe",
  "referral_code": "OPTIONAL_CODE"
}

Response: 201 Created
{
  "message": "User registered successfully",
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "user": { ... }
}
```

#### Login
```
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!"
}

Response: 200 OK
{
  "message": "Login successful",
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "user": { ... }
}
```

#### Send OTP
```
POST /api/auth/send-otp
Content-Type: application/json

{
  "email": "user@example.com"
}

Response: 200 OK
{
  "message": "OTP sent to email"
}
```

#### Verify OTP
```
POST /api/auth/verify-otp
Content-Type: application/json

{
  "email": "user@example.com",
  "otp": "123456"
}

Response: 200 OK
{
  "message": "Email verified successfully"
}
```

#### Refresh Token
```
POST /api/auth/refresh-token
Content-Type: application/json

{
  "refresh_token": "eyJhbGc..."
}

Response: 200 OK
{
  "access_token": "eyJhbGc..."
}
```

### Wallet Endpoints

#### Get Wallet
```
GET /api/wallet
Authorization: Bearer <access_token>

Response: 200 OK
{
  "id": 1,
  "user_id": 1,
  "total_points": 1000,
  "available_points": 800,
  "pending_points": 200,
  "level": 1,
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

#### Get Transactions
```
GET /api/wallet/transactions?limit=20&offset=0&type=earned
Authorization: Bearer <access_token>

Response: 200 OK
{
  "data": [ ... ],
  "pagination": {
    "total": 100,
    "limit": 20,
    "offset": 0
  }
}
```

### Referral Endpoints

#### Get Referral Stats
```
GET /api/referrals/stats
Authorization: Bearer <access_token>

Response: 200 OK
{
  "referral_code": "JOHN1234",
  "referral_link": "https://workminto.com?ref=JOHN1234",
  "total_referrals": 5,
  "active_referrals": 3,
  "completed_referrals": 2,
  "total_bonus_earned": 400
}
```

#### Get Referral History
```
GET /api/referrals/history?limit=20&offset=0
Authorization: Bearer <access_token>

Response: 200 OK
{
  "data": [ ... ],
  "pagination": { ... }
}
```

### Withdrawal Endpoints

#### Create Withdrawal
```
POST /api/withdrawals
Authorization: Bearer <access_token>
Content-Type: application/json

{
  "amount_points": 1000,
  "method": "paypal",
  "payment_details": {
    "email": "user@paypal.com"
  }
}

Response: 201 Created
{
  "id": 1,
  "amount_points": 1000,
  "amount_currency": "10.00",
  "method": "paypal",
  "status": "pending",
  "requested_at": "2024-01-01T00:00:00Z",
  "message": "Withdrawal request submitted successfully"
}
```

#### Get User Withdrawals
```
GET /api/withdrawals?status=pending&limit=20&offset=0
Authorization: Bearer <access_token>

Response: 200 OK
{
  "data": [ ... ],
  "pagination": { ... }
}
```

### Admin Endpoints

#### Get Dashboard Stats
```
GET /api/admin/dashboard/stats
Authorization: Bearer <admin_token>

Response: 200 OK
{
  "total_users": 1000,
  "active_users": 500,
  "total_points_distributed": 50000,
  "pending_withdrawals": 10,
  "completed_withdrawals": 100,
  "recent_activity": [ ... ]
}
```

#### Get Users
```
GET /api/admin/users?status=active&limit=50&offset=0&search=john
Authorization: Bearer <admin_token>

Response: 200 OK
{
  "data": [ ... ],
  "pagination": { ... }
}
```

#### Approve Withdrawal
```
POST /api/admin/withdrawals/:withdrawalId/approve
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "notes": "Approved - verified account"
}

Response: 200 OK
{
  "message": "Withdrawal approved successfully",
  "withdrawal_id": 1,
  "status": "approved"
}
```

## Environment Variables

```
NODE_ENV=development
PORT=3001
API_URL=http://localhost:3001

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=workminto
DB_USER=postgres
DB_PASSWORD=postgres

# JWT
JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRE=7d
JWT_REFRESH_SECRET=your_super_secret_refresh_key
JWT_REFRESH_EXPIRE=30d

# Email
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your_sendgrid_api_key
SMTP_FROM=noreply@workminto.com

# Frontend
FRONTEND_URL=http://localhost:3000

# Admin
ADMIN_EMAIL=admin@workminto.com
```

## Database Schema

The API uses PostgreSQL with the following main tables:

- `users` - User accounts and profiles
- `wallets` - User wallet balances
- `wallet_transactions` - Points transaction history
- `referrals` - Referral tracking and bonuses
- `withdrawals` - Withdrawal requests and approvals
- `tasks` - Available tasks for users
- `task_completions` - User task completion records
- `notifications` - User notifications
- `announcements` - Platform announcements
- `audit_logs` - Admin action logging
- `otp_codes` - OTP verification codes
- `password_reset_tokens` - Password reset tokens
- `refresh_tokens` - JWT refresh tokens

## Security Features

- ✅ Password hashing with bcryptjs
- ✅ JWT token-based authentication
- ✅ Refresh token rotation
- ✅ Rate limiting on auth endpoints
- ✅ CORS configuration
- ✅ Security headers with helmet
- ✅ Input validation and sanitization
- ✅ SQL injection prevention (parameterized queries)
- ✅ Audit logging for all admin actions
- ✅ Email verification for accounts

## Error Handling

All errors return consistent JSON responses:

```json
{
  "error": "error_code",
  "message": "Human-readable error message"
}
```

Common HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict (duplicate)
- `500` - Server Error

## Testing

```bash
# Run tests
npm test

# Run with coverage
npm test -- --coverage

# Run specific test file
npm test -- auth.test.js
```

## Deployment

### Production Checklist

- [ ] Set strong JWT secrets
- [ ] Configure proper database backups
- [ ] Set up email service (SendGrid, AWS SES, etc.)
- [ ] Configure CORS for production domain
- [ ] Enable HTTPS
- [ ] Set up monitoring and logging
- [ ] Configure rate limiting appropriately
- [ ] Set up CI/CD pipeline
- [ ] Run security audit
- [ ] Configure database connection pooling

### Deployment Options

1. **Docker (Recommended)**
   ```bash
   docker build -t workminto-api .
   docker run -p 3001:3001 --env-file .env workminto-api
   ```

2. **Heroku**
   ```bash
   heroku create workminto-api
   git push heroku main
   ```

3. **AWS EC2**
   - Use Docker or PM2 for process management
   - Configure security groups
   - Set up RDS for PostgreSQL

4. **DigitalOcean App Platform**
   - Connect GitHub repository
   - Configure environment variables
   - Deploy automatically

## Contributing

1. Create a feature branch
2. Make your changes
3. Write tests
4. Submit a pull request

## License

MIT

## Support

For issues and questions, please contact support@workminto.com

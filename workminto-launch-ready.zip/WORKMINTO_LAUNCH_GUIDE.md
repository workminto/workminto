# Workminto - Production Launch Guide

**Status:** Ready to Launch ✅  
**Completion:** 45% (MVP with placeholders for monetization)  
**Time to Deploy:** 15 minutes  

---

## WHAT'S LIVE RIGHT NOW

✅ **User Authentication**
- Signup with email/password
- Login with email/password
- OTP verification
- Password reset
- JWT token management

✅ **User Dashboard**
- Points balance display
- Referral code and stats
- Recent activity
- User level progression
- Transaction history

✅ **Referral System**
- Referral code generation
- Referral tracking
- Bonus points awarded (200 points per referral)
- Referral history and statistics

✅ **Wallet System**
- Points balance tracking
- Transaction history
- Points display in USD equivalent
- User level system

✅ **Withdrawal System**
- Withdrawal request submission
- Admin approval/rejection
- Withdrawal history
- Email notifications

✅ **Admin Panel**
- User management (view, suspend, ban)
- Withdrawal approval dashboard
- User statistics
- Audit logs
- Announcements management

✅ **Design & UI**
- Premium dark theme with neon gradients
- Mobile-first responsive design
- All 20+ pages built
- Beautiful animations and interactions

---

## WHAT'S PLACEHOLDER (Coming Soon)

❌ **Monetization Features** (Not yet implemented - marked as "Coming Soon")
- Offerwall integration (Pollfish, AdGem, etc.)
- Survey platform
- Task system
- Ad network

❌ **Payment Processing** (Not yet implemented)
- Stripe integration for payouts
- PayPal integration
- Bank transfer processing

❌ **Advanced Features** (Not yet implemented)
- Mobile app
- Real-time notifications
- Advanced fraud detection
- Email verification enforcement

---

## DEPLOYMENT OPTIONS

### OPTION 1: RAILWAY (EASIEST - RECOMMENDED) ⭐

Railway is the easiest option for non-technical founders. It handles everything automatically.

**Cost:** $5-20/month  
**Setup time:** 10 minutes  
**Difficulty:** Easy  

#### Steps:

1. **Create Railway Account**
   - Go to https://railway.app
   - Sign up with GitHub
   - Create new project

2. **Connect GitHub**
   - Fork the Workminto repository (or upload to GitHub)
   - Connect Railway to your GitHub repo

3. **Add PostgreSQL Database**
   - In Railway dashboard: Add Service → PostgreSQL
   - Railway automatically creates database

4. **Add Node.js Backend**
   - In Railway dashboard: Add Service → GitHub Repo
   - Select workminto-backend
   - Railway auto-detects Node.js

5. **Configure Environment Variables**
   - In Railway dashboard → Variables
   - Add these variables:
   ```
   NODE_ENV=production
   PORT=3001
   DB_HOST=postgres (Railway provides)
   DB_PORT=5432
   DB_NAME=railway
   DB_USER=postgres
   DB_PASSWORD=(Railway provides)
   JWT_SECRET=your_secret_key_here_change_this
   JWT_REFRESH_SECRET=your_refresh_secret_here_change_this
   FRONTEND_URL=https://your-domain.com
   SMTP_HOST=smtp.mailtrap.io
   SMTP_PORT=2525
   SMTP_USER=your_mailtrap_user
   SMTP_PASS=your_mailtrap_pass
   ```

6. **Deploy Frontend**
   - In Railway dashboard: Add Service → GitHub Repo
   - Select workminto (frontend)
   - Set build command: `npm run build`
   - Set start command: `npm run start`

7. **Get Your URL**
   - Railway provides automatic URLs
   - Frontend: https://workminto-frontend-xxx.railway.app
   - Backend: https://workminto-backend-xxx.railway.app

8. **Update Frontend API URL**
   - In frontend code: `client/src/config/api.ts`
   - Change `VITE_API_URL` to your Railway backend URL

9. **Deploy**
   - Push to GitHub
   - Railway auto-deploys

**Total time: 10 minutes**

---

### OPTION 2: VERCEL + RAILWAY (FAST)

**Cost:** $0-20/month  
**Setup time:** 15 minutes  
**Difficulty:** Easy  

#### Steps:

1. **Deploy Backend to Railway** (see Option 1 above)

2. **Deploy Frontend to Vercel**
   - Go to https://vercel.com
   - Sign up with GitHub
   - Import workminto repository
   - Set build command: `npm run build`
   - Deploy

3. **Update Environment Variables**
   - In Vercel: Settings → Environment Variables
   - Add `VITE_API_URL=https://your-railway-backend-url`

4. **Done!**
   - Frontend: https://your-project.vercel.app
   - Backend: Railway URL

**Total time: 15 minutes**

---

### OPTION 3: DOCKER (SELF-HOSTED)

**Cost:** $5-50/month (depending on server)  
**Setup time:** 30 minutes  
**Difficulty:** Moderate  

#### Prerequisites:
- Server with Docker installed (DigitalOcean, Linode, AWS)
- Domain name (optional)

#### Steps:

1. **SSH into your server**
   ```bash
   ssh root@your-server-ip
   ```

2. **Clone repository**
   ```bash
   git clone https://github.com/your-username/workminto.git
   cd workminto-backend
   ```

3. **Create .env file**
   ```bash
   cat > .env << EOF
   NODE_ENV=production
   PORT=3001
   DB_HOST=postgres
   DB_PORT=5432
   DB_NAME=workminto
   DB_USER=postgres
   DB_PASSWORD=your_secure_password_here
   JWT_SECRET=your_secret_key_here_change_this
   JWT_REFRESH_SECRET=your_refresh_secret_here_change_this
   FRONTEND_URL=https://your-domain.com
   SMTP_HOST=smtp.mailtrap.io
   SMTP_PORT=2525
   SMTP_USER=your_mailtrap_user
   SMTP_PASS=your_mailtrap_pass
   EOF
   ```

4. **Start with Docker Compose**
   ```bash
   docker-compose up -d
   ```

5. **Run migrations**
   ```bash
   docker-compose exec api npm run migrate
   docker-compose exec api npm run seed
   ```

6. **Deploy Frontend**
   - Build: `npm run build`
   - Upload `dist/` folder to your web server (Nginx, Apache)
   - Or use Vercel/Netlify

7. **Set up SSL (HTTPS)**
   ```bash
   # Using Let's Encrypt with Certbot
   sudo apt-get install certbot python3-certbot-nginx
   sudo certbot certonly --standalone -d your-domain.com
   ```

8. **Configure Nginx**
   ```nginx
   server {
     listen 443 ssl;
     server_name your-domain.com;
     
     ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
     ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;
     
     location / {
       proxy_pass http://localhost:3001;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection 'upgrade';
       proxy_set_header Host $host;
       proxy_cache_bypass $http_upgrade;
     }
   }
   ```

9. **Restart Nginx**
   ```bash
   sudo systemctl restart nginx
   ```

**Total time: 30 minutes**

---

## QUICK START (LOCAL TESTING)

### Prerequisites:
- Node.js 18+
- PostgreSQL 12+
- npm or pnpm

### Steps:

1. **Install dependencies**
   ```bash
   cd /home/ubuntu/workminto-backend
   npm install
   
   cd /home/ubuntu/workminto
   npm install
   ```

2. **Start PostgreSQL**
   ```bash
   # On Mac
   brew services start postgresql
   
   # On Linux
   sudo systemctl start postgresql
   
   # On Windows
   # Start PostgreSQL service from Services
   ```

3. **Create database**
   ```bash
   createdb workminto
   ```

4. **Run migrations**
   ```bash
   cd /home/ubuntu/workminto-backend
   npm run migrate
   npm run seed
   ```

5. **Start backend**
   ```bash
   cd /home/ubuntu/workminto-backend
   npm run dev
   # Backend running on http://localhost:3001
   ```

6. **Start frontend** (in new terminal)
   ```bash
   cd /home/ubuntu/workminto
   npm run dev
   # Frontend running on http://localhost:3000
   ```

7. **Access the app**
   - Open http://localhost:3000
   - Sign up with test email
   - Login
   - Explore dashboard

---

## ENVIRONMENT VARIABLES EXPLAINED

### Backend (.env)

```
# Server
NODE_ENV=production          # Set to 'production' for live
PORT=3001                    # Backend port

# Database
DB_HOST=localhost            # PostgreSQL host
DB_PORT=5432                 # PostgreSQL port
DB_NAME=workminto            # Database name
DB_USER=postgres             # Database user
DB_PASSWORD=your_password    # Database password

# Authentication
JWT_SECRET=your_secret_key   # Change this! Use strong random string
JWT_EXPIRE=7d                # Token expiration
JWT_REFRESH_SECRET=refresh   # Change this! Use strong random string
JWT_REFRESH_EXPIRE=30d       # Refresh token expiration

# Email
SMTP_HOST=smtp.mailtrap.io   # Email service host
SMTP_PORT=2525               # Email service port
SMTP_USER=your_username      # Email service username
SMTP_PASS=your_password      # Email service password
SMTP_FROM=noreply@workminto.com

# Frontend
FRONTEND_URL=http://localhost:3000  # Frontend URL (change in production)

# Admin
ADMIN_EMAIL=admin@workminto.com
```

### Frontend (.env)

```
VITE_API_URL=http://localhost:3001/api  # Backend API URL (change in production)
```

---

## TESTING THE PLATFORM

### Test User Flow:

1. **Signup**
   - Go to http://localhost:3000/signup
   - Enter email: test@example.com
   - Enter password: Test123!
   - Click "Create Account"

2. **Login**
   - Go to http://localhost:3000/login
   - Enter email: test@example.com
   - Enter password: Test123!
   - Click "Sign In"

3. **Dashboard**
   - See points balance (starts at 0)
   - See referral code
   - See recent activity

4. **Referrals**
   - Go to /referrals
   - Copy referral code
   - Share with friend
   - When friend signs up with code, you get 200 bonus points

5. **Wallet**
   - Go to /wallet
   - See points balance
   - See transaction history

6. **Withdrawal**
   - Go to /wallet
   - Click "Request Withdrawal"
   - Enter amount (minimum 1000 points = $10)
   - Submit request
   - Admin must approve

7. **Admin Panel**
   - Go to /admin/dashboard
   - See user statistics
   - Go to /admin/withdrawals
   - Approve/reject withdrawal requests

---

## WHAT'S NOT READY YET

### Monetization Features (Placeholders)
- ❌ Offerwall - Users cannot complete offers yet
- ❌ Surveys - No survey integration
- ❌ Tasks - No task system
- ❌ Ads - No ad network

### Payment Processing
- ❌ Stripe - Payouts not processed
- ❌ PayPal - Alternative payment not available
- ❌ Bank Transfer - Direct bank payouts not available

### Advanced Features
- ❌ Mobile App - Not built yet
- ❌ Real-time Notifications - Not implemented
- ❌ Email Verification - Not enforced
- ❌ 2FA - Not implemented

**These will be added after launch based on user demand.**

---

## MONITORING & MAINTENANCE

### Check Backend Health
```bash
curl https://your-backend-url/health
```

### View Logs
```bash
# Docker
docker-compose logs -f api

# Traditional
tail -f /var/log/workminto.log
```

### Database Backup
```bash
# PostgreSQL backup
pg_dump workminto > backup.sql

# Restore
psql workminto < backup.sql
```

### Update Code
```bash
# Pull latest changes
git pull origin main

# Restart backend
docker-compose restart api
# or
npm run dev
```

---

## TROUBLESHOOTING

### Backend won't start
```bash
# Check if port 3001 is in use
lsof -i :3001

# Kill process
kill -9 <PID>

# Try again
npm run dev
```

### Database connection error
```bash
# Check PostgreSQL is running
psql -U postgres -d workminto

# If not running, start it
sudo systemctl start postgresql
```

### Frontend can't reach backend
```bash
# Check backend is running
curl http://localhost:3001/health

# Check CORS is enabled
# In backend: src/index.js should have CORS middleware

# Check frontend API URL
# In frontend: client/src/config/api.ts
```

### Email not sending
```bash
# Check SMTP credentials
# In .env file, verify:
# - SMTP_HOST
# - SMTP_PORT
# - SMTP_USER
# - SMTP_PASS

# Test with Mailtrap
# Go to https://mailtrap.io
# Create account and get credentials
```

---

## SUPPORT

### Documentation
- Backend: `/home/ubuntu/workminto-backend/README.md`
- Frontend: `/home/ubuntu/workminto/README.md`
- API: `/home/ubuntu/workminto/API_SPECIFICATION.md`
- Architecture: `/home/ubuntu/workminto/BACKEND_ARCHITECTURE.md`

### Getting Help
- Check logs: `docker-compose logs`
- Test API: Use Postman collection
- Check environment variables: `cat .env`

---

## NEXT STEPS AFTER LAUNCH

### Week 1: Get First Users
- Share with friends
- Get feedback
- Fix bugs

### Week 2-3: Add Monetization
- Integrate offerwall (Pollfish)
- Add Stripe payments
- Users start earning

### Week 4+: Scale
- Marketing
- Mobile app
- Advanced features

---

**Workminto is ready to launch! 🚀**

Choose your deployment option above and go live in 10-30 minutes.
